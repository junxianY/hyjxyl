package cn.comshinetechchina.hyjxyl.util;

import cn.comshinetechchina.hyjxyl.base.Constant;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
* @ClassName: DateUtil 
* @Description: 日期操作类
* @author yjx
* @date 2018年4月13日 上午11:15:37
*
 */
public class DateUtil {
	 static SimpleDateFormat format = new SimpleDateFormat(Constant.DATETYPEYMD);
	/**
	 * 在给定的日期上加上天数返回新的日期
	 * @param date
	 * @param dayNum
	 * @return
	 */
	public static Date addDay(Date date,int dayNum){
		Calendar instance = Calendar.getInstance();
		instance.setTime(date);
		instance.set(Calendar.DAY_OF_MONTH,instance.get(Calendar.DAY_OF_MONTH)+dayNum);
		Date date2 = instance.getTime();
		return date2;
	}

	/**
	 * 计算增加多少天、月、年后的日期
	 * @param year
	 * @param month
	 * @param day
	 * @return
	 */
	public static Date getSysDate(int year,int month,int day){
		Calendar cal =Calendar.getInstance();
		if(day!=0){
			cal.add(cal.DATE,day);
		}
		if(month!=0)   {
			cal.add(cal.MONTH,month);
		}
		if(year!=0)   {
			cal.add(cal.YEAR,year);
		}
		return  cal.getTime();
	}
	/**
	 * 转化星期格式
	 * @param dateTime
	 * @return
	 */
	public static String getWeekStr(Date dateTime){
		String[] week = {"周天","周一","周二","周三","周四","周五","周六"};
		return week[getWeek(dateTime)-1];
	}
	/**
	 * 将字符串日期转换
	 * @param dateStr
	 * @param pattern
	 * @return
	 * @throws ParseException
	 */
	public static Date transferStr2Date(String dateStr,String pattern) throws ParseException{
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		Date date = format.parse(dateStr);
		return date;
	}
	/**
	 * 将date转换为String
	 * @param date
	 * @param pattern
	 * @return
	 * @throws ParseException
	 */
	public static String transferDate2Str(Date date,String pattern) throws ParseException{
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		String dateStr = format.format(date);
		return dateStr;
	}
	/**
	 * 获取日期中的星期
	 * @param date
	 * @return
	 */
	public static int getWeek(Date date){
		Calendar cal=Calendar.getInstance();
		cal.setTime(date);
		int week = cal.get(Calendar.DAY_OF_WEEK);
		return week;
	}
	/**
	 * 比较两个日期
	 * @param DATE1  yyyy-MM-dd 格式
	 * @param DATE2 yyyy-MM-dd 格式
	 * @return
	 */
	public static int compareDate(String DATE1, String DATE2) {
        DateFormat df = new SimpleDateFormat(Constant.DATETYPEYMD);
        try {
        	Date dt1 = df.parse(DATE1);
            Date dt2 = df.parse(DATE2);
            return compare_date(dt1, dt2);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0;
    }
	/**
	 * 精确比较两个日期
	 * @param DATE1  yyyy-MM-dd HH:mm:ss
	 * @param DATE2  yyyy-MM-dd HH:mm:ss
	 * @return
	 */
	public static int compareDateTime(String DATE1, String DATE2) {
        DateFormat df = new SimpleDateFormat(Constant.DATETYPEYMDHMS);
        try {
        	Date dt1 = df.parse(DATE1);
            Date dt2 = df.parse(DATE2);
            return compare_date(dt1, dt2);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0;
    }
	/**
	 * 比较两个日期
	 * @param dt1
	 * @param dt2
	 * @return
	 */
	public static int compare_date(Date dt1, Date dt2){
		if (dt1.getTime() > dt2.getTime()) {
            return 1;
        } else if (dt1.getTime() < dt2.getTime()) {
            return -1;
        } else {
            return 0;
        }
	}
	/**
	 * 获取格式化的当前时间
	 * @param pattern
	 * @return
	 * @throws ParseException
	 */
	public static Date getCurrentDateByFormat(String pattern) throws ParseException{
		Date curr = new Date();
		String date2Str = transferDate2Str(curr, pattern);
		Date cDate = transferStr2Date(date2Str, pattern);
		return cDate;
	}
	
	public static String getCurrentDateStrByFormat(String pattern) throws ParseException{
		Date curr = new Date();
		String date2Str = transferDate2Str(curr, pattern);
		return date2Str;
	}
	
	/**
	 * 给日期增加分钟
	 * @param day
	 * @param x
	 * @return
	 */
	public static String addDateMinut(String day, int x){//返回的是字符串型的时间，输入的是String day, int x
        SimpleDateFormat format = new SimpleDateFormat(Constant.DATETYPEYMDHMS);// 24小时制  
		//引号里面个格式也可以是 HH:mm:ss或者HH:mm等等，很随意的，不过在主函数调用时，要和输入的变量day格式一致
        Date date = null;   
        try {   
            date = format.parse(day);   
        } catch (Exception ex) {   
            ex.printStackTrace();   
        }   
        if (date == null)   
            return "";   
        System.out.println("front:" + format.format(date)); //显示输入的日期  
        Calendar cal = Calendar.getInstance();   
        cal.setTime(date);   
        cal.add(Calendar.MINUTE, x);// 24小时制   
        date = cal.getTime();   
        System.out.println("after:" + format.format(date));  //显示更新后的日期 
        cal = null;   
        return format.format(date);   
	  
	} 
	
	public static Date addDateOfHourMinu(Date d,Integer hour,Integer minute){
		Calendar cal = Calendar.getInstance();   
        cal.setTime(d);  
        if(hour!=null&&hour>0){
        	cal.add(Calendar.HOUR_OF_DAY, hour);
        }
        if(minute!=null&&minute>0){
        	cal.add(Calendar.MINUTE, minute);// 24小时制   
        }
        Date date = cal.getTime();  
        return date;
	}
	
	/**
	 * 查询某一日期下n个月第一天日期
	 * @param Date
	 * @return
	 * @throws ParseException
	 */
	public static String nextMonthFirstDate(String Date,int n) throws ParseException{
		 // 设置传入的时间格式  
        Date date=transferStr2Date(Date,Constant.DATETYPEYMD);
        //对calendar 设置为 date 所定的日期  
        Calendar calendar=Calendar.getInstance();
		calendar.setTime(date);
	    calendar.set(Calendar.DAY_OF_MONTH,1);
	    calendar.add(Calendar.MONTH,n);
        Date dd1=calendar.getTime();
        return new SimpleDateFormat(Constant.DATETYPEYMD).format(dd1);
	 }
    /**
     * 获取当月第一天
     * @return
     */
	public static String getMonthFirstDay() {
		Calendar c = Calendar.getInstance();    
        c.add(Calendar.MONTH, 0);
        c.set(Calendar.DAY_OF_MONTH,1);//设置为1号,当前日期既为本月第一天 
        String firstDay = format.format(c.getTime());
        System.out.println("-----1------firstDay:"+firstDay);
        return firstDay;
	}
	/**
	 * 获取某一天当月最后一天
	 * @return
	 */
    public static String getMonthlastDay() {
    	Calendar ca = Calendar.getInstance();    
        ca.set(Calendar.DAY_OF_MONTH, ca.getActualMaximum(Calendar.DAY_OF_MONTH));  
        String lastDay = format.format(ca.getTime());
        System.out.println("===============last:"+lastDay);
        return  lastDay;
	}
    
    /**
     * 获取某日的当月第一天
     * @param date
     * @return
     */
    public static String getOneMonthFirstDay(Date date) {
		Calendar c = Calendar.getInstance();   
		c.setTime(date);
        c.set(Calendar.DAY_OF_MONTH,1);//设置为1号,当前日期既为本月第一天 
        String firstDay = format.format(c.getTime());
        System.out.println("-----1------getOneMonthFirstDay:"+firstDay);
        return firstDay;
	}
    /**
     * 获取某日的 当月最后一天
     * @param date
     * @return
     */
    public static String getOneMonthLastDay(Date date) {
    	Calendar c = Calendar.getInstance();   
		c.setTime(date);
		c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));  
        String lastDay = format.format(c.getTime());
        System.out.println("-----1------getOneMonthLastDay:"+lastDay);
        return lastDay;
	}
    
    /**
	 * 获取下一个月最后一天
	 * @return
	 */
    public static String getNextMonthlastDay() {
    	Calendar ca = Calendar.getInstance(); 
    	ca.add(Calendar.MONTH, 1);
        ca.set(Calendar.DAY_OF_MONTH, ca.getActualMaximum(Calendar.DAY_OF_MONTH));  
        String lastDay = format.format(ca.getTime());
        System.out.println("===============next last:"+lastDay);
        return  lastDay;
	}
    /**
	 * 获取日期中的时分秒
	 * @param date
	 * @return
	 */
	public static String getTime(Date date){
		Calendar cal=Calendar.getInstance();
		StringBuilder time=new StringBuilder();
		cal.setTime(date);
		time.append(cal.get(Calendar.HOUR_OF_DAY));
		if(cal.get(Calendar.MINUTE)<10) {
			time.append(":0"+cal.get(Calendar.MINUTE));
		}else {
			time.append(":"+cal.get(Calendar.MINUTE));
		}
		if(cal.get(Calendar.SECOND)<10) {
			time.append(":0"+cal.get(Calendar.SECOND));
		}else {
			time.append(":"+cal.get(Calendar.SECOND));
		}
		return time.toString();
	}

    public static Date concatTime(Date ymd,Date hms) throws Exception{
    	String s = transferDate2Str(ymd, Constant.DATETYPEYMD)+" "+transferDate2Str(hms,Constant.DATETYPEHMS);
    	Date d = transferStr2Date(s, Constant.DATETYPEYMDHMS);
    	return d;
    }
    /**
     * 获取当前季度开始时间
     * @return
     */
    public static String getQuarterFirstDay() {
    	 Calendar startCalendar = Calendar.getInstance();  
         startCalendar.set(Calendar.MONTH, ((int) startCalendar.get(Calendar.MONTH) / 3) * 3);  
         startCalendar.set(Calendar.DAY_OF_MONTH, 1);  
         String day = format.format(startCalendar.getTime());
         System.out.println("===============day:"+day);
         return  day;
    }
    
    /**
     * 获取当前季度结束时间
     * @return
     */
    public static String getQuarterEndDay() {
    	Calendar endCalendar = Calendar.getInstance();  
        endCalendar.set(Calendar.MONTH, ((int) endCalendar.get(Calendar.MONTH) / 3) * 3 + 2);  
        endCalendar.set(Calendar.DAY_OF_MONTH, endCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));  
         String day = format.format(endCalendar.getTime());
         System.out.println("===============day:"+day);
         return  day;
    }

	/**
	 * 获取当年第一天
	 * @return
	 */
	public static String getYearFirstDay() {
    	 Calendar startCalendar = Calendar.getInstance();  
         startCalendar.set(Calendar.MONTH,0);  
         startCalendar.set(Calendar.DAY_OF_MONTH, 1);  
         String day = format.format(startCalendar.getTime());
         System.out.println("===============day:"+day);
         return  day;
    }
	/*public static void main(String[] args) throws Exception {
		Date date1 = transferStr2Date("2018-03-01", "yyyy-MM-dd");
		Date date2 = transferStr2Date("2018-03-02", "yyyy-MM-dd");
	}*/

	/**
	 * 已知秒数如何通过格林威治时间计算出具体的时间
	 * @param time
	 * @return
	 */
	public static String paserTime(int time){
		System.setProperty("user.timezone", "Asia/Shanghai");
		TimeZone tz = TimeZone.getTimeZone("Asia/Shanghai");
		TimeZone.setDefault(tz);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String times = format.format(new Date(time * 1000L));
		System.out.print("日期格式---->" + times);
		return times;
	}
}
