package cn.comshinetechchina.hyjxyl.util;


public class Test {
    public static void main(String[] args){
        String ss="null螨虫,羊肉,花粉,霉菌,";
        System.out.println(ss.replaceAll("null",""));
    }
}
