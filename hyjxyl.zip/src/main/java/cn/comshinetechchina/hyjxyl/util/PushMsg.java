package cn.comshinetechchina.hyjxyl.util;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.gexin.rp.sdk.base.IPushResult;
import com.gexin.rp.sdk.base.IQueryResult;
import com.gexin.rp.sdk.base.ITemplate;
import com.gexin.rp.sdk.base.impl.AppMessage;
import com.gexin.rp.sdk.base.impl.SingleMessage;
import com.gexin.rp.sdk.base.impl.Target;
import com.gexin.rp.sdk.base.payload.APNPayload;
import com.gexin.rp.sdk.exceptions.RequestException;
import com.gexin.rp.sdk.http.IGtPush;
import com.gexin.rp.sdk.template.NotificationTemplate;
import com.gexin.rp.sdk.template.TransmissionTemplate;
import com.gexin.rp.sdk.template.style.Style0;

/**
 * @author Administrator 消息推送工具类1
 */
public class PushMsg {
    final static public int ANDROID = 1;
    final static public int IOS = 2;

    //生产推送
    final static private String ANDROID_Appid = "t6FCVr4lZV603B09Neb51A";
    final static private String ANDROID_Appkey = "dJ43kUf5Ee5EPkI58NFIr1";
    final static private String ANDROID_Master = "jqwq6h8hiT6TyVgqDUHVt1";
    final static private String IOS_Appid = "t6FCVr4lZV603B09Neb51A";
    final static private String IOS_Appkey = "dJ43kUf5Ee5EPkI58NFIr1";
    final static private String IOS_Master = "jqwq6h8hiT6TyVgqDUHVt1";
    // 个推参数
    static String host = "http://sdk.open.api.igexin.com/apiex.htm";
    public static void main(String[] args) {
        try {
            System.out.println(push("测试", "测试推送", "764dff47e0fd8aa09caf0ebd099ecf57", 2));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 推送消息
     * @param title 标题
     * @param text 内容
     * @param sbh 设备号
     * @param sblx 设备类型 1 ios 2安卓
     * @return
     */
    public static String push(String title, String text, String sbh, int sblx) {
        PushParam param = new PushParam();
        param.setCid(sbh);
        param.setTitle(title);
        param.setText(text);
        if (sblx==1) {
            param.setDeviceType(PushMsg.IOS);
            param.setAppid(PushMsg.IOS_Appid);
            param.setAppkey(PushMsg.IOS_Appkey);
            param.setMaster(PushMsg.IOS_Master);
        } else {
            param.setDeviceType(PushMsg.ANDROID);
            param.setAppid(PushMsg.ANDROID_Appid);
            param.setAppkey(PushMsg.ANDROID_Appkey);
            param.setMaster(PushMsg.ANDROID_Master);
        }
        try {
            return oneToOneUser(param).toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 一对一发送
     * @param param
     * @return
     * @throws Exception
     */
    public static Map<String, Object> oneToOneUser(PushParam param)
            throws Exception {
        return oneToOnePushMessage(param.getDeviceType(), param.getAppid(),
                param.getAppkey(), param.getMaster(), param.getCid(),
                param.getTitle(), param.getText(), param.getBadge());
    }



    /**
     * 个人推送
     * @param type  设备类型 1:安卓 2:苹果
     * @param appId   APP的appId
     * @param appkey  APP的appkey
     * @param master   APP的master
     * @param cid  设备号
     * @param title  标题：安卓传标题，苹果传空
     * @param text  内容
     * @param badge   角标
     * @throws Exception
     */
    private static Map<String, Object> oneToOnePushMessage(int type,String appId, String appkey, String master, String cid,
                                                           String title, String text, int badge) throws Exception {
        IGtPush push = new IGtPush(host, appkey, master);
        if(type==2){
            //透传模板
            TransmissionTemplate template = messageIos(appId, appkey, title,text, badge);
            return oneMesgPush(push, template, appId, cid);
        }else if(type==1){
            NotificationTemplate  template= notificationTemplateDemo(appId, appkey, title,text);
            return oneMesgPush(push, template, appId, cid);
        }
        return null;
    }
    /**
     * 透传模板发送
     * @param push
     * @param template
     * @param appId
     */
    private static <T> String transparentTransmission(IGtPush push, T template,String appId) {
        AppMessage message = new AppMessage();
        message.setData((ITemplate) template);
        // 设置消息离线，并设置离线时间
        message.setOffline(true);
        // 离线有效时间，单位为毫秒，可选
        message.setOfflineExpireTime(24 * 1000 * 3600);
        // 设置推送目标条件过滤
        List appIdList = new ArrayList();
        appIdList.add(appId);
        message.setAppIdList(appIdList);
        IPushResult ret = push.pushMessageToApp(message);
        if (ret != null) {
            return ret.getResponse().toString();
        } else {
            return "服务器无响应--透传";
        }
    }

    // Android通知模板
    public static NotificationTemplate notificationTemplateDemo(String appId,String appkey, String title, String text) {
        NotificationTemplate template = new NotificationTemplate();
        // 设置APPID与APPKEY
        template.setAppId(appId);
        template.setAppkey(appkey);
        // 透传消息设置，1为强制启动应用，客户端接收到消息后就会立即启动应用；2为等待应用启动
        template.setTransmissionType(1);
        template.setTransmissionContent(text);
        // 设置定时展示时间
        // template.setDuration("2015-01-16 11:40:00", "2015-01-16 12:24:00");
        Style0 style = new Style0();
        // 设置通知栏标题与内容
        style.setTitle(title);
        style.setText(text);
        // 配置通知栏图标
        style.setLogo("icon.png");
        // 配置通知栏网络图标
        style.setLogoUrl("");
        // 设置通知是否响铃，震动，或者可清除
        style.setRing(true);
        style.setVibrate(true);
        style.setClearable(true);
        template.setStyle(style);
        return template;
    }

    /**
     * 透传消息模板
     * @param appId
     * @param appkey
     * @param title
     * @param text
     * @param badge
     * @return
     */
    public static TransmissionTemplate messageIos(String appId, String appkey,String title, String text, int badge) {
        TransmissionTemplate template = new TransmissionTemplate();
        template.setAppId(appId);
        template.setAppkey(appkey);
        template.setTransmissionContent(text);
        template.setTransmissionType(2);
        APNPayload payload = new APNPayload();
        // 在已有数字基础上加1显示，设置为-1时，在已有数字上减1显示，设置为数字时，显示指定数字
        //payload.setAutoBadge(String.valueOf(badge));
        payload.setAutoBadge("0");
        //payload.setContentAvailable(1);
        payload.setSound("default");
        payload.setCategory("Category");
        // 简单模式APNPayload.SimpleMsg
        // payload.setAlertMsg(new APNPayload.SimpleAlertMsg("hello"));
        // 字典模式使用APNPayload.DictionaryAlertMsg
        payload.setAlertMsg(getDictionaryAlertMsg(title, text));
        // 添加多媒体资源
        /*
         * payload.addMultiMedia(new
         * MultiMedia().setResType(MultiMedia.MediaType.video)
         * .setResUrl("http://ol5mrj259.bkt.clouddn.com/test2.mp4")
         * .setOnlyWifi(true));
         */
        template.setAPNInfo(payload);
        return template;
    }


    /**
     * 个人推送
     * @param push
     * @param template
     * @param appId
     * @param CID
     * @param <T>
     * @return
     * @throws Exception
     */
    private static <T> Map<String, Object> oneMesgPush(IGtPush push,T template, String appId, String CID) throws Exception {
        SingleMessage message = new SingleMessage();
        message.setOffline(true);
        message.setOfflineExpireTime(24 * 3600 * 1000);
        message.setData((ITemplate) template);
        message.setPushNetWorkType(0); // 可选。判断是否客户端是否wifi环境下推送，1为在WIFI环境下，0为不限制网络环境。
        Target target = new Target();
        target.setAppId(appId);
        target.setClientId(CID);
        IPushResult ret = null;
        try {
            ret = push.pushMessageToSingle(message, target);
        } catch (RequestException e) {
            e.printStackTrace();
            ret = push.pushMessageToSingle(message, target, e.getRequestId());
            throw new Exception(e);
        }
        if (ret != null) {
            return ret.getResponse();
        } else {
            return null;
        }
    }


    private static APNPayload.DictionaryAlertMsg getDictionaryAlertMsg(
            String title, String text) {
        APNPayload.DictionaryAlertMsg alertMsg = new APNPayload.DictionaryAlertMsg();
        alertMsg.setBody(text);
        alertMsg.setActionLocKey("ActionLockey");
        alertMsg.setLocKey("LocKey");
        alertMsg.addLocArg("loc-args");
        alertMsg.setLaunchImage("launch-image");
        // iOS8.2以上版本支持
        alertMsg.setTitle(title);
        alertMsg.setTitleLocKey("TitleLocKey");
        alertMsg.addTitleLocArg("TitleLocArg");
        return alertMsg;
    }

    // 获取用户推送状态
    public static IQueryResult getUserStatus(String appkey, String master,String appId, String CID) {
        IGtPush push = new IGtPush(host, appkey, master);
        IQueryResult abc = push.getClientIdStatus(appId, CID);
        return abc;
    }

    // 获取推送结果
    public static IPushResult getReturnMsg(String appkey, String master,String appId, String taskid) {
        IGtPush push = new IGtPush(host, appkey, master);
        IPushResult result = push.getPushResult(taskid);
        return result;
    }

}
