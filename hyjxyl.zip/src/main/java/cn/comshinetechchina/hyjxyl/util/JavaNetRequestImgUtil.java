package cn.comshinetechchina.hyjxyl.util;

import com.alibaba.fastjson.JSONObject;

import javax.imageio.ImageIO;

import java.awt.image.BufferedImage;

import java.io.*;

import java.net.HttpURLConnection;

import java.net.MalformedURLException;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 读取远程文件存储到指定位置
 */
public class JavaNetRequestImgUtil {
    /**
     * 保存远程图片到本地
     * @param remoteUrl 请求图片路径
     * @return
     */
    public static String saveRemoteImg(String remoteUrl,String savePath){
        //输入一个图片网址，将其获取到桌面
        //1.处理网址URL
        //2.通过网址打开网络链接
        //3.判断网络响应
        //4.读取图片文件流
        //5.创建图片存储文件路径，将文件流写进新创建的文件
        JSONObject json=new JSONObject();
        HttpURLConnection connection=null;
        URL url=null;
        try {
            url = new URL(remoteUrl);
            connection=(HttpURLConnection) url.openConnection();
            int code=connection.getResponseCode();
            if(code == 200){  //响应成功
                BufferedImage image=ImageIO.read(connection.getInputStream()); //读取图片文件流
                File file=new File(savePath);
                boolean b=ImageIO.write(image,"png",  file);  //将图片写进创建的路径
                if(b){
                    json.put("success",true);
                    json.put("message","操作成功");
                }else{
                    json.put("success",false);
                    json.put("message","文件写入指定路径出错");
                }
            }else{
                json.put("success",false);
                json.put("message","无法读取文件");
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("操作图片完毕，返回:"+json.toJSONString());
        return json.toJSONString();
    }
    /*public static void main(String [] args){
       String myurl="http://thirdwx.qlogo.cn/mmopen/vi_32/DYAIOgq83eoqg2qibofeWHycszibObXeLkLv1EM6uXMACGCIWymnrCHDz1JOiaudLZXdYk9Y0oKGLv5OibIvxxQmOg/132";
//       String savePath="C:/Users/32322/Desktop/moya.jpeg";  //创建存储图片文件的路径
//       String response=saveRemoteImg(myurl,savePath);
        String uploadPathInDB ="/data";// 获取数据库中配置的文件的上传路径
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd/hh/mm");
        String uploadPathInDisk=uploadPathInDB+"/"+sdf.format(new Date());//文件的上传路径按照日期进行存放
        File folder = new File(uploadPathInDisk);// 创建带日期文件夹
        if (!folder.exists()) {
            folder.mkdirs();
        }
        String fileSavePath=uploadPathInDisk+ "/" + myurl.substring(myurl.lastIndexOf("/")+1,myurl.length());
        System.out.println("保存图片地址为:"+fileSavePath);
    }*/

}
