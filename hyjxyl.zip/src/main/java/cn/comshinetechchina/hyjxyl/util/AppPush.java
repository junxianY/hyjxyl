package cn.comshinetechchina.hyjxyl.util;
import cn.comshinetechchina.hyjxyl.domain.PushMember;
import com.gexin.rp.sdk.base.IPushResult;
import com.gexin.rp.sdk.base.ITemplate;
import com.gexin.rp.sdk.base.impl.AppMessage;
import com.gexin.rp.sdk.base.impl.ListMessage;
import com.gexin.rp.sdk.base.impl.SingleMessage;
import com.gexin.rp.sdk.base.impl.Target;
import com.gexin.rp.sdk.base.payload.APNPayload;
import com.gexin.rp.sdk.exceptions.RequestException;
import com.gexin.rp.sdk.http.IGtPush;
import com.gexin.rp.sdk.template.LinkTemplate;
import com.gexin.rp.sdk.template.TransmissionTemplate;
import com.sun.media.jfxmedia.logging.Logger;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * 个推工具类
 */
public class AppPush {

    //定义常量, appId、appKey、masterSecret 采用本文档 "第二步 获取访问凭证 "中获得的应用配置
    private static String appId = "t6FCVr4lZV603B09Neb51A";
    private static String appKey = "dJ43kUf5Ee5EPkI58NFIr1";
    private static String masterSecret = "jqwq6h8hiT6TyVgqDUHVt1";
    private static String url = "http://sdk.open.api.igexin.com/apiex.htm";

//    public static void main(String[] args) throws IOException {
//        String title="提醒";
//        String text="读书，写字，旅游，约会，做自己感到惬意的事";
//        String time="2018-06-07 11:26:00";
//        List<PushMember> userList=new ArrayList<PushMember>();
//        PushMember member=new PushMember();
//        member.setClientId("1dc28d0dfdf0cf386ee185f1fbf6c3be");
//        userList.add(member);
//        String ss=pushMessage(title,text,userList);
//        System.out.println(ss);
//    }

    /**
     * 发送消息
     * @param title
     * @param text
     * @param userList 推送用户群
     * @return
     */
    public static String pushMessage(String title, String text, List<PushMember> userList){
        IGtPush push = new IGtPush(url, appKey, masterSecret);

        // 定义"点击链接打开通知模板"，并设置标题、内容、链接
        LinkTemplate template = new LinkTemplate();
        template.setAppId(appId);
        template.setAppkey(appKey);
        template.setTitle(title);
        template.setText(text);
        template.setUrl("http://getui.com");
        //响铃、震动、可清除
        template.setIsRing(true);
        template.setIsVibrate(true);
        template.setIsClearable(true);

        List<String> appIds = new ArrayList<String>();
        appIds.add(appId);

        // 定义"AppMessage"类型消息对象，设置消息内容模板、发送的目标App列表、是否支持离线发送、以及离线消息有效期(单位毫秒)
        ListMessage message = new ListMessage();
        message.setData(template);
        message.setOffline(true); //用户当前不在线时，是否离线存储，可选，默认不存储
        message.setOfflineExpireTime(1000 * 600);  //离线有效时间，单位为毫秒，可选
        List<Target> targets = new ArrayList<Target>();
        //iphone用户
        List<String> phoneUserList=new ArrayList<String>();
        if(userList!=null&&userList.size()>0){
         for(PushMember member:userList){
             if(member.getPhoneType()==2){
                 Target target = new Target();
                 target.setAppId(appId);
                 target.setClientId(member.getClientId());
                 targets.add(target);
             }else if(member.getPhoneType()==1){
                 phoneUserList.add(member.getClientId());
             }
         }
        }

        // 获取taskID
        String taskId = push.getContentId(message);
        // 使用taskID对目标进行推送
        IPushResult ret = push.pushMessageToList(taskId, targets);
        //ios消息推送
        if(!phoneUserList.isEmpty()){
          String res=apnpush(title,text,phoneUserList);
          System.out.println("ios推送结果为:"+res);
        }
        return ret.getResponse().toString();
    }

    /**
     * iso透传消息发送
     * @param title 标题
     * @param content 内容
     * @param userList
     * @return
     */
    public static String apnpush(String title, String content,List<String> userList) {
        IGtPush push = new IGtPush(url, appKey, masterSecret);
        TransmissionTemplate template = new TransmissionTemplate();
        template.setAppId(appId);
        template.setAppkey(appKey);
        template.setTransmissionContent(content);
        template.setTransmissionType(2);
        APNPayload payload = new APNPayload();
        payload.setAutoBadge("0");
        payload.setContentAvailable(1);
        payload.setSound("default");
        payload.setCategory("Category");
        payload.setAlertMsg(getDictionaryAlertMsg(title, content));
        // payload.setCategory("$由客户端定义");
        //payload.setAlertMsg(new APNPayload.SimpleAlertMsg(content));
         template.setAPNInfo(payload);
//         ListMessage message = new ListMessage();
//         message.setData(template);
//         // 设置消息离线，并设置离线时间
//         message.setOffline(true);
//        // 离线有效时间，单位为毫秒，可选
//        message.setOfflineExpireTime(24 * 1000 * 3600);
//        String contentId = push.getAPNContentId(appId, message);
//        System.out.println(contentId);
//        System.setProperty("gexin.rp.sdk.pushlist.needDetails", "true");
        //IPushResult ret = push.pushAPNMessageToList(appId, contentId, userList);
        SingleMessage message = new SingleMessage();
        message.setOffline(true);
        message.setOfflineExpireTime(24 * 3600 * 1000);
        message.setData(template);
        message.setPushNetWorkType(0); // 可选。判断是否客户端是否wifi环境下推送，1为在WIFI环境下，0为不限制网络环境。
        Target target = new Target();
        target.setAppId(appId);
        int i=0;
        if(userList!=null&&userList.size()>0){
            for(String clientId:userList){
                target.setClientId(clientId);
                IPushResult ret = push.pushMessageToSingle(message, target);
                System.out.println(ret.getResponse());
                //{result=ok, taskId=OSS-1101_f4637f17e126106ff4578e72c9c68414, status=successed_offline}
                if(ret.getResponse()!=null&&ret.getResponse().get("result")!=null&&ret.getResponse().get("result").toString().equals("ok")){
                  i++;
                }
            }
        }
        return "成功条数："+i;
    }

    /**
     * 设置消息提醒模式
     * @param title
     * @param text
     * @return
     */
    private static APNPayload.DictionaryAlertMsg getDictionaryAlertMsg(
            String title, String text) {
        APNPayload.DictionaryAlertMsg alertMsg = new APNPayload.DictionaryAlertMsg();
        alertMsg.setBody(text);
        alertMsg.setActionLocKey("ActionLockey");
        alertMsg.setLocKey("LocKey");
        alertMsg.addLocArg("loc-args");
        alertMsg.setLaunchImage("launch-image");
        // iOS8.2以上版本支持
        alertMsg.setTitle(title);
        alertMsg.setTitleLocKey("TitleLocKey");
        alertMsg.addTitleLocArg("TitleLocArg");
        return alertMsg;
    }
}
