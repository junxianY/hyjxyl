package cn.comshinetechchina.hyjxyl.util;

/**
 * 消息推送
 */
public class PushParam {

    private int deviceType;// 设备类型

    private String appkey;

    private String appid;// appid

    private String master;

    private String title;//推送显示标题

    private String text;//推送显示内容

    private int badge;//ios图标个数展示

    private String cid;//手机设备号









    public String getCid() {

        return cid;

    }



    public void setCid(String cid) {

        this.cid = cid;

    }



    public String getAppkey() {

        return appkey;

    }



    public void setAppkey(String appkey) {

        this.appkey = appkey;

    }



    public int getDeviceType() {

        return deviceType;

    }



    public void setDeviceType(int deviceType) {

        this.deviceType = deviceType;

    }



    public String getAppid() {

        return appid;

    }



    public void setAppid(String appid) {

        this.appid = appid;

    }



    public String getMaster() {

        return master;

    }



    public void setMaster(String master) {

        this.master = master;

    }



    public String getTitle() {

        return title;

    }



    public void setTitle(String title) {

        this.title = title;

    }



    public String getText() {

        return text;

    }



    public void setText(String text) {

        this.text = text;

    }



    public int getBadge() {

        return badge;

    }



    public void setBadge(int badge) {

        this.badge = badge;

    }





}
