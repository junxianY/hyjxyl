package cn.comshinetechchina.hyjxyl.util;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import cn.comshinetechchina.hyjxyl.filter.TokenState;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import net.minidev.json.JSONObject;

import javax.xml.bind.DatatypeConverter;

public class JwtUtil {

    /**
     * 秘钥
     */
    private static final byte[] SECRET="3d990d2276917dfac04467df11fff26d".getBytes();

    /**
     * 初始化head部分的数据为
     * {
     * 		"alg":"HS256",
     * 		"type":"JWT"
     * }
     */
    private static final JWSHeader header=new JWSHeader(JWSAlgorithm.HS256, JOSEObjectType.JWT, null, null, null, null, null, null, null, null, null, null, null);

    /**
     * 生成token，该方法只在用户登录成功后调用
     *
     * @param payload 集合，可以存储用户id，token生成时间，token过期时间等自定义字段
     * @return token字符串,若失败则返回null
     */
    public static String createToken(Map<String, Object> payload) {
        String tokenString=null;
        // 创建一个 JWS object
        JWSObject jwsObject = new JWSObject(header, new Payload(new JSONObject(payload)));
        try {
            // 将jwsObject 进行HMAC签名
            jwsObject.sign(new MACSigner(SECRET));
            tokenString=jwsObject.serialize();
        } catch (JOSEException e) {
            System.err.println("签名失败:" + e.getMessage());
            e.printStackTrace();
        }
        return tokenString;
    }



    /**
     * 校验token是否合法，返回Map集合,集合中主要包含    state状态码   data鉴权成功后从token中提取的数据
     * 该方法在过滤器中调用，每次请求API时都校验
     * @param token
     * @return  Map<String, Object>
     */
    public static Map<String, Object> validToken(String token) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            JWSObject jwsObject = JWSObject.parse(token);
            Payload payload = jwsObject.getPayload();
            JWSVerifier verifier = new MACVerifier(SECRET);

            if (jwsObject.verify(verifier)) {
                JSONObject jsonOBj = payload.toJSONObject();
                // token校验成功（此时没有校验是否过期）
                resultMap.put("state", TokenState.VALID.toString());
                // 若payload包含ext字段，则校验是否过期
                if (jsonOBj.containsKey("ext")) {
                    long extTime = Long.valueOf(jsonOBj.get("ext").toString());
                    long curTime = new Date().getTime();
                    // 过期了
                    if (curTime > extTime) {
                        resultMap.clear();
                        resultMap.put("state", TokenState.EXPIRED.toString());
                    }
                }
                resultMap.put("data", jsonOBj);

            } else {
                // 校验失败
                resultMap.put("state", TokenState.INVALID.toString());
            }

        } catch (Exception e) {
            //e.printStackTrace();
            // token格式不合法导致的异常
            resultMap.clear();
            resultMap.put("state", TokenState.INVALID.toString());
        }
        return resultMap;
    }

    /**
     * 解析后台token 获取用户id、租户id、角色id、用户名
     * @param token
     * @return
     * @throws ParseException
     */
  public static Map<String, Object> parseManagementToken(String token) throws ParseException {
      Map<String, Object> resultMap = new HashMap<String, Object>();
      Claims claims = Jwts.parser()
              .setSigningKey(SECRET)
              .parseClaimsJws(token).getBody();
      resultMap.put("uid",claims.get("uid"));
      resultMap.put("tenantId",claims.get("tenantId"));
      resultMap.put("roleId",claims.get("roleId"));
      resultMap.put("userName",claims.get("userName"));
      return resultMap;
  }

    /**
     * 解析app端token
     * @param token
     * @return
     * @throws ParseException
     */
    public static Map<String, Object> parseAppToken(String token) throws ParseException {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        Claims claims = Jwts.parser()
                .setSigningKey(SECRET)
                .parseClaimsJws(token).getBody();
        resultMap.put("memberId",claims.get("uid"));
        return resultMap;
    }

//    public static void main(String[] args) throws Exception {
//        String token="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHQiOjE1MjYzNzUxNDQ4OTcsInRlbmFudElkIjoiMTExMTEiLCJ1aWQiOiIxMTExIiwiaWF0IjoxNTI2MzczMzQ0ODk3LCJyb2xlSWQiOjF9.00D7DHE_G3nhEUtkHl35e2l83NcfTORlc3RO6OF5YNU";
//        Claims claims = Jwts.parser()
//                .setSigningKey(SECRET)
//                .parseClaimsJws(token).getBody();
//        System.out.println("uid: " + claims.get("uid"));
//        System.out.println("tenantId: " + claims.get("tenantId"));
//        System.out.println("roleId: " + claims.get("roleId"));
//    }

}
