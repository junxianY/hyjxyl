package cn.comshinetechchina.hyjxyl.util;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.Charset;

public class HttpAccessUtil {
    private static final Logger log = LoggerFactory.getLogger(HttpAccessUtil.class);
    /**
     * 发送httpclient post请求
     * @param url
     * @param param
     * @return
     */
    @SuppressWarnings("deprecation")
    public static String sendPost(String url, String param) {
        log.info("httpClient发送请求参数param："+param);
        final String CONTENT_TYPE_TEXT_JSON = "text/json";
        DefaultHttpClient client = new DefaultHttpClient(new PoolingClientConnectionManager());
        String result = "";
        try {
            HttpPost httpPost = new HttpPost(url);
            httpPost.addHeader("Content-Type", "application/json;charset=UTF-8");
            httpPost.setHeader("Accept", "application/json");
            if (param!=null&&!"".equals(param)) {
//				StringEntity se = new StringEntity(param);
//				se.setContentType(CONTENT_TYPE_TEXT_JSON);
//				httpPost.setEntity(se);
                httpPost.setEntity(new StringEntity(param, Charset.forName("UTF-8")));
            }
            CloseableHttpResponse response2 = null;
            response2 = client.execute(httpPost);
            HttpEntity entity2 = null;
            if (response2 != null) {
                entity2 = response2.getEntity();
            }
            result = EntityUtils.toString(entity2, "UTF-8");
            log.info("请求返回结果:" + result);
        } catch (Exception e) {
            log.info("发送POST请求出现异常:" + e.getMessage());
            e.printStackTrace();
        }
        return result;
    }
}
