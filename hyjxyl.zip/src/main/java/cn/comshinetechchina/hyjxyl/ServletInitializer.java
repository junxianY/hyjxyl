package cn.comshinetechchina.hyjxyl;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan
public class ServletInitializer  extends SpringBootServletInitializer {
    protected SpringApplicationBuilder Configure(SpringApplicationBuilder application) {
        return application.sources(HyjxylApplication.class);
     }
}
