package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.Point;

/**
 * 积分服务接口
 */
public interface PointService {
    int deleteByPrimaryKey(String memberId);
    int insertSelective(Point record);
    Point selectByPrimaryKey(String memberId);
    int updateByPrimaryKeySelective(Point record);

    /**
     * 公用增加积分接口
     * @param memberId
     * @param type 1.完善个人资料 2.完善健康信息 3.添加病例体检信息 4.阅读活动资讯
     * @param age type=1使用
     * @param articleId type=4使用
     * @return
     */
    int savePointInfo(String memberId,int type,int age,String articleId);
}
