package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.CheckData;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 规则工具类
 */
public class RuleUtil {
    /**
     * 过滤检测空消息
     * @param list
     * @param type 1:体重 2:血糖 3:血氧 4：血压\脉搏 5：血脂 6：尿酸 7体脂 8心率
     * @return
     */
    public static List<CheckData> filterData(List<CheckData> list,Integer type){
        Iterator<CheckData> iter=list.iterator();
        while(iter.hasNext()){
            CheckData data=iter.next();
            if (type == 1) {
             if(data.getWeight()==0){
                 iter.remove();
             }
            } else if (type == 2) {
             if(data.getBloodSugar()==0){
                 iter.remove();
             }
            } else if (type == 3) {
                if(data.getOxygenSaturation()==0){
                    iter.remove();
                }
            } else if (type == 4) {
                if(data.getLowPressure()==0&&data.getHeightPressure()==0&&data.getPulse()==0){
                    iter.remove();
                }
            } else if (type == 5) {
                if(data.getTotalCholesterol()==0&&data.getTriglycerides()==0&&data.getHeightLipoprotein()==0&&data.getLowLipoprotein()==0){
                    iter.remove();
                }
            } else if (type == 6) {
                if(data.getUricAcid()==0){
                    iter.remove();
                }
            } else if (type == 7) {
                if(data.getFatRate()==0&&data.getWaterRate()==0){
                    iter.remove();
                }
            } else if (type == 8) {
                if(data.getEcgRate()==0){
                    iter.remove();
                }
            }
        }
        System.out.println("过滤后list大小："+list.size());
        return list;
    }

    /**
     * 通过检测数据返回健康提醒推送数据
     * @param data
     * @param name 用户名
     * @return
     */
    public static List<String> checkPushMessage(CheckData data,String name){
        List<String> list=new ArrayList<>();
        String message1="";
        String message2="";
       /*  一项有问题
        1.健康提醒：
        您的【检测项】检测值有些异常哦，请点击查看详情。
        2.健康提醒：
        您关注的【有备注显示备注，无备注显示人名】【检测项】检测值有些异常哦，请点击查看详情。
        多项：
        1.健康提醒：
        您的健康检测值有些异常哦，请点击查看详情。
        2.健康提醒：
        您关注的【有备注显示备注，无备注显示人名】健康检测值有些异常哦，请点击查看详情。*/
       int count=0;
       String item="";
       if(data.getWeightState()!=3){
           count++;
           item="体重";
       }
       if(data.getBloodSugarState()!=3){
            count++;
            item="血糖";
       }
        if(data.getOxygenSaturationState()!=3){
            count++;
            item="血氧";
        }
        if(data.getLowPressureState()!=3&&data.getHeightPressureState()!=3||data.getPulseState()!=3){
            count++;
            item="血压";
        }
        if(data.getTotalCholesterolState()!=3||data.getTriglyceridesState()!=3||data.getHeightLipoproteinState()!=3||data.getLowLipoproteinState()!=3){
            count++;
            item="血脂";
        }
        if(data.getUricAcidState()!=3){
            count++;
            item="尿液";
        }
        if(data.getFatRateState()!=3||data.getWaterRateState()!=3){
            count++;
            item="体脂";
        }
        if(data.getEcgRateState()!=3){
            count++;
            item="心率";
        }
        if(count==0){
           return null;
        }else if(count==1){
            message1="您的"+item+"检测值有些异常哦，请点击查看详情。";
            message2="您关注的"+name+item+"检测值有些异常哦，请点击查看详情。";
        }else{
            message1="您的健康检测值有些异常哦，请点击查看详情。";
            message2="您关注的"+name+"健康检测值有些异常哦，请点击查看详情。";
        }
       list.add(message1);
       list.add(message2);
       return list;
    }
}
