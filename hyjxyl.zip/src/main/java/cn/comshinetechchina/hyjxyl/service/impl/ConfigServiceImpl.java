package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.ConfigDao;
import cn.comshinetechchina.hyjxyl.domain.Config;
import cn.comshinetechchina.hyjxyl.service.ConfigService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service("configService")
public class ConfigServiceImpl implements ConfigService {
    @Resource
    private ConfigDao configDao;
    @Override
    public List<Config> selectConfigList(String code, int isActive) {
        return configDao.selectConfigList(code,isActive);
    }
}
