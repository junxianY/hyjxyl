package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.CityDao;
import cn.comshinetechchina.hyjxyl.domain.City;
import cn.comshinetechchina.hyjxyl.service.CityService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service("cityService")
public class CityServiceImpl implements CityService {
    @Resource
    private CityDao cityDao;
    @Override
    public List<City> selectCityList(String provinceId) {
        return cityDao.selectCityList(provinceId);
    }
}
