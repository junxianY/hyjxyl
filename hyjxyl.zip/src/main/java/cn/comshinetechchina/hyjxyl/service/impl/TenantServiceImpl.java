package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.TenantDao;
import cn.comshinetechchina.hyjxyl.domain.Tenant;
import cn.comshinetechchina.hyjxyl.service.TenantService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("tenantService")
public class TenantServiceImpl implements TenantService {
    @Resource
    private TenantDao tenantDao;
    @Override
    public int insertSelective(Tenant record) {
        return tenantDao.insertSelective(record);
    }

    @Override
    public Tenant selectByPrimaryKey(String tenantId) {
        return tenantDao.selectByPrimaryKey(tenantId);
    }

    @Override
    public int updateByPrimaryKeySelective(Tenant record) {
        return tenantDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public int deleteByPrimaryKey(String tenantId) {
        return tenantDao.deleteByPrimaryKey(tenantId);
    }

    @Override
    public List<Tenant> selectTenantList(Map<String, Object> map) {
        return this.tenantDao.selectTenantList(map);
    }
}
