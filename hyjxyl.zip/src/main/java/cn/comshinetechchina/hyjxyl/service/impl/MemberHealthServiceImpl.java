package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.MemberHealthDao;
import cn.comshinetechchina.hyjxyl.domain.MemberHealth;
import cn.comshinetechchina.hyjxyl.service.MemberHealthService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
@Service("memberHealthService")
public class MemberHealthServiceImpl implements MemberHealthService {
    @Resource
    private MemberHealthDao memberHealthDao;
    @Override
    public int insertSelective(MemberHealth record) {
        return memberHealthDao.insertSelective(record);
    }

    @Override
    public MemberHealth selectByPrimaryKey(String healthId) {
        return memberHealthDao.selectByPrimaryKey(healthId);
    }

    @Override
    public int updateByPrimaryKeySelective(MemberHealth record) {
        return memberHealthDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public MemberHealth selectMemberHealthInfo(String memberId) {
        return memberHealthDao.selectMemberHealthInfo(memberId);
    }
}
