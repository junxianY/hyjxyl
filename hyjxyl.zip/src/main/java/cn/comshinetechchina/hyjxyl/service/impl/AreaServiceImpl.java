package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.AreaDao;
import cn.comshinetechchina.hyjxyl.domain.Area;
import cn.comshinetechchina.hyjxyl.domain.PcaObj2;
import cn.comshinetechchina.hyjxyl.service.AreaService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service("areaService")
public class AreaServiceImpl implements AreaService {
    @Resource
    private AreaDao areaDao;
    @Override
    public List<Area> selectAreaList(String cityId) {
        return areaDao.selectAreaList(cityId);
    }

    @Override
    public List<PcaObj2> selectPcaObj2List(String cityId) {
        return areaDao.selectPcaObj2List(cityId);
    }
}
