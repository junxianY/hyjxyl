package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.ContentType;

public interface ContentTypeService{
    /**
     * 查询附件类型
     * @param typeCode
     * @param isActive
     * @return
     */
    public ContentType selectOneContentType(String typeCode, int isActive);
}
