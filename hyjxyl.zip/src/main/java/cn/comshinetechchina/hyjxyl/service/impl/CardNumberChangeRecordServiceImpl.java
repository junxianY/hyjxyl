package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.CardNumberChangeRecordDao;
import cn.comshinetechchina.hyjxyl.domain.CardNumberChangeRecord;
import cn.comshinetechchina.hyjxyl.service.CardNumberChangeRecordService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("cardNumberChangeRecordService")
public class CardNumberChangeRecordServiceImpl implements CardNumberChangeRecordService {
    @Resource
    private CardNumberChangeRecordDao cardNumberChangeRecordDao;

    @Override
    public int insertSelective(CardNumberChangeRecord record) {
        return cardNumberChangeRecordDao.insertSelective(record);
    }

    @Override
    public List<CardNumberChangeRecord> selectChangeRecordList(String cardNo, String serviceId) {
        return cardNumberChangeRecordDao.selectChangeRecordList(cardNo,serviceId);
    }
}
