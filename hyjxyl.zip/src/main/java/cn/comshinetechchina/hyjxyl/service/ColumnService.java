package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.Column;

import java.util.List;
import java.util.Map;

public interface ColumnService {
    int deleteByPrimaryKey(Integer columnId);
    int insertSelective(Column record);
    Column selectByPrimaryKey(Integer columnId);
    int updateByPrimaryKeySelective(Column record);
    public List<Column> queryColumnList(Map<String,String> map);
}
