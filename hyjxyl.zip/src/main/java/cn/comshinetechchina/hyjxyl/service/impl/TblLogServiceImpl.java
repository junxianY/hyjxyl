package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.TblLogDao;
import cn.comshinetechchina.hyjxyl.domain.TblLog;
import cn.comshinetechchina.hyjxyl.domain.TblLogObj;
import cn.comshinetechchina.hyjxyl.service.TblLogService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;

@Service("tblLogService")
public class TblLogServiceImpl implements TblLogService {
    @Resource
    private TblLogDao tblLogDao;
    @Override
    public int insertSelective(TblLog record) {
        return tblLogDao.insertSelective(record);
    }

    @Override
    public List<TblLogObj> selectLogList(String memberId, Integer type,PageBean page) {
        return this.tblLogDao.selectLogList(memberId,type,page);
    }
}
