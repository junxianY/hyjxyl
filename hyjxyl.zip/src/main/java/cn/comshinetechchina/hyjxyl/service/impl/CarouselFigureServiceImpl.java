package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.CarouselFigureDao;
import cn.comshinetechchina.hyjxyl.domain.ArticleObj;
import cn.comshinetechchina.hyjxyl.domain.CarouselFigure;
import cn.comshinetechchina.hyjxyl.domain.CarouselFigureObj;
import cn.comshinetechchina.hyjxyl.service.CarouselFigureService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("carouselFigureService")
public class CarouselFigureServiceImpl implements CarouselFigureService {
    @Resource
    private CarouselFigureDao carouselFigureDao;
    @Override
    public List<CarouselFigureObj> selectCarouselFigureList(PageBean page, Map<String, Object> map) {
        return carouselFigureDao.selectCarouselFigureList(page,map);
    }

    @Override
    public int insertSelective(CarouselFigure record) {
        return carouselFigureDao.insertSelective(record);
    }

    @Override
    public CarouselFigure selectByPrimaryKey(String id) {
        return carouselFigureDao.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKeySelective(CarouselFigure record) {
        return carouselFigureDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<CarouselFigureObj> selectRandom5Articles() {
        return this.carouselFigureDao.selectRandom5Articles();
    }

    @Override
    public List<ArticleObj> queryAvailableArticles(PageBean page,Map<String, Object> map) {
        return this.carouselFigureDao.queryAvailableArticles(page,map);
    }

    @Override
    public CarouselFigure selectOneCarouselFigure(String articleId, int available) {
        return this.carouselFigureDao.selectOneCarouselFigure(articleId,available);
    }

    @Override
    public CarouselFigure selectOneCarouselFigureByOrder(Integer orderNo) {
        return carouselFigureDao.selectOneCarouselFigureByOrder(orderNo);
    }
}
