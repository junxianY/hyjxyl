package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.TblServiceDao;
import cn.comshinetechchina.hyjxyl.domain.TblService;
import cn.comshinetechchina.hyjxyl.service.TblServiceService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("tblServiceService")
public class TblServiceServiceImpl implements TblServiceService {
    @Resource
    private TblServiceDao tblServiceDao;
    @Override
    public int insertSelective(TblService record) {
        return tblServiceDao.insertSelective(record);
    }

    @Override
    public TblService selectByPrimaryKey(String serviceId) {
        return tblServiceDao.selectByPrimaryKey(serviceId);
    }

    @Override
    public int updateByPrimaryKeySelective(TblService record) {
        return tblServiceDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public int deleteByPrimaryKey(String serviceId) {
        return this.tblServiceDao.deleteByPrimaryKey(serviceId);
    }

    @Override
    public List<TblService> queryServiceList(Map<String, String> map) {
        return this.tblServiceDao.queryServiceList(map);
    }
}
