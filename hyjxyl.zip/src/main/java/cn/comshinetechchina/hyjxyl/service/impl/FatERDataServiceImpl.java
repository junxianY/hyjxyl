package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.dao.FatERDataDao;
import cn.comshinetechchina.hyjxyl.domain.BloodOxygenData;
import cn.comshinetechchina.hyjxyl.domain.FatERData;
import cn.comshinetechchina.hyjxyl.service.FatERDataService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service("fatERDataService")
public class FatERDataServiceImpl implements FatERDataService {
    private Logger log= LoggerFactory.getLogger(FatERDataServiceImpl.class);
    @Resource
    private FatERDataDao fatERDataDao;

    @Override
    public List<FatERData> selectFatERDataList(PageBean page, Map<String, Object> map) {
        return fatERDataDao.selectFatERDataList(page,map);
    }

    @Override
    public String packageChartData(List<FatERData> list) {
        JSONObject json=new JSONObject();
        //横坐标数据
        JSONObject xAxis=new JSONObject();
        xAxis.put("type","category");
        xAxis.put("boundaryGap",false);
        List<String> xList=new ArrayList<String>();
        List<String> yList=new ArrayList<String>();
        try {
            if (list != null && list.size() > 0) {
                for (FatERData data : list) {
                    if(data.getRt()!=null){
                        xList.add(DateUtil.transferDate2Str(data.getRt(), "yyyy-MM-dd"));
                        if(data.getResistor()>=0){
                            yList.add(String.valueOf(data.getResistor()));
                        }else{
                            yList.add("");
                        }

                    }
                }
            }
        }catch(ParseException ex){
            throw new ServiceException("强转出错",ex);
        }
        xAxis.put("data",xList);
        //纵坐标数据
        JSONObject series=new JSONObject();
        series.put("name","电阻值");
        series.put("type","line");
        series.put("data",yList);
        json.put("xAxis",xAxis);
        json.put("series",series);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
