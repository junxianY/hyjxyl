package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.LocationDao;
import cn.comshinetechchina.hyjxyl.domain.Location;
import cn.comshinetechchina.hyjxyl.service.LocationService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
@Service("locationService")
public class LocationServiceImpl implements LocationService {
    @Resource
    private LocationDao locationDao;
    @Override
    public List<Location> selectLocationList(PageBean page, Map<String, Object> map) {
        return locationDao.selectLocationList(page,map);
    }

    @Override
    public int insertSelective(Location record) {
        return this.locationDao.insertSelective(record);
    }

    @Override
    public Location selectByPrimaryKey(String locationId) {
        return this.locationDao.selectByPrimaryKey(locationId);
    }
}
