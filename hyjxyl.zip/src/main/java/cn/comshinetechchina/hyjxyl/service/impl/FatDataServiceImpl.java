package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.dao.FatDataDao;
import cn.comshinetechchina.hyjxyl.domain.BloodOxygenData;
import cn.comshinetechchina.hyjxyl.domain.FatData;
import cn.comshinetechchina.hyjxyl.service.FatDataService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
@Service("fatDataService")
public class FatDataServiceImpl implements FatDataService {
    @Resource
    private FatDataDao fatDataDao;
    @Override
    public List<FatData> selectFatDataList(PageBean page, Map<String, Object> map) {
        return fatDataDao.selectFatDataList(page,map);
    }

    @Override
    public String packageChartData(List<FatData> list) {
        JSONObject json=new JSONObject();
        //横坐标数据
        JSONObject xAxis=new JSONObject();
        xAxis.put("type","category");
        xAxis.put("boundaryGap",false);
        List<String> xList=new ArrayList<String>();
        //脂肪含量
        List<String> yList1=new ArrayList<String>();
        //基础代谢值 单位kcal/日
        List<String> yList2=new ArrayList<String>();
        //体脂结果 1偏低2标准3偏高4高
        List<String> yList3=new ArrayList<String>();
        try {
            if (list != null && list.size() > 0) {
                for (FatData data : list) {
                    if(data.getRt()!=null){
                        xList.add(DateUtil.transferDate2Str(data.getRt(), "yyyy-MM-dd"));
                        if(data.getFc()>=0){
                            yList1.add(String.valueOf(data.getFc()));
                        }else{
                            yList1.add("");
                        }
                        if(data.getBmr()>=0){
                            yList2.add(String.valueOf(data.getBmr()));
                        }else{
                            yList2.add("");
                        }
                        if(data.getBmir()>=0){
                            yList3.add(String.valueOf(data.getBmir()));
                        }else{
                            yList3.add("");
                        }
                    }
                }
            }
        }catch(ParseException ex){
            throw new ServiceException("强转出错",ex);
        }
        //横坐标数据
        xAxis.put("data",xList);
        //纵坐标数据
        JSONObject series1=new JSONObject();
        series1.put("name","脂肪含量");
        series1.put("type","line");
        series1.put("data",yList1);
        JSONObject series2=new JSONObject();
        series2.put("name","基础代谢值");
        series2.put("type","line");
        series2.put("data",yList2);
        JSONObject series3=new JSONObject();
        series3.put("name","体脂结果");
        series3.put("type","line");
        series3.put("data",yList3);
        List<JSONObject> arrayList=new ArrayList<JSONObject>();
        arrayList.add(series1);
        arrayList.add(series2);
        arrayList.add(series3);
        json.put("xAxis",xAxis);
        json.put("series",arrayList);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    @Override
    public List<FatData> selectFatDataList(String memberId) {
        return this.fatDataDao.selectFatDataList(memberId);
    }
}
