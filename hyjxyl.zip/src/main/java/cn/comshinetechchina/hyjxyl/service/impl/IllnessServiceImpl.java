package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.IllnessDao;
import cn.comshinetechchina.hyjxyl.domain.Illness;
import cn.comshinetechchina.hyjxyl.domain.IllnessObj;
import cn.comshinetechchina.hyjxyl.service.IllnessService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("illnessService")
public class IllnessServiceImpl implements IllnessService {
    @Resource
    private IllnessDao illnessDao;
    @Override
    public int insertSelective(Illness record) {
        return illnessDao.insertSelective(record);
    }

    @Override
    public Illness selectByPrimaryKey(String illnessId) {
        return illnessDao.selectByPrimaryKey(illnessId);
    }

    @Override
    public int updateByPrimaryKeySelective(Illness record) {
        return illnessDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<IllnessObj> getIllnessList(Map<String, Object> map, PageBean bean) {
        return this.illnessDao.getIllnessList(map,bean);
    }

    @Override
    public IllnessObj selectOneIllness(String illnessId) {
        return this.illnessDao.selectOneIllness(illnessId);
    }

    @Override
    public int deleteByPrimaryKey(String illnessId) {
        return this.illnessDao.deleteByPrimaryKey(illnessId);
    }
}
