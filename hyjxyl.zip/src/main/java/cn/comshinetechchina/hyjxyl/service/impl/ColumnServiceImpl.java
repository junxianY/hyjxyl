package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.ColumnDao;
import cn.comshinetechchina.hyjxyl.domain.Column;
import cn.comshinetechchina.hyjxyl.service.ColumnService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
@Service("columnService")
public class ColumnServiceImpl implements ColumnService {
    @Resource
    private ColumnDao columnDao;
    @Override
    public int deleteByPrimaryKey(Integer columnId) {
        return columnDao.deleteByPrimaryKey(columnId);
    }

    @Override
    public int insertSelective(Column record) {
        return columnDao.insertSelective(record);
    }

    @Override
    public Column selectByPrimaryKey(Integer columnId) {
        return columnDao.selectByPrimaryKey(columnId);
    }

    @Override
    public int updateByPrimaryKeySelective(Column record) {
        return columnDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<Column> queryColumnList(Map<String, String> map) {
        return columnDao.queryColumnList(map);
    }
}
