package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.DeviceDao;
import cn.comshinetechchina.hyjxyl.domain.Device;
import cn.comshinetechchina.hyjxyl.service.DeviceService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("deviceService")
public class DeviceServiceImpl implements DeviceService {
    @Resource
    private DeviceDao deviceDao;
    @Override
    public int deleteByPrimaryKey(String deviceId) {
        return deviceDao.deleteByPrimaryKey(deviceId);
    }

    @Override
    public int insertSelective(Device record) {
        return deviceDao.insertSelective(record);
    }

    @Override
    public Device selectByPrimaryKey(String deviceId) {
        return deviceDao.selectByPrimaryKey(deviceId);
    }

    @Override
    public int updateByPrimaryKeySelective(Device record) {
        return deviceDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<Device> selectDeviceList(String deviceNO, String tenantId, String serviceId, int available) {
        return this.deviceDao.selectDeviceList(deviceNO,tenantId,serviceId,available);
    }

    @Override
    public List<Device> selectPageDeviceList(Map<String, Object> map, PageBean bean) {
        return deviceDao.selectPageDeviceList(map,bean);
    }
}
