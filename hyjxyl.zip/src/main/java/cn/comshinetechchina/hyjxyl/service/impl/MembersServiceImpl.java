package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.MembersDao;
import cn.comshinetechchina.hyjxyl.dao.TblLogDao;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.MembersService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service("membersServiceImpl")
public class MembersServiceImpl implements MembersService {
    @Resource
    private MembersDao membersDao;
    @Resource
    private TblLogDao logDao;
    @Override
    public Members selectOneMembers(String phoneNo,String token) {
        return membersDao.selectOneMembers(phoneNo,token);
    }

    @Override
    public int insertSelective(Members record) {
        return membersDao.insertSelective(record);
    }

    @Override
    public int updateByPrimaryKeySelective(Members record) {
        return membersDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public Members selectByPrimaryKey(String memberId) {
        return this.membersDao.selectByPrimaryKey(memberId);
    }

    @Override
    public List<MemberInfo> selectMemberInfoList(Map<String, String> map,PageBean bean) {
        return this.membersDao.selectMemberInfoList(map,bean);
    }

    @Override
    public MemberInfo selectMemberInfoDetail(String memberId) {
        return this.membersDao.selectMemberInfoDetail(memberId);
    }

    @Override
    public int batchUpdateMemberStatus(List<String> memberIds, int available, String remark, String userId, String userName) {
        int i=this.membersDao.batchUpdateMemberStatus(memberIds,available);
        if(i>0){
            //插入用户操作日志表
            for(String memberId:memberIds){
                TblLog record=new TblLog();
                record.setLogId(UUID.randomUUID().toString());
                record.setOperateTime(new Date());
                record.setOperateContent("修改用户是否有效状态为"+available);
                record.setOperateTableId(memberId);
                record.setOperateTableName("tbl_members");
                record.setUserId(userId);
                record.setUserName(userName);
                this.logDao.insertSelective(record);
            }
        }
        return i;
    }

    @Override
    public MemberInfoObj selectMemberInfoObjDetail(String memberId) {
        return this.membersDao.selectMemberInfoObjDetail(memberId);
    }

    @Override
    public MemberInfoObj selectOneMember(String openId) {
        return this.membersDao.selectOneMember(openId);
    }

    @Override
    public int updateMembersToken(String memberId) {
        return this.membersDao.updateMembersToken(memberId);
    }
    @Override
    public MemberObj getMemberByPara(Map<String, Object> map) {
        return membersDao.getMemberByPara(map);
    }
}
