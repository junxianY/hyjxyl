package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.FavourRecord;

/**
 * 点赞服务类
 */
public interface FavourRecordService {
    /**
     * 查询某客户对某篇活动的最后点赞信息
     * @param refId
     * @param refType
     * @param memberId
     * @return
     */
  public FavourRecord selectOneFavourRecord(String refId,String refType,String memberId);
}
