package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecord;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecordCountObj;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecordObj;

import java.util.List;
import java.util.Map;

/**
 * 刷卡记录表
 */
public interface CardUseRecordService {
    int insertSelective(CardUseRecord record);

    CardUseRecord selectByPrimaryKey(String recordId);

    int updateByPrimaryKeySelective(CardUseRecord record);

    /**
     * 通过条件查询刷卡记录列表
     * @param map
     * @return
     */
    public List<CardUseRecordObj> selectRecordList(PageBean page,Map<String, Object> map);

    /**
     * 插入刷卡记录，更新剩余次数
     * @param cardNo
     * @param deviceNo
     * @return
     */
    public String insertCardRecord(String cardNo,String deviceNo);

    /**
     * 统计各种服务使用次数
     * @param memberId
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @return
     */
    public List<CardUseRecordCountObj> countCardUseRecord(String memberId,String startDate,String endDate);
}
