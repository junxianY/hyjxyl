package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.ContentTypeDao;
import cn.comshinetechchina.hyjxyl.domain.ContentType;
import cn.comshinetechchina.hyjxyl.service.ContentTypeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service("contentTypeService")
public class ContentTypeServiceImpl implements ContentTypeService {
    @Resource
    private ContentTypeDao contentTypeDao;
    @Override
    public ContentType selectOneContentType(String typeCode, int isActive) {
        return contentTypeDao.selectOneContentType(typeCode,isActive);
    }
}
