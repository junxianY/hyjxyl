package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.MemberExtendDao;
import cn.comshinetechchina.hyjxyl.domain.MemberExtend;
import cn.comshinetechchina.hyjxyl.service.MemberExtendService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("memberExtendService")
public class MemberExtendServiceImpl implements MemberExtendService {
    @Resource
    private MemberExtendDao  memberExtendDao;
    @Override
    public int insertSelective(MemberExtend record) {
        return memberExtendDao.insertSelective(record);
    }

    @Override
    public MemberExtend selectByPrimaryKey(String memberId) {
        return memberExtendDao.selectByPrimaryKey(memberId);
    }

    @Override
    public int updateByPrimaryKeySelective(MemberExtend record) {
        return memberExtendDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<MemberExtend> selectMemberExtendList(MemberExtend record) {
        return memberExtendDao.selectMemberExtendList(record);
    }
}
