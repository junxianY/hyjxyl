package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.Illness;
import cn.comshinetechchina.hyjxyl.domain.IllnessObj;

import java.util.List;
import java.util.Map;

public interface IllnessService {
    int insertSelective(Illness record);

    Illness selectByPrimaryKey(String illnessId);

    int updateByPrimaryKeySelective(Illness record);

    /**
     * 查询病例列表
     * @param map 查询条件参数
     * @param bean 分页信息
     * @return
     */
    public List<IllnessObj> getIllnessList(Map<String, Object> map, PageBean bean);

    /**
     * 查询单条病例信息
     * @param illnessId
     * @return
     */
    public IllnessObj selectOneIllness(String illnessId);

    int deleteByPrimaryKey(String illnessId);
}
