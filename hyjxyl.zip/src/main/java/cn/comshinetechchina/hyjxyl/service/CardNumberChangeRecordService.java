package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.CardNumberChangeRecord;

import java.util.List;

/**
 * 卡次数变更服务接口
 */
public interface CardNumberChangeRecordService {
    int insertSelective(CardNumberChangeRecord record);
    public List<CardNumberChangeRecord> selectChangeRecordList(String cardNo, String serviceId);
}
