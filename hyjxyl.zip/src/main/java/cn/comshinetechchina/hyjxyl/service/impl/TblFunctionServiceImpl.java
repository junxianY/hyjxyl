package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.TblFunctionDao;
import cn.comshinetechchina.hyjxyl.domain.TblFunction;
import cn.comshinetechchina.hyjxyl.service.TblFunctionService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
@Service("tblFunctionService")
public class TblFunctionServiceImpl implements TblFunctionService {
    @Resource
    private TblFunctionDao tblFunctionDao;
    @Override
    public List<TblFunction> selectFunctionList(Map<String, Object> map) {
        return tblFunctionDao.selectFunctionList(map);
    }
}
