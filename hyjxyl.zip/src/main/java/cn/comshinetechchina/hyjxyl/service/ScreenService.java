package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.CardUseRecord;
import cn.comshinetechchina.hyjxyl.domain.ServiceStatistics;
import cn.comshinetechchina.hyjxyl.domain.StatisticsArticle;

import java.util.List;
import java.util.Map;

/**
 * 大屏统计接口
 */
public interface ScreenService {
    /**
     * 统计用户接口
     * @param type 默认、总人数 1、当天 2、当月 3、近30天
     * @return
     */
   public int countMembers(int type);

    /**
     * 根据年龄统计用户获取结果json
     * @return
     */
   public String statisticsMembersByAge();

    /**
     * 通过文化程度统计用户获取结果json
     * @return
     */
   public String statisticsMembersByEducation();

    /**
     * 通过疾病类型统计
     * @return
     */
   public String statisticsByDisease(Integer sex);

    /**
     * 通过服务名称统计
     * @return
     */
   public String statisticsByService();

    /**
     * 服务分男女统计 折线图
     * @return
     */
   public String statisticMemberService(String startDate,String endDate);

    /**
     * 获取最近四小时内划卡成功的服务列表
     * @return
     */
   public List<CardUseRecord> getCardUseList();

    /**
     * 居住类型统计
     * @return
     */
   public String statisticsByLiveCategory();
    /**
     * 统计某段时间内各项服务总次数
     * @param map  type=1 近30天
     * @return
     */
    public List<ServiceStatistics> statisticsMembersByServiceName(Map<String,Object> map);

    /**
     * 统计仪器使用记录
     * @param map  type=1 今天
     * @return
     */
    public List<ServiceStatistics> statisticsCardUseRecord(Map<String,Object> map);

    /**
     * 统计活动资讯浏览量、点赞数等
     * @param map
     * @return
     */
    public List<StatisticsArticle> statisticsArticles(Map<String,Object> map);

    /**
     * 健康监测预警
     * @return
     */
    public String statisticsHealthMonitorData();
}
