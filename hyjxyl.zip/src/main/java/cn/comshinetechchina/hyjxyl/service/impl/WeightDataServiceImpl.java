package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.controller.DataController;
import cn.comshinetechchina.hyjxyl.dao.WeightDataDao;
import cn.comshinetechchina.hyjxyl.domain.WeightData;
import cn.comshinetechchina.hyjxyl.service.WeightDataService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service("weightDataService")
public class WeightDataServiceImpl implements WeightDataService {
    private Logger log= LoggerFactory.getLogger(WeightDataServiceImpl.class);

    @Resource
    private WeightDataDao weightDataDao;
    @Override
    public List<WeightData> selectWeightDataList(PageBean page, Map<String, Object> map) {
        return weightDataDao.selectWeightDataList(page,map);
    }

    @Override
    public String packageChartData(List<WeightData> list) {
        JSONObject json=new JSONObject();
        //横坐标数据
        JSONObject xAxis=new JSONObject();
        xAxis.put("type","category");
        xAxis.put("boundaryGap",false);
        List<String> xList=new ArrayList<String>();
        List<String> yList=new ArrayList<String>();
        try {
            if (list != null && list.size() > 0) {
                for (WeightData data : list) {
                    if(data.getRt()!=null){
                        xList.add(DateUtil.transferDate2Str(data.getRt(), "yyyy-MM-dd"));
                        if(data.getWtg()>=0){
                            yList.add(String.valueOf(data.getWtg()));
                        }else{
                            yList.add("");
                        }

                    }
                }
            }
        }catch(ParseException ex){
            throw new ServiceException("强转出错",ex);
        }
        xAxis.put("data",xList);
        //纵坐标数据
        JSONObject series=new JSONObject();
        series.put("name","体重值");
        series.put("type","line");
        series.put("data",yList);
        json.put("xAxis",xAxis);
        json.put("series",series);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    @Override
    public List<WeightData> selectMemberWeightDataList(String memberId) {
        return this.weightDataDao.selectMemberWeightDataList(memberId);
    }
}
