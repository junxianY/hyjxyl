package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.Card;
import cn.comshinetechchina.hyjxyl.domain.CardObj;
import cn.comshinetechchina.hyjxyl.domain.MemberInfo;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 卡信息服务类
 */
public interface CardService {
    int insertSelective(Card record);
    Card selectByPrimaryKey(String cardId);
    int updateByPrimaryKeySelective(Card record);
    int deleteByPrimaryKey(String cardId);

    /**
     * 通过条件查询卡列表
     * @param map
     * @return
     */
    public List<CardObj> selectCardList(Map<String,Object> map);

    /**
     * 绑卡操作
     * @param cardNo
     * @param cardTypeId 卡类型id
     * @param timeLimit 期限
     * @param startDate 有效起止日
     * @param endDate 有效截止日
     * @return
     */
    public int bindCard(String cardNo, String cardTypeId, Integer timeLimit, Date startDate, Date endDate);

    /**
     * 更换卡绑定操作
     * @param memberId 客户id
     * @param newCardNo 新卡编号
     * @param faceNo 卡面卡号
     * @param userId
     * @param userName
     * @param ip
     * @return
     */
    public String changeCard(String memberId,String newCardNo,String faceNo,String userId,String userName,String ip);

    /**
     * 解绑卡接口
     * @param memberId
     * @return
     */
    public String removeCardBind(String memberId);

    /**
     * 批量更新卡状态接口
     * @param cardNos  卡编号
     * @param available 卡状态
     * @param remark   备注
     * @param userId 用户id
     * @param userName 用户名
     * @return
     */
    public int batchUpdateCardStatus(List<String> cardNos,int available,String remark,String userId,String userName);

    public List<MemberInfo> selectCardMemberList(Map<String,String> map, PageBean bean);
}
