package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.PhoneCodeDao;
import cn.comshinetechchina.hyjxyl.domain.PhoneCode;
import cn.comshinetechchina.hyjxyl.service.PhoneCodeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
@Service("phoneCodeService")
public class PhoneCodeServiceImpl implements PhoneCodeService {
    @Resource
    private PhoneCodeDao phoneCodeDao;
    @Override
    public int insertSelective(PhoneCode record) {
        return phoneCodeDao.insertSelective(record);
    }

    @Override
    public PhoneCode selectByPrimaryKey(String phone) {
        return phoneCodeDao.selectByPrimaryKey(phone);
    }

    @Override
    public int updateByPrimaryKeySelective(PhoneCode record) {
        return phoneCodeDao.updateByPrimaryKeySelective(record);
    }
}
