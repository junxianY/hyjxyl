package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.UrineData;

import java.util.List;
import java.util.Map;

/**
 * 尿液分析数据接口
 */
public interface UrineDataService {
    /**
     * 倒序查询列表
     * @param map
     * @param page
     * @return
     */
    public List<UrineData> selectUrineDataList(PageBean page, Map<String,Object> map);

    /**
     * 查询用户尿液信息
     * @param memberId
     * @return
     */
    List<UrineData> selectMemberUrineDataList(String memberId);

}
