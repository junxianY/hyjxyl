package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.CardType;

import java.util.List;
import java.util.Map;

/**
 * 卡类型服务类
 */
public interface CardTypeService {
    int insertSelective(CardType record);

    CardType selectByPrimaryKey(String cardTypeId);

    int updateByPrimaryKeySelective(CardType record);

    /**
     * 通过条件查询卡类型
     * @param map
     * @return
     */
    List<CardType> selectAllCardTypes(Map<String,Object> map);
    int deleteByPrimaryKey(String cardTypeId);
}
