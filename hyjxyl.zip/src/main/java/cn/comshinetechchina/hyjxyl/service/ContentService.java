package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.Content;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 附件服务类
 */
public interface ContentService {
    int insertSelective(Content record);
    Content selectByPrimaryKey(String contentId);


    /**
     * 通过业务id查询其附件信息(倒序排列)
     * @param busiId  业务id
     * @param tableName 业务表名
     * @param contentTypeId 附件类型
     * @return
     */
    public List<Content> selectContentsById(String busiId, String tableName, String contentTypeId);

    /**
     * 附件保存进表操作
     * @param upload  附件流
     * @param contentName 附件名称
     * @param contentTypeId 附件类型
     * @return
     */
    public String saveFileUpload(MultipartFile upload, String contentName, String contentTypeId);

    /**
     * 保存远程图片接口
     * @param remotePath
     * @return
     */
    public String saveRemoteImg(String remotePath);
}
