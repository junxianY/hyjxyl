package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.Location;

import java.util.List;
import java.util.Map;

/**
 * 位置地图接口
 */
public interface LocationService {
    /**
     * 查询地图位置信息
     * @param page
     * @param map
     * @return
     */
    public List<Location> selectLocationList(PageBean page, Map<String,Object> map);
    int insertSelective(Location record);

    Location selectByPrimaryKey(String locationId);
}
