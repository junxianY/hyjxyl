package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.PushMember;

import java.util.List;
import java.util.Map;

/**
 * 个推用戶接口
 */
public interface PushMemberService {
    int insertSelective(PushMember record);
    PushMember selectByPrimaryKey(String id);
    int updateByPrimaryKeySelective(PushMember record);
    public List<PushMember> selectPushMembersList(Map<String, Object> map);

    /**
     * 更新状态接口
     * @param record
     * @return
     */
    public int updatePushMember(PushMember record);

    int delPushMemberByClientId(String clientId);
}
