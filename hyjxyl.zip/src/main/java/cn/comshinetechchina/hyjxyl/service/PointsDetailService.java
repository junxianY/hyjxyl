package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.PointsDetail;

import java.util.List;
import java.util.Map;

public interface PointsDetailService {
    /**
     * 查询积分明细信息接口
     * @param map
     * @return
     */
    List<PointsDetail> selectPointsDetailList(Map<String,Object> map);
    int insertSelective(PointsDetail record);

    PointsDetail selectByPrimaryKey(String pointsDetailId);

    int updateByPrimaryKeySelective(PointsDetail record);

    /**
     * 分页查询
     * @param map
     * @param bean
     * @return
     */
    List<PointsDetail> selectPointsDetailListByPage(Map<String,Object> map,PageBean bean);
}
