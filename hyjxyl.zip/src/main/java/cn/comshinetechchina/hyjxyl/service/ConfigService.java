package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.Config;

import java.util.List;

public interface ConfigService {
    /**
     * 查询配置参数列表
     * @param code 参数code
     * @param isActive 是否有效 1有效 0无效
     * @return
     */
    public List<Config> selectConfigList(String code, int isActive);
}
