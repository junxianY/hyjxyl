package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.TblLog;
import cn.comshinetechchina.hyjxyl.domain.TblLogObj;

import java.util.List;

/**
 * 日志服务类
 */
public interface TblLogService {
    int insertSelective(TblLog record);

    /**
     * 分页查询日志记录
     * @param memberId
     * @param type
     * @return
     */
    List<TblLogObj> selectLogList(String memberId,Integer type,PageBean page);
}
