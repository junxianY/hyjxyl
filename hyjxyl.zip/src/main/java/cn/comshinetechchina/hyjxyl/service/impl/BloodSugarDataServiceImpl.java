package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.dao.BloodSugarDataDao;
import cn.comshinetechchina.hyjxyl.domain.BloodSugarData;
import cn.comshinetechchina.hyjxyl.service.BloodSugarDataService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
@Service("bloodSugarDataService")
public class BloodSugarDataServiceImpl implements BloodSugarDataService {
    private Logger log= LoggerFactory.getLogger(BloodSugarDataServiceImpl.class);
    @Resource
    private BloodSugarDataDao bloodSugarDataDao;
    @Override
    public List<BloodSugarData> selectBloodSugarDataList(PageBean page, Map<String, Object> map) {
        return this.bloodSugarDataDao.selectBloodSugarDataList(page,map);
    }

    @Override
    public String packageChartData(List<BloodSugarData> list) {
        JSONObject json=new JSONObject();
        //横坐标数据
        JSONObject xAxis=new JSONObject();
        xAxis.put("type","category");
        xAxis.put("boundaryGap",false);
        List<String> xList=new ArrayList<String>();
        List<String> yList=new ArrayList<String>();
        try {
            if (list != null && list.size() > 0) {
                for (BloodSugarData data : list) {
                    if(data.getRt()!=null){
                        xList.add(DateUtil.transferDate2Str(data.getRt(), "yyyy-MM-dd"));
                        if(data.getBs()>=0){
                            yList.add(String.valueOf(data.getBs()));
                        }else{
                            yList.add("");
                        }

                    }
                }
            }
        }catch(ParseException ex){
            throw new ServiceException("强转出错",ex);
        }
        xAxis.put("data",xList);
        //纵坐标数据
        JSONObject series=new JSONObject();
        series.put("name","血糖值");
        series.put("type","line");
        series.put("data",yList);
        json.put("xAxis",xAxis);
        json.put("series",series);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    @Override
    public List<BloodSugarData> selectMemberBloodSugarDataList(String memberId) {
        return this.bloodSugarDataDao.selectMemberBloodSugarDataList(memberId);
    }
}
