package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.ProvinceDao;
import cn.comshinetechchina.hyjxyl.domain.Province;
import cn.comshinetechchina.hyjxyl.service.ProvinceService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service("provinceService")
public class ProvinceServiceImpl implements ProvinceService {
    @Resource
    private ProvinceDao provinceDao;
    @Override
    public List<Province> selectProvinceList() {
        return provinceDao.selectProvinceList();
    }
}
