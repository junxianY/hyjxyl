package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.KithAndKinDao;
import cn.comshinetechchina.hyjxyl.domain.KithAndKin;
import cn.comshinetechchina.hyjxyl.service.KithAndKinService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("kithAndKinService")
public class KithAndKinServiceImpl implements KithAndKinService {
 @Resource
 private KithAndKinDao kithAndKinDao;

    @Override
    public int insertSelective(KithAndKin record) {
        return kithAndKinDao.insertSelective(record);
    }

    @Override
    public KithAndKin selectByPrimaryKey(String kinId) {
        return kithAndKinDao.selectByPrimaryKey(kinId);
    }

    @Override
    public int updateByPrimaryKeySelective(KithAndKin record) {
        return kithAndKinDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<KithAndKin> selectUserKithList(String memberId) {
        return kithAndKinDao.selectUserKithList(memberId);
    }

    @Override
    public List<KithAndKin> selectKithListByPara(String memberId, String nickMemberId, String nickName, String available) {
        return this.kithAndKinDao.selectKithListByPara(memberId,nickMemberId,nickName,available);
    }

    @Override
    public List<KithAndKin> selectUserKithList(String memberId, int concern) {
        return this.kithAndKinDao.selectUserKithList(memberId,concern);
    }
}
