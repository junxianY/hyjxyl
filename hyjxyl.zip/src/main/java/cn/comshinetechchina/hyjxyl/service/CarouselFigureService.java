package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.ArticleObj;
import cn.comshinetechchina.hyjxyl.domain.CarouselFigure;
import cn.comshinetechchina.hyjxyl.domain.CarouselFigureObj;

import java.util.List;
import java.util.Map;

/**
 * 轮播图接口u
 */
public interface CarouselFigureService {
    public List<CarouselFigureObj> selectCarouselFigureList(PageBean page, Map<String,Object> map);
    int insertSelective(CarouselFigure record);
    CarouselFigure selectByPrimaryKey(String id);
    int updateByPrimaryKeySelective(CarouselFigure record);

    /**
     * 获取随机五条数据
     * @return
     */
    public List<CarouselFigureObj> selectRandom5Articles();

    /**
     * 查询可以添加的活动列表
     * @param map
     * @return
     */
    public List<ArticleObj> queryAvailableArticles(PageBean page,Map<String,Object> map);

    /**
     * 通过articleId查询对应轮播图信息
     * @param articleId
     * @return
     */
    CarouselFigure selectOneCarouselFigure(String articleId,int available);

    /**
     * 通过序号查询信息
     * @param orderNo
     * @return
     */
    CarouselFigure selectOneCarouselFigureByOrder(Integer orderNo);
}
