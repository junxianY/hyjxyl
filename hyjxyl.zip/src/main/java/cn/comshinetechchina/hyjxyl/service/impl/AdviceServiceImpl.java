package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.AdviceDao;
import cn.comshinetechchina.hyjxyl.domain.Advice;
import cn.comshinetechchina.hyjxyl.domain.AdviceObj;
import cn.comshinetechchina.hyjxyl.service.AdviceService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("adviceService")
public class AdviceServiceImpl implements AdviceService {
    @Resource
    private AdviceDao adviceDao;
    @Override
    public int insertSelective(Advice record) {
        return adviceDao.insertSelective(record);
    }

    @Override
    public Advice selectByPrimaryKey(String adviceId) {
        return adviceDao.selectByPrimaryKey(adviceId);
    }

    @Override
    public List<AdviceObj> selectAdviceList(PageBean page, Map<String, String> map) {
        return this.adviceDao.selectAdviceList(page,map);
    }

    @Override
    public int deleteByPrimaryKey(String adviceId) {
        return this.adviceDao.deleteByPrimaryKey(adviceId);
    }
}
