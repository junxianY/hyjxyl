package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.TestRecordDao;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.TestRecordService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

@Service("testRecordService")
public class TestRecordServiceImpl implements TestRecordService {
    @Resource
    private TestRecordDao testRecordDao;
    @Override
    public List<TestRecord> selectTestRecordList(Map<String, Object> map,PageBean bean) {
        return testRecordDao.selectTestRecordList(map,bean);
    }

    @Override
    public String packageChartData(List<CheckData> list, Integer type) {
        //1:体重 2:血糖 3:血氧 4：血压\脉搏 5：血脂 6：尿酸 7体脂 8心率
        //图表时间从小到大
        if(list!=null&&list.size()>0){
            Collections.sort(list, new Comparator<CheckData>() {
                public int compare(CheckData a, CheckData b) {
                    String time1 = a.getCreateTime();
                    String time2 = b.getCreateTime();
                    return time1.compareTo(time2);
                }
            });
        }
        JSONObject json=new JSONObject();
        //横坐标数据
        JSONObject xAxis=new JSONObject();
        //纵坐标数据
        JSONObject series=new JSONObject();
        xAxis.put("type","category");
        xAxis.put("boundaryGap",false);
        if(type==1){
                List<String> xList=new ArrayList<String>();
                List<String> yList=new ArrayList<String>();
                    if (list != null && list.size() > 0) {
                        for (CheckData data : list) {
                            System.out.println(data.getCreateTime().substring(0,10));
                            if(data.getCreateTime()!=null){
                                xList.add(data.getCreateTime().substring(0,10));
                                if(data.getWeight()>=0){
                                    yList.add(String.valueOf(data.getWeight()));
                                }else{
                                    yList.add("");
                                }

                            }
                        }
                    }
                xAxis.put("data",xList);
                series.put("name","体重值");
                series.put("type","line");
                series.put("data",yList);
                json.put("xAxis",xAxis);
                json.put("series",series);
        }else if(type==2){
            List<String> xList=new ArrayList<String>();
            List<String> yList=new ArrayList<String>();
            if (list != null && list.size() > 0) {
                    for (CheckData data : list) {
                        if(data.getCreateTime()!=null){
                            xList.add(data.getCreateTime().substring(0,10));
                            if(data.getBloodSugar()>=0){
                                yList.add(String.valueOf(data.getBloodSugar()));
                            }else{
                                yList.add("");
                            }

                        }
                    }
             }
            xAxis.put("data",xList);
            series.put("name","血糖值");
            series.put("type","line");
            series.put("data",yList);
            json.put("xAxis",xAxis);
            json.put("series",series);
        }else if(type==3){
            List<String> xList=new ArrayList<String>();
            List<String> yList=new ArrayList<String>();
                if (list != null && list.size() > 0) {
                    for (CheckData data : list) {
                        if(data.getCreateTime()!=null){
                            xList.add(data.getCreateTime().substring(0,10));
                            if(data.getOxygenSaturation()>=0){
                                yList.add(String.valueOf(data.getOxygenSaturation()));
                            }else{
                                yList.add("");
                            }

                        }
                    }
                }
            xAxis.put("data",xList);
            series.put("name","血氧值");
            series.put("type","line");
            series.put("data",yList);
            json.put("xAxis",xAxis);
            json.put("series",series);
        }else if(type==4){
            List<String> xList=new ArrayList<String>();
            //舒张压
            List<String> yList1=new ArrayList<String>();
            //收缩压
            List<String> yList2=new ArrayList<String>();
            //脉搏
            List<String> yList3=new ArrayList<String>();
                if (list != null && list.size() > 0) {
                    for (CheckData data : list) {
                        if(data.getCreateTime()!=null){
                            xList.add(data.getCreateTime().substring(0,10));
                            if(data.getLowPressure()>=0){
                                yList1.add(String.valueOf(data.getLowPressure()));
                            }else{
                                yList1.add("");
                            }
                            if(data.getHeightPressure()>=0){
                                yList2.add(String.valueOf(data.getHeightPressure()));
                            }else{
                                yList2.add("");
                            }
                            if(data.getPulse()>=0){
                                yList3.add(String.valueOf(data.getPulse()));
                            }else{
                                yList3.add("");
                            }
                        }
                    }
                }
            xAxis.put("data",xList);
            //纵坐标数据
            JSONObject series1=new JSONObject();
            series1.put("name","舒张压");
            series1.put("type","line");
            series1.put("data",yList1);
            JSONObject series2=new JSONObject();
            series2.put("name","收缩压");
            series2.put("type","line");
            series2.put("data",yList2);
            JSONObject series3=new JSONObject();
            series3.put("name","脉率");
            series3.put("type","line");
            series3.put("data",yList3);
            List<JSONObject> arrayList=new ArrayList<JSONObject>();
            arrayList.add(series1);
            arrayList.add(series2);
            arrayList.add(series3);

            json.put("xAxis",xAxis);
            json.put("series",arrayList);
        }else if(type==5){
            //胆固醇 甘油三酯 高密度蛋白  低密度蛋白 mmol/L
            List<String> xList=new ArrayList<String>();
            //胆固醇
            List<String> yList1=new ArrayList<String>();
            //甘油三酯
            List<String> yList2=new ArrayList<String>();
            //高密度蛋白
            List<String> yList3=new ArrayList<String>();
            //低密度蛋白
            List<String> yList4=new ArrayList<String>();
            if (list != null && list.size() > 0) {
                for (CheckData data : list) {
                    if(data.getCreateTime()!=null){
                        xList.add(data.getCreateTime().substring(0,10));
                        if(data.getTotalCholesterol()>=0){
                            yList1.add(String.valueOf(data.getTotalCholesterol()));
                        }else{
                            yList1.add("");
                        }
                        if(data.getTriglycerides()>=0){
                            yList2.add(String.valueOf(data.getTriglycerides()));
                        }else{
                            yList2.add("");
                        }
                        if(data.getHeightLipoprotein()>=0){
                            yList3.add(String.valueOf(data.getHeightLipoprotein()));
                        }else{
                            yList3.add("");
                        }
                        if(data.getLowLipoprotein()>=0){
                            yList4.add(String.valueOf(data.getLowLipoprotein()));
                        }else{
                            yList4.add("");
                        }
                    }
                }
            }
            xAxis.put("data",xList);
            //纵坐标数据
            JSONObject series1=new JSONObject();
            series1.put("name","胆固醇");
            series1.put("type","line");
            series1.put("data",yList1);
            JSONObject series2=new JSONObject();
            series2.put("name","甘油三酯");
            series2.put("type","line");
            series2.put("data",yList2);
            JSONObject series3=new JSONObject();
            series3.put("name","高密度蛋白");
            series3.put("type","line");
            series3.put("data",yList3);
            JSONObject series4=new JSONObject();
            series4.put("name","低密度蛋白");
            series4.put("type","line");
            series4.put("data",yList3);
            List<JSONObject> arrayList=new ArrayList<JSONObject>();
            arrayList.add(series1);
            arrayList.add(series2);
            arrayList.add(series3);
            arrayList.add(series4);
            json.put("xAxis",xAxis);
            json.put("series",arrayList);
        }else if(type==6){
            //尿酸
            List<String> xList=new ArrayList<String>();
            List<String> yList=new ArrayList<String>();
            if (list != null && list.size() > 0) {
                for (CheckData data : list) {
                    System.out.println(data.getCreateTime().substring(0,10));
                    if(data.getCreateTime()!=null){
                        xList.add(data.getCreateTime().substring(0,10));
                        if(data.getUricAcid()>=0){
                            yList.add(String.valueOf(data.getUricAcid()));//尿酸值
                        }else{
                            yList.add("");
                        }

                    }
                }
            }
            xAxis.put("data",xList);
            series.put("name","尿酸值");
            series.put("type","line");
            series.put("data",yList);
            json.put("xAxis",xAxis);
            json.put("series",series);
        }else if(type==7){
           //体脂率 体水分率 %
            List<String> xList=new ArrayList<String>();
            //体脂率
            List<String> yList1=new ArrayList<String>();
            //体水分率
            List<String> yList2=new ArrayList<String>();
            if (list != null && list.size() > 0) {
                for (CheckData data : list) {
                    if(data.getCreateTime()!=null){
                        xList.add(data.getCreateTime().substring(0,10));
                        if(data.getFatRate()>=0){
                            yList1.add(String.valueOf(data.getFatRate()));
                        }else{
                            yList1.add("");
                        }
                        if(data.getWaterRate()>=0){
                            yList2.add(String.valueOf(data.getWaterRate()));
                        }else{
                            yList2.add("");
                        }
                    }
                }
            }
            xAxis.put("data",xList);
            //纵坐标数据
            JSONObject series1=new JSONObject();
            series1.put("name","体脂率");
            series1.put("type","line");
            series1.put("data",yList1);
            JSONObject series2=new JSONObject();
            series2.put("name","体水分率");
            series2.put("type","line");
            series2.put("data",yList2);

            List<JSONObject> arrayList=new ArrayList<JSONObject>();
            arrayList.add(series1);
            arrayList.add(series2);
            json.put("xAxis",xAxis);
            json.put("series",arrayList);
        }else if(type==8){
            //心率
            List<String> xList=new ArrayList<String>();
            List<String> yList=new ArrayList<String>();
            if (list != null && list.size() > 0) {
                for (CheckData data : list) {
                    if(data.getCreateTime()!=null){
                        xList.add(data.getCreateTime().substring(0,10));
                        if(data.getEcgRate()>=0){
                            yList.add(String.valueOf(data.getEcgRate()));
                        }else{
                            yList.add("");
                        }

                    }
                }
            }
            xAxis.put("data",xList);
            series.put("name","心率值");
            series.put("type","line");
            series.put("data",yList);
            json.put("xAxis",xAxis);
            json.put("series",series);
        }
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    @Override
    public List<TestRecord> selectAllTestRecordList(Map<String, Object> map) {
        return this.testRecordDao.selectAllTestRecordList(map);
    }

}
