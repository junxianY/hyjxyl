package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.dao.BloodPressureDataDao;
import cn.comshinetechchina.hyjxyl.domain.BloodPressureData;
import cn.comshinetechchina.hyjxyl.domain.BloodSugarData;
import cn.comshinetechchina.hyjxyl.service.BloodPressureDataService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service("bloodPressureDataService")
public class BloodPressureDataServiceImpl implements BloodPressureDataService {
    private Logger log= LoggerFactory.getLogger(BloodPressureDataServiceImpl.class);
    @Resource
    private BloodPressureDataDao bloodPressureDataDao;
    @Override
    public List<BloodPressureData> selectBloodPressureDataList(PageBean page, Map<String, Object> map) {
        return bloodPressureDataDao.selectBloodPressureDataList(page,map);
    }

    @Override
    public String packageChartData(List<BloodPressureData> list) {
        JSONObject json=new JSONObject();
        //横坐标数据
        JSONObject xAxis=new JSONObject();
        xAxis.put("type","category");
        xAxis.put("boundaryGap",false);
        List<String> xList=new ArrayList<String>();
        //舒张压
        List<String> yList1=new ArrayList<String>();
        //收缩压
        List<String> yList2=new ArrayList<String>();
        //脉率
        List<String> yList3=new ArrayList<String>();
        try {
            if (list != null && list.size() > 0) {
                for (BloodPressureData data : list) {
                    if(data.getRt()!=null){
                        xList.add(DateUtil.transferDate2Str(data.getRt(), "yyyy-MM-dd HH:mm:ss"));
                        if(data.getDp()>=0){
                            yList1.add(String.valueOf(data.getDp()));
                        }else{
                            yList1.add("");
                        }
                        if(data.getSp()>=0){
                            yList2.add(String.valueOf(data.getSp()));
                        }else{
                            yList2.add("");
                        }
                        if(data.getPs()>=0){
                            yList3.add(String.valueOf(data.getPs()));
                        }else{
                            yList3.add("");
                        }
                    }
                }
            }
        }catch(ParseException ex){
            throw new ServiceException("强转出错",ex);
        }
        xAxis.put("data",xList);
        //纵坐标数据
        JSONObject series1=new JSONObject();
        series1.put("name","舒张压");
        series1.put("type","line");
        series1.put("data",yList1);
        JSONObject series2=new JSONObject();
        series2.put("name","收缩压");
        series2.put("type","line");
        series2.put("data",yList2);
        JSONObject series3=new JSONObject();
        series3.put("name","脉率");
        series3.put("type","line");
        series3.put("data",yList3);
        List<JSONObject> arrayList=new ArrayList<JSONObject>();
        arrayList.add(series1);
        arrayList.add(series2);
        arrayList.add(series3);

        json.put("xAxis",xAxis);
        json.put("series",arrayList);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);

    }

    @Override
    public List<BloodPressureData> selectMemberBloodPressureDataList(String memberId) {
        return this.bloodPressureDataDao.selectMemberBloodPressureDataList(memberId);
    }
}
