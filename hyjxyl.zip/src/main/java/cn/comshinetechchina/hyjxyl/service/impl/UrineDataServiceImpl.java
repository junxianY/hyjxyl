package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.UrineDataDao;
import cn.comshinetechchina.hyjxyl.domain.UrineData;
import cn.comshinetechchina.hyjxyl.service.UrineDataService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
@Service("urineDataService")
public class UrineDataServiceImpl implements UrineDataService {
    @Resource
    private UrineDataDao urineDataDao;
    @Override
    public List<UrineData> selectUrineDataList(PageBean page, Map<String,Object> map) {
        return urineDataDao.selectUrineDataList(page,map);
    }

    @Override
    public List<UrineData> selectMemberUrineDataList(String memberId) {
        return this.urineDataDao.selectMemberUrineDataList(memberId);
    }
}
