package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.FatERData;

import java.util.List;
import java.util.Map;

/**
 * 脂肪接口
 */
public interface FatERDataService {
    public List<FatERData> selectFatERDataList(PageBean page, Map<String, Object> map);
    public String packageChartData(List<FatERData> list);
}
