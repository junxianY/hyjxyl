package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.Province;

import java.util.List;

public interface ProvinceService {
    /**
     * 查询省份列表
     * @return
     */
    public List<Province> selectProvinceList();
}
