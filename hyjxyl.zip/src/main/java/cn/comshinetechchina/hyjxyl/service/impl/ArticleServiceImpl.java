package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.ArticleDao;
import cn.comshinetechchina.hyjxyl.dao.FavourRecordDao;
import cn.comshinetechchina.hyjxyl.domain.Article;
import cn.comshinetechchina.hyjxyl.domain.ArticleObj;
import cn.comshinetechchina.hyjxyl.domain.FavourRecord;
import cn.comshinetechchina.hyjxyl.service.ArticleService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service("articleService")
public class ArticleServiceImpl implements ArticleService {
    @Resource
    private ArticleDao articleDao;
    @Resource
    private FavourRecordDao favourRecordDao;
    @Override
    public int insertSelective(Article record) {
        return articleDao.insertSelective(record);
    }

    @Override
    public Article selectByPrimaryKey(String articleId) {
        return articleDao.selectByPrimaryKey(articleId);
    }

    @Override
    public int updateByPrimaryKeySelective(Article record) {
        return this.articleDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public int deleteByPrimaryKey(String articleId) {
        return this.articleDao.deleteByPrimaryKey(articleId);
    }

    @Override
    public List<ArticleObj> selectArticleList(Map<String, Object> map, PageBean bean) {
        return this.articleDao.selectArticleList(map,bean);
    }

    @Override
    public int updateArticleFavor(String articleId, String userId,Integer operate) {
        int i=0;
        Article article=this.articleDao.selectByPrimaryKey(articleId);
        if(article==null){
            return i;
        }else{
            if(null==article.getFavour()){
                article.setFavour(1);
            }else{
                if(operate==1){
                    article.setFavour(article.getFavour()+1);
                }else if(operate==2){
                    //取消赞
                    article.setFavour(article.getFavour()-1);
                }

            }
            i=this.articleDao.updateByPrimaryKeySelective(article);
            if(i>0){
                //插入一条点赞数
                FavourRecord record=new FavourRecord();
                record.setFavourId(UUID.randomUUID().toString());
                record.setRefId(articleId);
                record.setRefType("tbl_articles");
                record.setCreateBy(userId);
                record.setCreateDate(new Date());
                record.setType(operate);
                this.favourRecordDao.insertSelective(record);
            }
        }
        return i;
    }

    @Override
    public int updateArticleArticleScol(List<String> list) {
        return this.articleDao.updateArticleArticleScol(list);
    }

    @Override
    public List<ArticleObj> selectRandom5Articles() {
        return this.articleDao.selectRandom5Articles();
    }

    @Override
    public Map selectOneByOrderNo(Article article) {
        return this.articleDao.selectOneByOrderNo(article);
    }

    @Override
    public int updateByPrimaryKeyWithBLOBs(Article record) {
        return this.articleDao.updateByPrimaryKeyWithBLOBs(record);
    }
}
