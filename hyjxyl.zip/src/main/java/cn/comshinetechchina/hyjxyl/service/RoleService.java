package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.Role;
import cn.comshinetechchina.hyjxyl.domain.RoleFunction;

import java.util.List;

/**
 * 角色服务类
 */
public interface RoleService {
    int insertSelective(Role record);

    Role selectByPrimaryKey(Integer roleId);

    int updateByPrimaryKeySelective(Role record);

    /**
     * 通过角色id查询其菜单权限
     * @param roleId
     * @return
     */
    public List<RoleFunction> selectRoleFunctionList(Integer roleId);

    /**
     * 查询角色列表
     * @return
     */
    public List<Role> selectRoleList();
}
