package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.controller.DeviceTestController;
import cn.comshinetechchina.hyjxyl.dao.*;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.DeviceDataService;
import cn.comshinetechchina.hyjxyl.service.PushMessageService;
import cn.comshinetechchina.hyjxyl.service.RuleUtil;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.*;

@Service("deviceDataService")
public class DeviceDataServiceImpl implements DeviceDataService {
    private static final Logger log = LoggerFactory.getLogger(DeviceDataServiceImpl.class);
    @Resource
    private UrineDataDao urineDataDao;
    @Resource
    private WeightDataDao weightDataDao;
    @Resource
    private BloodSugarDataDao bloodSugarDataDao;
    @Resource
    private BloodPressureDataDao bloodPressureDataDao;
    @Resource
    private BloodOxygenDataDao bloodOxygenDataDao;
    @Resource
    private FatDataDao fatDataDao;
    @Resource
    private ConfigDao configDao;
    @Resource
    private MembersDao membersDao;
    @Resource
    private TestRecordDao testRecordDao;
    @Resource
    private PushMessageService pushMessageService;
    @Resource
    private KithAndKinDao kithAndKinDao;
    @Resource
    private MessageDao messageDao;
    @Override
    public String receiveData(String reqData) {
      JSONObject json=new  JSONObject();
      JSONObject req= JSON.parseObject(reqData);
      //1.只记录有效数据
      if("NOTMV1".equals(req.getString("dat"))){
       //2.分类判断数据类型
          int i=0;
          String configCode="";
          //查询配置表，匹配设备类型
          Map<String,Object> para=new HashMap<String,Object>();
          para.put("configValue",req.getString("det"));
          para.put("isActive",1);
          List<Config> configList=this.configDao.selectConfigByPara(para);
          if(configList!=null&&configList.size()>0){
              configCode=configList.get(0).getConfigCode();
          }

          if("data_urine".equals(configCode)){
            //尿液分析数据
              UrineData data=new UrineData();
              data.setId(UUID.randomUUID().toString());
              //计算卡编号
              if(req.get("uid")!=null){
                  data.setCardNo(req.getString("uid"));
              }
              if(req.get("sid")!=null){
                  //检测设备id
                data.setSid(req.getString("sid"));
              }
              if(req.get("LEU")!=null){
                  //白细胞
                data.setLeu(req.getInteger("LEU"));
              }
              if(req.get("NIT")!=null){
                  //亚硝酸盐
                  data.setNit(req.getInteger("NIT"));
              }
              if(req.get("UGB")!=null){
                  //尿胆原
                  data.setUgb(req.getInteger("UGB"));
              }
              if(req.get("PRO")!=null){
                  //蛋白质
                  data.setPro(req.getInteger("PRO"));
              }
              if(req.get("PH")!=null){
                  //酸碱度
                  data.setPh(req.getInteger("PH"));
              }
              if(req.get("BLD")!=null){
                  //红细胞
                  data.setBld(req.getInteger("BLD"));
              }
              if(req.get("SG")!=null){
                  //比重
                  data.setSg(req.getFloat("SG"));
              }
              if(req.get("KET")!=null){
                  //酮体
                  data.setKet(req.getInteger("KET"));
              }
              if(req.get("BIL")!=null){
                  //胆红素
                  data.setBil(req.getInteger("BIL"));
              }
              if(req.get("GLU")!=null){
                  //葡萄糖
                  data.setGlu(req.getInteger("GLU"));
              }
              if(req.get("VC")!=null){
                  //维生素C
                  data.setVc(req.getInteger("VC"));
              }
              if(req.get("rt")!=null){
                  //测量时间毫秒
                  int minute=req.getInteger("rt");
                  try {
                      Date rt= DateUtil.transferStr2Date(DateUtil.paserTime(minute),"yyyy-MM-dd HH:mm:ss");
                      data.setRt(rt);
                  } catch (ParseException e) {
                      e.printStackTrace();
                  }
              }
              data.setCreateTime(new Date());
              data.setAvailable(1);
              //判断表中是否存在记录
              Map map=this.urineDataDao.selectOneData(data.getRt(),"tbl_urine_data");
              if(map==null){
                  i=urineDataDao.insertSelective(data);
              }

          }
          if("data_weight".equals(configCode)){
              //体重数据
              WeightData data=new WeightData();
              data.setId(UUID.randomUUID().toString());
              //计算卡编号
              if(req.get("uid")!=null){
                  data.setCardNo(req.getString("uid"));
              }
              if(req.get("sid")!=null){
                  //检测设备id
                  data.setSid(req.getString("sid"));
              }
              if(req.get("wtg")!=null){
                  //体重值
                  data.setWtg(req.getFloatValue("wtg"));
              }
              data.setUnit("kg");
              if(req.get("rt")!=null){
                  //测量时间
                  int minute=req.getInteger("rt");
                  try {
                      Date rt= DateUtil.transferStr2Date(DateUtil.paserTime(minute),"yyyy-MM-dd HH:mm:ss");
                      data.setRt(rt);
                  } catch (ParseException e) {
                      e.printStackTrace();
                  }
              }
              data.setCreateTime(new Date());
              data.setAvailable(1);
              Map map=this.urineDataDao.selectOneData(data.getRt(),"tbl_weight_data");
              if(map==null){
                  i=this.weightDataDao.insertSelective(data);
              }
          }
          if("data_blood_sugar".equals(configCode)){
              //血糖分析数据
              BloodSugarData data=new BloodSugarData();
              data.setId(UUID.randomUUID().toString());
              if(req.get("uid")!=null){
                  data.setCardNo(req.getString("uid"));
              }
              if(req.get("sid")!=null){
                  //检测设备id
                  data.setSid(req.getString("sid"));
              }
              if(req.get("rt")!=null){
                  //测量时间
                  int minute=req.getInteger("rt");
                  try {
                      Date rt= DateUtil.transferStr2Date(DateUtil.paserTime(minute),"yyyy-MM-dd HH:mm:ss");
                      data.setRt(rt);
                  } catch (ParseException e) {
                      e.printStackTrace();
                  }
              }
              if(req.get("bs")!=null){
                  //血糖值
                  data.setBs(req.getFloat("bs"));
              }
              data.setCreateTime(new Date());
              data.setAvailable(1);
              Map map=this.urineDataDao.selectOneData(data.getRt(),"tbl_blood_sugar_data");
              if(map==null){
                  i=bloodSugarDataDao.insertSelective(data);
              }
          }
          if("data_blood_pressure".equals(configCode)){
              //血压分析数据
              BloodPressureData data=new BloodPressureData();
              data.setId(UUID.randomUUID().toString());
              if(req.get("uid")!=null){
                  data.setCardNo(req.getString("uid"));
              }
              if(req.get("sid")!=null){
                  //检测设备id
                  data.setSid(req.getString("sid"));
              }
              if(req.get("rt")!=null){
                  //测量时间
                  int minute=req.getInteger("rt");
                  try {
                      Date rt= DateUtil.transferStr2Date(DateUtil.paserTime(minute),"yyyy-MM-dd HH:mm:ss");
                      data.setRt(rt);
                  } catch (ParseException e) {
                      e.printStackTrace();
                  }
              }
              if(req.get("dp")!=null){
                  //舒张压
                  data.setDp(req.getInteger("dp"));
              }
              if(req.get("sp")!=null){
                  //收缩压
                  data.setSp(req.getInteger("sp"));
              }
              if(req.get("ps")!=null){
                  //脉率
                  data.setPs(req.getInteger("ps"));
              }
              data.setCreateTime(new Date());
              data.setAvailable(1);
              Map map=this.urineDataDao.selectOneData(data.getRt(),"tbl_blood_pressure_data");
              if(map==null){
                  i=this.bloodPressureDataDao.insertSelective(data);
              }

          }
          if("data_blood_oxygen".equals(configCode)){
              //血氧分析数据
              BloodOxygenData data=new BloodOxygenData();
              data.setId(UUID.randomUUID().toString());
              if(req.get("uid")!=null){
                  data.setCardNo(req.getString("uid"));
              }
              if(req.get("sid")!=null){
                  //检测设备id
                  data.setSid(req.getString("sid"));
              }
              if(req.get("rt")!=null){
                  //测量时间
                  int minute=req.getInteger("rt");
                  try {
                      Date rt= DateUtil.transferStr2Date(DateUtil.paserTime(minute),"yyyy-MM-dd HH:mm:ss");
                      data.setRt(rt);
                  } catch (ParseException e) {
                      e.printStackTrace();
                  }
              }
              if(req.get("ps")!=null){
                  //脉率
                  data.setPs(req.getInteger("ps"));
              }
              if(req.get("ox")!=null){
                  //血氧值
                  data.setOx(req.getFloat("ox"));
              }
              data.setCreateTime(new Date());
              data.setAvailable(1);
              Map map=this.urineDataDao.selectOneData(data.getRt(),"tbl_blood_oxygen_data");
              if(map==null){
                  i=bloodOxygenDataDao.insertSelective(data);
              }
          }
         /* if("HC-301W".equals(req.getString("det"))){
              //脂肪透传电阻数据
              FatERData data=new FatERData();
              data.setId(UUID.randomUUID().toString());
              if(req.get("uid")!=null){
                  data.setCardNo(req.getString("uid"));
              }
              if(req.get("sid")!=null){
                  //检测设备id
                  data.setSid(req.getString("sid"));
              }
              if(req.get("rt")!=null){
                  //测量时间
                  int minute=req.getInteger("rt");
                  try {
                      Date rt= DateUtil.transferStr2Date(DateUtil.paserTime(minute),"yyyy-MM-dd HH:mm:ss");
                      data.setRt(rt);
                  } catch (ParseException e) {
                      e.printStackTrace();
                  }
              }
              data.setCreateTime(new Date());
              if(req.get("df")!=null){
                  //类型：transmission表示数据格式为透传电阻值
                  data.setDf(req.getString("df"));
              }
              if(req.get("resistor")!=null){
                  //电阻值
                  data.setResistor(req.getInteger("resistor"));
              }
              data.setAvailable(1);
              i=this.fatERDataDao.insertSelective(data);
          }
*/
          if("data_fat".equals(configCode)){
              //脂肪数据
              FatData data=new FatData();
              data.setId(UUID.randomUUID().toString());
              if(req.get("uid")!=null){
                  data.setCardNo(req.getString("uid"));
              }
              if(req.get("sid")!=null){
                  //检测设备id
                  data.setSid(req.getString("sid"));
              }
              if(req.get("rt")!=null){
                  //测量时间
                  int minute=req.getInteger("rt");
                  try {
                      Date rt= DateUtil.transferStr2Date(DateUtil.paserTime(minute),"yyyy-MM-dd HH:mm:ss");
                      data.setRt(rt);
                  } catch (ParseException e) {
                      e.printStackTrace();
                  }
              }
              data.setCreateTime(new Date());
              data.setAvailable(1);
              if(req.get("un")!=null){
                  //用户编号
                  data.setUn(req.getString("un"));
              }
              if(req.get("hg")!=null){
                  //身高
                  data.setHg(req.getInteger("hg"));
              }
              if(req.get("wg")!=null){
                  //体重
                  data.setWg(req.getFloat("wg"));
              }
              if(req.get("ag")!=null){
                  //年龄
                  data.setAge(req.getInteger("ag"));
              }
              if(req.get("sex")!=null){
                  data.setSex(req.getInteger("sex"));
              }
              if(req.get("cd")!=null){
                  //数据的测量时间
                  data.setCd(req.getDate("cd"));
              }
              if(req.get("fc")!=null){
                  //脂肪含量
                  data.setFc(req.getFloat("fc"));
              }
              if(req.get("bmi")!=null){
                 //体脂质数
                  data.setBmi(req.getFloat("bmi"));
              }
              if(req.get("bmr")!=null){
                  //基础代谢值(单位kcal/日)
                  data.setBmr(req.getInteger("bmr"));
              }
              if(req.get("bmir")!=null){
                  //体脂结果
                  data.setBmir(req.getInteger("bmir"));
              }
              if(req.get("bt")!=null){
                  //体型类型
                  data.setBt(req.getInteger("bt"));
              }
              Map map=this.urineDataDao.selectOneData(data.getRt(),"tbl_fat_data");
              if(map==null){
                  i=this.fatDataDao.insertSelective(data);
              }

          }
          if(i>0){
              json.put("success",true);
              json.put("message","入库成功");
          }else{
              json.put("success",false);
              json.put("message","入库失败");
          }
      }else{
          json.put("success",false);
          json.put("message","无效数据不记录入库");
      }
        return json.toJSONString();
    }

    @Override
    public String receiveDataNew(String requestData) {
        JSONObject json=new JSONObject();
        try {
                ReqData reqData = JSON.parseObject(requestData, ReqData.class);
                if (reqData != null && reqData.getData() != null && reqData.getData().size() > 0) {
                    //循环遍历获取检测数据
                    //IDCard是cardNo
                    for (CheckData data : reqData.getData()) {
                        //先存储总的消息
                        TestRecord record=new TestRecord();
                        record.setId(UUID.randomUUID().toString());
                        record.setRecord(JSONObject.toJSONString(data));
                        String cardNo = data.getIdCard();
                        record.setCardNo(cardNo);
                        record.setCreateTime(new Date());
                        int t = testRecordDao.insertSelective(record);
                        if(t>0){
                            //推送消息
                            //先通过卡号查询用户信息
                            Map<String,Object> map=new HashMap<>();
                            map.put("cardNo",cardNo);
                            MemberObj info=this.membersDao.getMemberByPara(map);
                            if(info!=null){
                                List<String> mesList=RuleUtil.checkPushMessage(data,info.getUserName());
                                if(mesList!=null&&mesList.size()>0){
                                    //推送个人  个人检测结果通知
                                    String res=pushMessageService.pushMessageToOne(info.getMemberId(),"健康提醒",mesList.get(0));
                                    System.out.println("推送返回:"+res);
                                    log.info("推送个人返回:"+res);
                                    //插入消息表
                                    if(res.indexOf("ok")!=-1){
                                        Message message=new Message();
                                        message.setMessage(mesList.get(0));
                                        message.setMessageId(UUID.randomUUID().toString());
                                        message.setSendDate(new Date());
                                        message.setAvailable(1);
                                        message.setReceiveUserId(info.getMemberId());
                                        message.setMessageType("03");
                                        message.setStatus("02");//状态按通过算
                                        message.setCreatedDate(new Date());
                                        this.messageDao.insertSelective(message);
                                    }
                                    //查询都那些人关注该用户 推送
                                    Map<String,Object> para=new HashMap<>();
                                    para.put("nickMemberId",info.getMemberId());
                                    para.put("concern",1);
                                    para.put("available",1);
                                    List<KithAndKin> kinList=kithAndKinDao.selectKithListByPara(para);
                                    if(kinList!=null&&kinList.size()>0){
                                        for(KithAndKin kin:kinList){
                                          String msg=mesList.get(1);
                                          if(kin.getRelationRemark()!=null){
                                              msg=msg.replace(info.getUserName(),kin.getRelationRemark());
                                          }
                                           //亲友检测结果通知
                                            String res1=pushMessageService.pushMessageToOne(kin.getMemberId(),"健康提醒",msg);
                                            System.out.println("推送亲友返回:"+res1);
                                            if(res1.indexOf("ok")!=-1){
                                                Message message=new Message();
                                                message.setMessage(msg);
                                                message.setMessageId(UUID.randomUUID().toString());
                                                message.setSendDate(new Date());
                                                message.setAvailable(1);
                                                message.setReceiveUserId(kin.getMemberId());
                                                message.setMessageType("03");
                                                message.setStatus("02");//状态按通过算
                                                message.setCreatedDate(new Date());
                                                this.messageDao.insertSelective(message);
                                            }
                                        }
                                    }
                                }
                            }
                            json.put("code", 2);
                            json.put("msg", "上传成功");
                        }else{
                            json.put("code", 1);
                            json.put("msg", "上传失败，未保存成功");
                        }
                    }
            }else{
                json.put("code", 1);
                json.put("msg", "上传失败，未保存成功");
            }
        }catch(Exception ex){
            throw new ServiceException(ex,"保存失败");
        }
       return  JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
