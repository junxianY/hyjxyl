package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.ContentRefDao;
import cn.comshinetechchina.hyjxyl.domain.ContentRef;
import cn.comshinetechchina.hyjxyl.service.ContentRefService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("contentRefService")
public class ContentRefServiceImpl implements ContentRefService {
    @Resource
    private ContentRefDao contentRefDao;
    @Override
    public int insertSelective(ContentRef record) {
        return contentRefDao.insertSelective(record);
    }

    @Override
    public ContentRef selectByPrimaryKey(String contentRefId) {
        return contentRefDao.selectByPrimaryKey(contentRefId);
    }

    @Override
    public int updateByPrimaryKeySelective(ContentRef record) {
        return contentRefDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public int batchInsertContentRef(List<ContentRef> list) {
        return this.contentRefDao.batchInsertContentRef(list);
    }

    @Override
    public int delContentRefById(String externalId) {
        return this.contentRefDao.delContentRefById(externalId);
    }


}
