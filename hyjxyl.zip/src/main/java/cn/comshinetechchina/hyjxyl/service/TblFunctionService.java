package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.TblFunction;

import java.util.List;
import java.util.Map;

public interface TblFunctionService {
    public List<TblFunction> selectFunctionList(Map<String,Object> map);
}
