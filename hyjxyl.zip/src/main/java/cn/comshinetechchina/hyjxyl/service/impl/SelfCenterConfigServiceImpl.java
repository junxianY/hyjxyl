package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.SelfCenterConfigDao;
import cn.comshinetechchina.hyjxyl.domain.SelfCenterConfig;
import cn.comshinetechchina.hyjxyl.service.SelfCenterConfigService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
@Service("selfCenterConfigService")
public class SelfCenterConfigServiceImpl implements SelfCenterConfigService {
    @Resource
    private SelfCenterConfigDao selfCenterConfigDao;
    @Override
    public int insertSelective(SelfCenterConfig record) {
        return selfCenterConfigDao.insertSelective(record);
    }

    @Override
    public SelfCenterConfig selectByPrimaryKey(String memberId) {
        return selfCenterConfigDao.selectByPrimaryKey(memberId);
    }

    @Override
    public int updateByPrimaryKeySelective(SelfCenterConfig record) {
        return selfCenterConfigDao.updateByPrimaryKeySelective(record);
    }
}
