package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.RoleDao;
import cn.comshinetechchina.hyjxyl.domain.Role;
import cn.comshinetechchina.hyjxyl.domain.RoleFunction;
import cn.comshinetechchina.hyjxyl.service.RoleService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;

@Service("roleService")
public class RoleServiceImpl implements RoleService {
    @Resource
    private RoleDao roleDao;

    @Override
    public int insertSelective(Role record) {
        return roleDao.insertSelective(record);
    }

    @Override
    public Role selectByPrimaryKey(Integer roleId) {
        return roleDao.selectByPrimaryKey(roleId);
    }

    @Override
    public int updateByPrimaryKeySelective(Role record) {
        return roleDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<RoleFunction> selectRoleFunctionList(Integer roleId) {
        return this.roleDao.selectRoleFunctionList(roleId);
    }

    @Override
    public List<Role> selectRoleList() {
        return this.roleDao.selectRoleList();
    }
}
