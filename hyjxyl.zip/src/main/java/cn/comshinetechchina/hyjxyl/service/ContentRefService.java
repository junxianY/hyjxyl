package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.ContentRef;

import java.util.List;

/**
 * 业务附件关联服务类
 */
public interface ContentRefService {
    int insertSelective(ContentRef record);
    ContentRef selectByPrimaryKey(String contentRefId);
    int updateByPrimaryKeySelective(ContentRef record);

    /**
     * 批量插入关键信息
     * @param list
     * @return
     */
    public int batchInsertContentRef(List<ContentRef> list);

    /**
     * 解除绑定附件
     *  @param externalId 业务id
     * @return
     */
    public int delContentRefById(String externalId);
}
