package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.BloodPressureData;
import java.util.List;
import java.util.Map;

/**
 * 血压服务接口
 */
public interface BloodPressureDataService {
    /**
     * 查询血压列表
     * @param page
     * @param map
     * @return
     */
    public List<BloodPressureData> selectBloodPressureDataList(PageBean page, Map<String,Object> map);

    /**
     * 查询图表数据
     * @param list
     * @return
     */
    public String packageChartData(List<BloodPressureData> list);

    /**
     * 通过个人id查询体检信息
     * @param memberId
     * @return
     */
    public List<BloodPressureData> selectMemberBloodPressureDataList(String memberId);

}
