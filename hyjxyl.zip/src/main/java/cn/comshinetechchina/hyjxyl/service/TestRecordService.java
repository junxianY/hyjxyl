package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.CheckData;
import cn.comshinetechchina.hyjxyl.domain.TestRecord;

import java.util.List;
import java.util.Map;

public interface TestRecordService {
    /**
     * 通过条件分页查询客户体检信息
     * @param map
     * @return
     */
    List<TestRecord> selectTestRecordList(Map<String,Object> map,PageBean bean);

    /**
     * 组装json数据
     * @param list
     * @param type 1:体重 2:血糖 3:血氧 4：血压\脉搏 5：血脂 6：尿酸 7体脂 8心率
     * @return
     */
    String packageChartData(List<CheckData> list, Integer type);

    /**
     * 通过条件查询客户所有体检信息
     * @param map
     * @return
     */
    List<TestRecord> selectAllTestRecordList(Map<String,Object> map);
}
