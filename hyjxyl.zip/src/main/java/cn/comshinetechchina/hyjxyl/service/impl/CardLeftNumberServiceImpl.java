package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.controller.CardController;
import cn.comshinetechchina.hyjxyl.dao.CardLeftNumberDao;
import cn.comshinetechchina.hyjxyl.dao.CardNumberChangeRecordDao;
import cn.comshinetechchina.hyjxyl.domain.CardLeftNumber;
import cn.comshinetechchina.hyjxyl.domain.CardLeftNumberKey;
import cn.comshinetechchina.hyjxyl.domain.CardNumberChangeRecord;
import cn.comshinetechchina.hyjxyl.service.CardLeftNumberService;
import cn.comshinetechchina.hyjxyl.service.CardNumberChangeRecordService;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service("cardLeftNumberService")
public class CardLeftNumberServiceImpl implements CardLeftNumberService {
    private static final Logger log = LoggerFactory.getLogger(CardLeftNumberServiceImpl.class);
    @Resource
    private CardLeftNumberDao cardLeftNumberDao;
    @Resource
    private CardNumberChangeRecordDao cardNumberChangeRecordDao;
    @Override
    public int batchInsertRecord(List<CardLeftNumber> list) {
        return cardLeftNumberDao.batchInsertRecord(list);
    }

    @Override
    public List<CardLeftNumber> selectCardLeftNumberList(Map<String, Object> map) {
        return cardLeftNumberDao.selectCardLeftNumberList(map);
    }

    @Override
    public int changeCardNo(String oldCardNo, String newCardNo) {
        return cardLeftNumberDao.changeCardNo(oldCardNo,newCardNo);
    }

    @Override
    public int updateByPrimaryKeySelective(CardLeftNumber record) {
        return cardLeftNumberDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public CardLeftNumber selectByPrimaryKey(CardLeftNumberKey key) {
        return cardLeftNumberDao.selectByPrimaryKey(key);
    }

    @Override
    public int modifyCardLeftNumber(String cardNo, String serviceId, Integer newLeftNum,String userId,String remark) {
        CardLeftNumberKey key = new CardLeftNumberKey();
        key.setCardNo(cardNo);
        key.setServiceId(serviceId);
        CardLeftNumber record = this.cardLeftNumberDao.selectByPrimaryKey(key);
        if(record==null){
            log.info("该卡不存在对应服务");
            return 0;
        }
        int preNumber = record.getLeftNumber();
        if (record != null) {
            try {
                record.setLeftNumber(newLeftNum);
                int i = this.cardLeftNumberDao.updateByPrimaryKeySelective(record);
                if (i > 0) {
                    //更新成功插入变更记录表
                    CardNumberChangeRecord changeRecord = new CardNumberChangeRecord();
                    changeRecord.setRecordId(UUID.randomUUID().toString());
                    changeRecord.setCardNo(cardNo);
                    changeRecord.setServiceId(serviceId);
                    changeRecord.setPreNumber(preNumber);
                    changeRecord.setAfterNumber(newLeftNum);
                    changeRecord.setRemark(remark);
                    changeRecord.setCreateTime(new Date());
                    changeRecord.setCreateBy(userId);
                    int t = cardNumberChangeRecordDao.insertSelective(changeRecord);
                    if(t>0){
                      log.info("更新卡编号："+cardNo+"的服务id:"+serviceId+"的新次数为："+newLeftNum);
                    }
                }
                return i;
            } catch (Exception ex) {
                throw new ServiceException("操作失败",ex);
            }
        }
        return 0;
    }

    @Override
    public int updateLeftNumberAvailable(String cardNo) {
        return this.cardLeftNumberDao.updateLeftNumberAvailable(cardNo);
    }

    @Override
    public int deleteInfoByPara(String cardNo) {
        return this.cardLeftNumberDao.deleteInfoByPara(cardNo);
    }

    @Override
    public int delRecordByTask(Date endDate) {
        return this.cardLeftNumberDao.delRecordByTask(endDate);
    }
}
