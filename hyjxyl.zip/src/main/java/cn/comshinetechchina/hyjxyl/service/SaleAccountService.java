package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.SaleAccount;

import java.util.List;
import java.util.Map;

/**
 * 销售专员接口服务
 */
public interface SaleAccountService {
    int deleteByPrimaryKey(String code);
    int insertSelective(SaleAccount record);
    SaleAccount selectByPrimaryKey(String code);
    int updateByPrimaryKeySelective(SaleAccount record);

    /**
     * 分页查询服务专员信息
     * @param map
     * @param page
     * @return
     */
    List<SaleAccount> querySaleAccountList(Map<String,Object> map,PageBean page);
}
