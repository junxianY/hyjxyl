package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.Comment;

import java.util.List;
import java.util.Map;

/**
 * 评论服务类
 */
public interface CommentService {
    int deleteByPrimaryKey(String commentId);
    int insertSelective(Comment record);
    Comment selectByPrimaryKey(String commentId);
    int updateByPrimaryKeySelective(Comment record);
    /**
     * 通过条件查询评论列表
     * @return
     */
    public List<Comment> selectCommentList(Map<String,Object> map);

    /**
     * 点赞方法
     * @param commentId 评论id
     * @param userId  点赞人
     * @param operate 1增加赞 2 取消赞
     * @return 1 成功 0失败
     */
    public int updateCommentFavour(String commentId,String userId,Integer operate);
}
