package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.WeightData;

import java.util.List;
import java.util.Map;

/**
 * 体重数据接口
 */
public interface WeightDataService {
    public List<WeightData> selectWeightDataList(PageBean page, Map<String,Object> map);

    /**
     * 组装图表数据
     * @param list
     * @return
     */
    public String packageChartData(List<WeightData> list);

    /**
     * 查询个人体重信息
     * @param memberId
     * @return
     */
    List<WeightData> selectMemberWeightDataList(String memberId);
}
