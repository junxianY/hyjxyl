package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.SelfCenterConfig;

/**
 * 老人配置中心服务类
 */
public interface SelfCenterConfigService {

    int insertSelective(SelfCenterConfig record);

    SelfCenterConfig selectByPrimaryKey(String memberId);


    int updateByPrimaryKeySelective(SelfCenterConfig record);
}
