package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.controller.LoginController;
import cn.comshinetechchina.hyjxyl.dao.ConfigDao;
import cn.comshinetechchina.hyjxyl.dao.ScreenDao;
import cn.comshinetechchina.hyjxyl.dao.TblServiceDao;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.ScreenService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service("screenService")
public class ScreenServiceImpl implements ScreenService {
    @Resource
    private ScreenDao screenDao;
    @Resource
    private ConfigDao configDao;
    @Resource
    private TblServiceDao tblServiceDao;
    private static final Logger log = LoggerFactory.getLogger(ScreenServiceImpl.class);

    @Override
    public int countMembers(int type) {
        return screenDao.countMembers(type);
    }

    @Override
    public String statisticsMembersByAge() {
        //折线图  sex 1男 2女
        //组装结果json
        JSONObject result = new JSONObject();
        JSONObject json = new JSONObject();
        //55-60  61-65 66-70 71-75 75以上
        int age1 = screenDao.statisticsMembersByAge(55, 60, 1);
        int age2 = screenDao.statisticsMembersByAge(61, 65, 1);
        int age3 = screenDao.statisticsMembersByAge(66, 70, 1);
        int age4 = screenDao.statisticsMembersByAge(71, 75, 1);
        int age5 = screenDao.statisticsMembersByAge(75, 140, 1);
        List<Integer> manList = new ArrayList<Integer>();
        manList.add(age1);
        manList.add(age2);
        manList.add(age3);
        manList.add(age4);
        manList.add(age5);

        //女
        int age6 = screenDao.statisticsMembersByAge(55, 60, 2);
        int age7 = screenDao.statisticsMembersByAge(61, 65, 2);
        int age8 = screenDao.statisticsMembersByAge(66, 70, 2);
        int age9 = screenDao.statisticsMembersByAge(71, 75, 2);
        int age10 = screenDao.statisticsMembersByAge(75, 140, 2);
        List<Integer> womanList = new ArrayList<Integer>();
        womanList.add(age6);
        womanList.add(age7);
        womanList.add(age8);
        womanList.add(age9);
        womanList.add(age10);
        //柱形分类
        List<String> legend = new ArrayList<String>();
        legend.add("男");
        legend.add("女");
        JSONObject legendData = new JSONObject();
        legendData.put("data", legend);
        json.put("legend", legendData);
        //存放x轴数据
        JSONObject xAxis = new JSONObject();
        xAxis.put("type", "category");
        //y轴数据
        List<Object> series = new ArrayList<Object>();
        List<String> xAxisData = new ArrayList<String>();
        xAxisData.add("55～60");
        xAxisData.add("61～65");
        xAxisData.add("66～70");
        xAxisData.add("71～75");
        xAxisData.add("75以上");
        xAxis.put("data", xAxisData);
        xAxis.put("type", "category");
        json.put("xAxis", xAxis);

        JSONObject womanData = new JSONObject();
        womanData.put("name", "女");
        womanData.put("type", "bar");
        womanData.put("data", womanList);

        JSONObject manData = new JSONObject();
        manData.put("name", "男");
        manData.put("type", "bar");
        manData.put("data", manList);
        series.add(manData);
        series.add(womanData);

        json.put("series", series);
        result.put("data", json);
        result.put("success", true);
        result.put("message", "查询成功");
        return JSONObject.toJSONString(result, SerializerFeature.WriteMapNullValue);
    }

    @Override
    public String statisticsMembersByEducation() {
        //柱状图  教育程度
        JSONObject result = new JSONObject();
        //组装结果json
        JSONObject json = new JSONObject();
        //柱形分类
        List<String> legend = new ArrayList<String>();
        legend.add("男");
        legend.add("女");
        JSONObject legendData = new JSONObject();
        legendData.put("data", legend);
        json.put("legend", legendData);

        //x坐标
        JSONObject xAxis = new JSONObject();
        xAxis.put("type", "category");
        //显示值
        List<Object> series = new ArrayList<Object>();

        List<String> xValues = new ArrayList<String>();
        List<Integer> seriesValues1 = new ArrayList<Integer>();

        // 20180911 改造分男女显示
        Map<String, Object> para = new HashMap<String, Object>();
        para.put("sex", 1);
        List<Map<String, Object>> manList = this.screenDao.statisticsMembersEducation(para);

        if (manList != null && manList.size() > 0) {
            for (Map<String, Object> map : manList) {
                String educationName = map.get("educationName").toString();
                xValues.add(educationName);
                String total = map.get("total") != null ? map.get("total").toString() : "0";
                seriesValues1.add(total == null ? 0 : Integer.parseInt(total));
            }
        }
        JSONObject manData = new JSONObject();
        manData.put("name", "男");
        manData.put("type", "bar");
        manData.put("data", seriesValues1);
        series.add(manData);
        para.put("sex", 2);
        List<Map<String, Object>> womanList = this.screenDao.statisticsMembersEducation(para);
        List<Integer> seriesValues2 = new ArrayList<Integer>();
        if (womanList != null && womanList.size() > 0) {
            for (Map<String, Object> map : manList) {
                String total = map.get("total") != null ? map.get("total").toString() : "0";
                seriesValues2.add(total == null ? 0 : Integer.parseInt(total));
            }
        }
        JSONObject womanData = new JSONObject();
        womanData.put("name", "女");
        womanData.put("type", "bar");
        womanData.put("data", seriesValues2);
        series.add(womanData);

        xAxis.put("data", xValues);
        json.put("xAxis", xAxis);
        json.put("series", series);
        result.put("data", json);
        result.put("success", true);
        result.put("message", "查询成功");
        return JSONObject.toJSONString(result, SerializerFeature.WriteMapNullValue);
    }

    @Override
    public String statisticsByDisease(Integer sex) {
        //遍历疾病名称 统计 饼状图 男女 区分 两个update 20180911
        JSONObject result = new JSONObject();
        JSONObject data = new JSONObject();
        List<Config> list = this.configDao.selectConfigList("disease", 1);

        //分类
        JSONObject legend = new JSONObject();
        List<String> legendData = new ArrayList<String>();
        legend.put("orient", "vertical");
        legend.put("x", "left");
        //分类值
        JSONObject series = new JSONObject();
        series.put("name", "疾病人数");
        series.put("type", "pie");
        series.put("radius", "55%");
        series.put("center", new String[]{"50%", "60%"});

        List<Map> seriesData = new ArrayList<Map>();
        if (list != null && list.size() > 0) {
            int count = 0;
            Map<String, Object> map = null;
            for (Config config : list) {
                //根据配置遍历疾病 查询其总数
                legendData.add(config.getConfigValue());
                count = this.screenDao.countOneDisease(config.getConfigValue(), sex);
                map = new HashMap<String, Object>();
                map.put("value", count);
                map.put("name", config.getConfigValue());
                seriesData.add(map);
            }
        }
        legend.put("data", legendData);
        series.put("data", seriesData);
        data.put("series", series);
        data.put("legend", legend);
        result.put("data", data);
        result.put("success", true);
        result.put("message", "查询成功");
        return JSONObject.toJSONString(result, SerializerFeature.WriteMapNullValue);
    }

    @Override
    public String statisticsByService() {
        //累计服务总人次  折线图
        JSONObject json = new JSONObject();
        JSONObject result = new JSONObject();
        //查询服务列表
        Map<String, String> map = new HashMap<String, String>();
        map.put("available", "1");
        List<TblService> serviceList = this.tblServiceDao.queryServiceList(map);
        List<String> legendData = new ArrayList<String>();
        if (serviceList != null && serviceList.size() > 0) {
            for (TblService info : serviceList) {
                legendData.add(info.getName());
            }
            legendData.add("总计");
        }
        log.info("一共" + legendData.size() + "个服务");
        //存放显示标识
        JSONObject legend = new JSONObject();
        legend.put("data", legendData);
        json.put("legend", legend);

        //每项服务各月总人次
        List<ServiceStatistics> list = this.screenDao.selectServiceStatistics(null);
        if (list != null && list.size() > 0) {
            //组装数据
            //x轴
            JSONObject xAxis = new JSONObject();
            //y轴 集合
            List<JSONObject> seriesList = new ArrayList<JSONObject>();
            //存放总计的列值
            List<Integer> totalList = new ArrayList<Integer>();
            //将结果根据月份分组
            Map<String, List<ServiceStatistics>> monthList = list.stream().collect(Collectors.groupingBy(ServiceStatistics::getUseDate));
            List<String> xAxisData = new ArrayList<String>();
            //遍历map，将横坐标值固定
            if (monthList != null) {
                for (String key : monthList.keySet()) {
                    xAxisData.add(key);
                    List<ServiceStatistics> sList = monthList.get(key);
                    //将各月的总数计算
                    if (sList != null && sList.size() > 0) {
                        int total = 0;
                        for (ServiceStatistics ss : sList) {
                            int count = StringUtils.isNotBlank(ss.getCount()) ? Integer.parseInt(ss.getCount()) : 0;
                            total += count;
                        }
                        totalList.add(total);
                    }
                }
            }
            //升序排列
            Collections.sort(xAxisData);
            xAxis.put("type", "category");
            xAxis.put("boundaryGap", false);
            xAxis.put("data", xAxisData);
            json.put("xAxis", xAxis);

            //将结果根据服务名称分组
            //Map<String, List<ServiceStatistics>> serviceNameList = list.stream().collect(Collectors.groupingBy(ServiceStatistics::getServiceName));
            //将结果过滤
            if (legendData.size() > 0) {
                JSONObject obj = null;
                List<Integer> countList = null;
                for (String serviceName : legendData) {
                    obj = new JSONObject();
                    countList = new ArrayList<Integer>();
                    List<ServiceStatistics> filterList = list.stream().filter(a -> a.getServiceName().equals(serviceName)).collect(Collectors.toList());
                    Collections.sort(filterList);
                    //通过横坐标循环
                    if (xAxisData.size() > 0) {
                        for (String month : xAxisData) {
                            if (filterList != null && filterList.size() > 0) {
                                //存在的话匹配对应月份值
                                int count = 0;
                                for (ServiceStatistics info : filterList) {
                                    if (info.getUseDate().equals(month)) {
                                        count = StringUtils.isBlank(info.getCount()) ? 0 : Integer.parseInt(info.getCount());
                                    }
                                }
                                countList.add(count);
                            } else {
                                countList.add(0);//不存在时为0
                            }
                        }
                    }
                    obj.put("name", serviceName);
                    obj.put("type", "line");
                    obj.put("data", countList);
                    seriesList.add(obj);
                }
                //最后加上总计的列
                obj = new JSONObject();
                obj.put("name", "总计");
                obj.put("type", "line");
                obj.put("data", totalList);
                seriesList.add(obj);
                json.put("series", seriesList);
            }
            log.info("返回结果:" + json.toJSONString());
            result.put("data", json);
            result.put("success", true);
            result.put("message", "查询成功");
        } else {
            result.put("data", json);
            result.put("success", false);
            result.put("message", "数据为空");
        }
        return JSONObject.toJSONString(result, SerializerFeature.WriteMapNullValue);
    }

    @Override
    public List<CardUseRecord> getCardUseList() {
        return null;
    }

    @Override
    public String statisticsByLiveCategory() {
        JSONObject result = new JSONObject();
        JSONObject json = new JSONObject();
        //柱形分类
        List<String> legend = new ArrayList<String>();
        legend.add("男");
        legend.add("女");
        JSONObject legendData = new JSONObject();
        legendData.put("data", legend);
        json.put("legend", legendData);
        //存放x轴数据
        JSONObject xAxis = new JSONObject();
        xAxis.put("type", "category");
        //y轴数据
        List<Object> series = new ArrayList<Object>();


        //居住类型统计 柱状图
        //先查询女的 在查询男的 再合并结果
        Map<String, Object> para = new HashMap<String, Object>();
        para.put("sex", 2);
        List<Map<String, Object>> list = this.screenDao.queryMembersByLiveCategory(para);

        para.put("sex", 1);
        List<Map<String, Object>> manList = this.screenDao.queryMembersByLiveCategory(para);
        List<String> xAxisData = new ArrayList<String>();
        List<Integer> seriesData1 = new ArrayList<Integer>();
        //循环女性结果集加入值
        for (Map<String, Object> map : list) {
            String categoryName = map.get("categoryName").toString();
            xAxisData.add(categoryName);
            String total = map.get("total") != null ? map.get("total").toString() : "0";
            seriesData1.add(total == null ? 0 : Integer.parseInt(total));
        }
        JSONObject womanData = new JSONObject();
        womanData.put("name", "女");
        womanData.put("type", "bar");
        womanData.put("data", seriesData1);

        List<Integer> seriesData2 = new ArrayList<Integer>();
        //循环男性结果集加入值
        for (Map<String, Object> map : manList) {
            String total = map.get("total") != null ? map.get("total").toString() : "0";
            seriesData2.add(total == null ? 0 : Integer.parseInt(total));
        }
        JSONObject manData = new JSONObject();
        manData.put("name", "男");
        manData.put("type", "bar");
        manData.put("data", seriesData2);
        series.add(manData);
        series.add(womanData);

        xAxis.put("data", xAxisData);
        json.put("xAxis", xAxis);
        json.put("series", series);
        result.put("data", json);
        result.put("success", true);
        result.put("message", "查询成功");
        return JSONObject.toJSONString(result, SerializerFeature.WriteMapNullValue);
    }

    @Override
    public List<ServiceStatistics> statisticsMembersByServiceName(Map<String, Object> map) {
        return this.screenDao.statisticsMembersByServiceName(map);
    }

    @Override
    public List<ServiceStatistics> statisticsCardUseRecord(Map<String, Object> map) {
        return this.screenDao.statisticsCardUseRecord(map);
    }

    @Override
    public List<StatisticsArticle> statisticsArticles(Map<String, Object> map) {
        return this.screenDao.statisticsArticles(map);
    }

    @Override
    public String statisticMemberService(String startDate, String endDate) {
        //统计服务每天总次数折线图
        System.out.println("startDate:"+startDate+"---endDate:"+endDate);
        JSONObject result = new JSONObject();
        JSONObject json = new JSONObject();
        Map<String, Object> para = new HashMap<String, Object>();
        para.put("startDate", startDate);
        para.put("endDate", endDate);
        //男的
        para.put("sex", 1);
        List<Map<String, Object>> manList = this.screenDao.statisticsCardUse(para);
        //女的
        para.put("sex", 2);
        List<Map<String, Object>> womanList = this.screenDao.statisticsCardUse(para);
        //横坐标日期值
        List<String> xAxisData = countDays(startDate,endDate);
        if(xAxisData==null||xAxisData.size()<=0){
            result.put("data", "");
            result.put("success", false);
            result.put("message", "没有数据");
            return result.toJSONString();
        }

        List<Integer> y1 =  new ArrayList<Integer>();
        List<Integer> y2 =  new ArrayList<Integer>();

            for(String date:xAxisData){
                if (manList != null && manList.size() > 0) {
                //对应日期查找对应的次数
                boolean isMatch=false;
                for(Map<String,Object> map:manList){
                    String date1=map.get("day").toString();
                    if(date1.equals(date)){
                        String total =map.get("total") != null ? map.get("total").toString() : "0";
                        y1.add(Integer.parseInt(total));
                        isMatch=true;
                        break;
                    }
                }
                if(!isMatch){
                    y1.add(0);
                }
            }else{
                    y1.add(0);
            }

            if (womanList != null && womanList.size() > 0) {
                //对应日期查找对应的次数
                boolean isMatch=false;
                for(Map<String,Object> map:womanList){
                        String date1=map.get("day").toString();
                        if(date1.equals(date)){
                            String total =map.get("total") != null ? map.get("total").toString() : "0";
                            y2.add(Integer.parseInt(total));
                            isMatch=true;
                            break;
                        }
                    }
                    if(!isMatch){
                        y2.add(0);
                    }
            }else{
                y2.add(0);
            }
        }

        JSONObject legendData = new JSONObject();
        legendData.put("data", new String[]{"男", "女"});
        json.put("legend", legendData);

        JSONObject xAxis = new JSONObject();
        xAxis.put("type", "category");
        xAxis.put("boundaryGap", false);
        xAxis.put("data", xAxisData);
        json.put("xAxis",xAxis);
        List<Object> series = new ArrayList<Object>();
        JSONObject manSeries=new JSONObject();
        manSeries.put("name","男");
        manSeries.put("type","line");
        manSeries.put("data",y1);
        series.add(manSeries);
        JSONObject womanSeries=new JSONObject();
        womanSeries.put("name","女");
        womanSeries.put("type","line");
        womanSeries.put("data",y2);
        series.add(womanSeries);
        json.put("series",series);
        result.put("data", json);
        result.put("success", true);
        result.put("message", "查询成功");
        return JSONObject.toJSONString(result, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 返回改日期段的日期
     *
     * @param startDate yyyy-MM-dd
     * @param endDate  yyyy-MM-dd
     * @return
     */
    public static List<String> countDays(String startDate, String endDate) {
        List<String> listDate = new ArrayList<String>();
        Calendar startCalendar = Calendar.getInstance();
        Calendar endCalendar = Calendar.getInstance();
        try {
            startCalendar.setTime(DateUtil.transferStr2Date(startDate, "yyyy-MM-dd"));
            endCalendar.setTime(DateUtil.transferStr2Date(endDate, "yyyy-MM-dd"));
        } catch (ParseException e) {
            throw new ServiceException("日期格式化异常", e);
        }
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        while (true) {
            if (startCalendar.getTimeInMillis() <=endCalendar.getTimeInMillis()) {
                listDate.add(df.format(startCalendar.getTime()));
                System.out.print(df.format(startCalendar.getTime()) + "---");
                startCalendar.add(Calendar.DATE, 1);
            } else {
                break;
            }
        }
        return listDate;
    }

    @Override
    public String statisticsHealthMonitorData() {
      JSONObject result=new JSONObject();
      Map<String,Object> para=new HashMap<String,Object>();
      para.put("tableName","tbl_blood_sugar_data");
      //血糖
      List<HealthMonitorObj>  list=new ArrayList<HealthMonitorObj>();
      HealthMonitorObj obj=null;
      int count1=this.screenDao.totalCount(para);
      para.put("bs","1");
      List<Map<String,Object>> list1=this.screenDao.selectResultByCheck(para);
      obj=new HealthMonitorObj();
      obj.setName("血糖");
      obj.setTotalCount(count1);
      if(list1!=null&&list1.size()>0){
          obj.setAlarmCount(list1.size());
      }else{
          obj.setAlarmCount(0);
      }
      list.add(obj);
      //血压
       para.clear();
       para.put("tableName","tbl_blood_pressure_data");
       para.put("dp","1");
       int count2=this.screenDao.totalCount(para);
       List<Map<String,Object>> list2=this.screenDao.selectResultByCheck(para);
        obj=new HealthMonitorObj();
        obj.setName("血压");
        obj.setTotalCount(count2);
        if(list2!=null&&list2.size()>0){
            obj.setAlarmCount(list2.size());
        }else{
            obj.setAlarmCount(0);
        }
        list.add(obj);

        // 血氧
        para.clear();
        para.put("tableName","tbl_blood_oxygen_data");
        int count3=this.screenDao.totalCount(para);
        para.put("ox","1");
        List<Map<String,Object>> list3=this.screenDao.selectResultByCheck(para);
        obj=new HealthMonitorObj();
        obj.setName("血氧");
        obj.setTotalCount(count3);
        if(list3!=null&&list3.size()>0){
            obj.setAlarmCount(list3.size());
        }else{
            obj.setAlarmCount(0);
        }
        list.add(obj);

       //心率
        para.clear();
        para.put("tableName","tbl_blood_oxygen_data");
        para.put("ps","1");
        int count4=this.screenDao.totalCount(para);
        List<Map<String,Object>> list4=this.screenDao.selectResultByCheck(para);
        obj=new HealthMonitorObj();
        obj.setName("心率");
        obj.setTotalCount(count4);
        if(list4!=null&&list4.size()>0){
            obj.setAlarmCount(list4.size());
        }else{
            obj.setAlarmCount(0);
        }
        list.add(obj);
        result.put("data",list);
        result.put("success",true);
        result.put("message","查询成功");
       return JSONObject.toJSONString(result, SerializerFeature.WriteMapNullValue);
    }
}