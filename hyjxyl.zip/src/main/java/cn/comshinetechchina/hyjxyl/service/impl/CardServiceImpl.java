package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.*;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.CardLeftNumberHistoryService;
import cn.comshinetechchina.hyjxyl.service.CardService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import cn.comshinetechchina.hyjxyl.util.ToolUtil;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

@Service("cardService")
public class CardServiceImpl implements CardService {
    private static final Logger log = LoggerFactory.getLogger(CardService.class);
    @Resource
    private CardDao cardDao;
    @Resource
    private CardLeftNumberDao cardLeftNumberDao;
    @Resource
    private CardTypeServiceDao  cardTypeServiceDao;
    @Resource
    private MembersDao membersDao;
    @Resource
    private TblLogDao logDao;
    @Resource
    private CardChangeRecordDao cardChangeRecordDao;
    @Resource
    private CardLeftNumberHistoryService cardLeftNumberHistoryService;
    @Override
    public int insertSelective(Card record) {
        return cardDao.insertSelective(record);
    }

    @Override
    public Card selectByPrimaryKey(String cardId) {
        return cardDao.selectByPrimaryKey(cardId);
    }

    @Override
    public int updateByPrimaryKeySelective(Card record) {
        return cardDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public int deleteByPrimaryKey(String cardId) {
        return cardDao.deleteByPrimaryKey(cardId);
    }

    @Override
    public List<CardObj> selectCardList(Map<String, Object> map) {
        return this.cardDao.selectCardList(map);
    }

    @Override
    public int bindCard(String cardNo, String cardTypeId,Integer timeLimit,Date startDate,Date endDate) {
        //step1 根据卡类型查询相应服务
        List<CardLeftNumber> insertList=null;
        int i=0;
        Map<String,String> map=new HashMap<String,String>();
        map.put("cardTypeId",cardTypeId);
        map.put("available","1");
        List<CardTypeService>   cardTypeServiceList=cardTypeServiceDao.selectCardTypeServiceList(map);
        if(cardTypeServiceList!=null&&cardTypeServiceList.size()>0){
         //step2 循环卡类型相应服务 加入插入集合
         insertList=new ArrayList<CardLeftNumber>();
         CardLeftNumber leftInfo=null;
         for(CardTypeService info:cardTypeServiceList){
             leftInfo=new CardLeftNumber();
             leftInfo.setCardNo(cardNo);
             leftInfo.setServiceId(info.getServiceId());
             //总次数
             leftInfo.setTotalNumber(info.getTotalCount());
             //剩余次数 满次
             leftInfo.setLeftNumber(info.getTotalCount());
             //根据单位计算起始结束日期
             leftInfo.setStartDate(new Date());
             //结束日期
             if (0 == timeLimit) {
                 leftInfo.setEndDate(DateUtil.getSysDate(0, 6, 0));
             } else if (1 == timeLimit) {
                 leftInfo.setEndDate(DateUtil.getSysDate(1, 0, 0));
             }
             //起始日期不为空时
             if(startDate!=null){
                 leftInfo.setStartDate(startDate);
             }
             if(endDate!=null){
                 leftInfo.setEndDate(endDate);
             }
             leftInfo.setCreateDate(new Date());
             leftInfo.setAvailable(1);
             insertList.add(leftInfo);
         }
        }
        //step3  批量插入卡服务剩余次数信息
        if(!insertList.isEmpty()){
           i=cardLeftNumberDao.batchInsertRecord(insertList);
        }
        return i;
    }

    @Override
    public String changeCard(String memberId,String newCardNo,String faceNo,String userId,String userName,String ip) {
        JSONObject json=new JSONObject();
        //根据员工查询出卡id
        Members member=membersDao.selectByPrimaryKey(memberId);
        String cardId="";
        String oldCardNo="";
        if(member!=null){
            cardId=member.getCardId();
        }
        Card oldCard=null;
        //查询出旧卡信息
        if(StringUtils.isNotBlank(cardId)){
            oldCard=this.cardDao.selectByPrimaryKey(cardId);
        }
        if(oldCard!=null){
            oldCardNo=oldCard.getCardNo();
            //进行操作  1.旧卡置为无效，状态为解绑 2.插入一条新的卡记录 3.更新个人信息关联卡id 4.卡剩余次数表旧记录更新为无效 5.将卡剩余次数记录移到历史表 6.批量插入新记录
            //7.插入客户卡变更记录CardChangeRecord
            oldCard.setAvailable(0);
            oldCard.setStatus(-1);
            int i=this.cardDao.updateByPrimaryKey(oldCard);
            if(i>0){
                log.info(cardId+"旧卡更新无效成功");
                Card newCard=new Card();
                BeanUtils.copyProperties(oldCard,newCard);
                String newCardId=UUID.randomUUID().toString();
                newCard.setCardId(newCardId);
                newCard.setCardNo(newCardNo);
                newCard.setFaceNo(faceNo);
                newCard.setAvailable(1);
                newCard.setDescription("旧卡id:"+cardId);
                int t=this.cardDao.insertSelective(newCard);
                //增加变更记录表 add 2018.11.27
                CardChangeRecord ccr=new CardChangeRecord();
                ccr.setRecordId(UUID.randomUUID().toString());
                ccr.setCardNo(newCardNo);
                ccr.setChangeTime(new Date());
                ccr.setMemberId(memberId);
                if(t>0){
                    log.info("插入新卡信息成功，新id:"+newCardId);
                    Members member1=new Members();
                    member1.setMemberId(memberId);
                    member1.setCardId(newCardId);
                    int j=membersDao.updateByPrimaryKeySelective(member1);
                    //插入变更记录
                    int t1=cardChangeRecordDao.insertSelective(ccr);
                    if(t1>0){
                        log.info("插入个人卡变更记录表成功");
                    }
                    if(j>0){
                       log.info("更新客户绑定卡id成功");
                      // int g=cardLeftNumberDao.changeCardNo(oldCardNo,newCardNo);
                       Map<String,Object> map=new HashMap<String,Object>();
                       map.put("cardNo",oldCardNo);
                       map.put("available",1);
                       List<CardLeftNumber> list=this.cardLeftNumberDao.selectCardLeftNumberList(map);
                       int g=cardLeftNumberDao.updateLeftNumberAvailable(oldCardNo);
                       if(g>0){
                           log.info("更新旧卡状态为无效成功");
                       }
                       //旧记录移入历史表
                       int p=cardLeftNumberHistoryService.moveCardLeftNumber(oldCardNo,null);
                       //删除旧记录
                       if(p>0){
                           int m=this.cardLeftNumberDao.deleteInfoByPara(oldCardNo);
                           if(m>0){
                               //批量插入新记录
                               if(list!=null&&list.size()>0){
                                   //替换卡编号
                                   for(CardLeftNumber obj:list){
                                       obj.setCardNo(newCardNo);
                                   }
                                   //插入新纪录
                                   int f=this.cardLeftNumberDao.batchInsertRecord(list);
                                   if(f>0){
                                       log.info("插入了"+f+"条新的卡剩余次数记录，卡编号为："+newCardNo);
                                   }
                               }
                               json.put("success",true);
                               json.put("message","操作成功");
                               //成功的话插入日志
                               TblLog record = new TblLog();
                               record.setLogId(UUID.randomUUID().toString());
                               record.setUserId(userId);
                               record.setUserName(userName);
                               record.setUserIp(ip);
                               record.setOperateTableName("tbl_members");
                               record.setOperateTableId(memberId);
                               StringBuffer content=new StringBuffer("换卡操作:");
                               content.append("变更前卡号："+oldCardNo+",卡面卡号"+oldCard.getFaceNo()+";变更后卡号:"+newCardNo+",卡面卡号:"+faceNo);
                               record.setOperateContent(content.toString());
                               record.setOperateTime(new Date());
                               record.setComments(memberId); //备注为客户id
                               record.setType(6);
                               logDao.insertSelective(record);
                           }
                       }
                   }
                }else{
                    json.put("success",false);
                    json.put("message","更新出错，未找到记录");
                }
            }else{
                json.put("success",false);
                json.put("message","更新出错，未找到记录");
            }
        }else{
            log.info("未查询到相应卡信息");
            json.put("success",false);
            json.put("message","操作失败，未查询到相应卡信息");
        }
        return json.toJSONString();

    }

    @Override
    public int batchUpdateCardStatus(List<String> cardNos, int available, String remark,String userId,String userName) {
        int i=this.cardDao.batchUpdateCardStatus(cardNos,available);
        if(i>0){
            //插入用户操作日志表
            for(String cardNo:cardNos){
                TblLog record=new TblLog();
                record.setLogId(UUID.randomUUID().toString());
                record.setOperateTime(new Date());
                if(1==available){
                    record.setOperateContent("启用卡:"+cardNo);
                    record.setType(3);
                }
                if(0==available){
                    record.setOperateContent("禁用卡:"+cardNo);
                    record.setType(5);
                }
                record.setOperateTableName("tbl_cards");
                record.setUserId(userId);
                record.setUserName(userName);

                //通过卡编号查询客户id
                Map<String,Object> map=new HashMap<>();
                map.put("cardNo",cardNo);
                MemberObj obj=this.membersDao.getMemberByPara(map);
                if(obj!=null){
                    record.setComments(obj.getMemberId()); //操作卡的 备注为用户id
                    record.setOperateTableId(obj.getCardId()); //主键id
                }
                this.logDao.insertSelective(record);
            }
        }
        return i;
    }

    @Override
    public String removeCardBind(String memberId) {
        JSONObject json=new JSONObject();
        //根据员工查询出卡id
        Members member=membersDao.selectByPrimaryKey(memberId);
        String cardId="";
        if(member!=null){
            cardId=member.getCardId();
        }
        Card oldCard=null;
        //查询出旧卡信息
        if(StringUtils.isNotBlank(cardId)){
            oldCard=this.cardDao.selectByPrimaryKey(cardId);
        }
        if(oldCard!=null){
            //进行操作  1.旧卡置为无效，状态为解绑 2.更新个人信息关联卡id为空
            oldCard.setAvailable(0);
            oldCard.setStatus(-1);
            int i=this.cardDao.updateByPrimaryKey(oldCard);
            if(i>0){
                    log.info(cardId+"旧卡更新无效成功");
                    Members member1=new Members();
                    member1.setMemberId(memberId);
                    member1.setCardId("");
                    int j=membersDao.updateByPrimaryKeySelective(member1);
                    if(j>0){
                        log.info("更新客户绑定卡id为空成功");
                        json.put("success",true);
                        json.put("message","操作成功");
                    }else{
                        json.put("success",false);
                        json.put("message","卡id置空失败");
                    }
            }else{
                json.put("success",false);
                json.put("message","更新出错，未找到记录");
            }
        }else{
            log.info("未查询到相应卡信息");
            json.put("success",false);
            json.put("message","操作失败，未查询到相应卡信息");
        }
        return json.toJSONString();
    }

    @Override
    public List<MemberInfo> selectCardMemberList(Map<String, String> map, PageBean bean) {
        return this.cardDao.selectCardMemberList(map,bean);
    }
}
