package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.CardTypeService;

import java.util.List;
import java.util.Map;

/**
 * 卡类别与服务关联服务类
 */
public interface CardTypeServiceService {
    int deleteByPrimaryKey(String cardTypeServiceId);
    int insertSelective(CardTypeService record);
    CardTypeService selectByPrimaryKey(String cardTypeServiceId);
    int updateByPrimaryKeySelective(CardTypeService record);

    /**
     * 通过条件查询卡服务关联列表
     * @param map
     * @return
     */
    public List<CardTypeService> selectCardTypeServiceList(Map<String,String> map);

    /**
     * 批量插入
     * @param list
     * @return
     */
    int batchInsertSelective(List<CardTypeService> list);

    /**
     * 删除某卡类型绑定服务
     * @param cardTypeId
     * @return
     */
    public int deleteRecordByPara(String cardTypeId);
}
