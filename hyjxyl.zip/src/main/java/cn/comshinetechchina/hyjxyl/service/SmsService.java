package cn.comshinetechchina.hyjxyl.service;

import java.util.Map;

/**
 * 短信接口类
 */
public interface SmsService {
    /**
     * 发送短信接口
     * @param phoneNum 手机号
     * @param signName 短信签名
     * @param templeteCode 模板code
     * @param paras  模板参数
     * @return
     */
    public Map<String,Object> sendMessage(String phoneNum, String signName, String templeteCode, String paras);
}
