package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.Message;

import java.util.List;
import java.util.Map;

public interface MessageService {

    int insertSelective(Message record);

    Message selectByPrimaryKey(String messageId);

    /**
     * 通过条件查询消息列表
     * @param map
     * @return
     */
    public List<Message> selectMessageList(Map<String,String> map);

    /**
     * 更新消息
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(Message record);
}
