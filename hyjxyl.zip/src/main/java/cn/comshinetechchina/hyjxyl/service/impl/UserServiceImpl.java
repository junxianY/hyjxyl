package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.UserDao;
import cn.comshinetechchina.hyjxyl.domain.User;
import cn.comshinetechchina.hyjxyl.service.UserService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("userService")
public class UserServiceImpl implements UserService {
    @Resource
    private UserDao userDao;
    @Override
    public int deleteByPrimaryKey(String userId) {
        return userDao.deleteByPrimaryKey(userId);
    }

    @Override
    public int insert(User record) {
        return userDao.insert(record);
    }

    @Override
    public int insertSelective(User record) {
        return userDao.insertSelective(record);
    }

    @Override
    public User selectByPrimaryKey(String userId) {
        return userDao.selectByPrimaryKey(userId);
    }

    @Override
    public int updateByPrimaryKeySelective(User record) {
        return userDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public User selectUserByPara(String userName, String password) {
        return userDao.selectUserByPara(userName,password);
    }

    @Override
    public List<User> selectUserList(Map<String, Object> map) {
        return this.userDao.selectUserList(map);
    }
}
