package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.MemberExtend;

import java.util.List;

/**
 * 老人扩展信息服务类
 */
public interface MemberExtendService {
    int insertSelective(MemberExtend record);

    MemberExtend selectByPrimaryKey(String memberId);

    int updateByPrimaryKeySelective(MemberExtend record);

    /**
     * 通过参数查询用户信息
     * @param record
     * @return
     */
    public List<MemberExtend> selectMemberExtendList(MemberExtend record);
}
