package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.BloodOxygenData;

import java.util.List;
import java.util.Map;

/**
 * 血氧数据接口
 */
public interface BloodOxygenDataService {
    /**
     * 分页查询血氧数据
     * @param page
     * @param map
     * @return
     */
    public List<BloodOxygenData> selectBloodOxygenDataList(PageBean page, Map<String, Object> map);
    public String packageChartData(List<BloodOxygenData> list);

    /**
     * 查询某客户血氧数据
     * @param memberId
     * @return
     */
    List<BloodOxygenData> selectMemberBloodOxygenDataList(String memberId);
}
