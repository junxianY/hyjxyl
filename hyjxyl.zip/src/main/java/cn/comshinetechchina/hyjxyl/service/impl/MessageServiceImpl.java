package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.MessageDao;
import cn.comshinetechchina.hyjxyl.domain.Message;
import cn.comshinetechchina.hyjxyl.service.MessageService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("messageService")
public class MessageServiceImpl implements MessageService {
    @Resource
    private MessageDao messageDao;
    @Override
    public int insertSelective(Message record) {
        return this.messageDao.insertSelective(record);
    }

    @Override
    public Message selectByPrimaryKey(String messageId) {
        return this.messageDao.selectByPrimaryKey(messageId);
    }

    @Override
    public List<Message> selectMessageList(Map<String, String> map) {
        return this.messageDao.selectMessageList(map);
    }

    @Override
    public int updateByPrimaryKeySelective(Message record) {
        return this.messageDao.updateByPrimaryKeySelective(record);
    }
}
