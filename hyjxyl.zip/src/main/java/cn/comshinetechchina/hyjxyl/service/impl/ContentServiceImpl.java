package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.dao.ConfigDao;
import cn.comshinetechchina.hyjxyl.dao.ContentDao;
import cn.comshinetechchina.hyjxyl.domain.Config;
import cn.comshinetechchina.hyjxyl.domain.Content;
import cn.comshinetechchina.hyjxyl.service.ContentService;
import cn.comshinetechchina.hyjxyl.util.JavaNetRequestImgUtil;
import com.alibaba.fastjson.JSONObject;
import net.coobird.thumbnailator.Thumbnails;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.util.UUID;
import javax.annotation.Resource;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service("contentService")
public class ContentServiceImpl implements ContentService {
    private static final org.slf4j.Logger log= LoggerFactory.getLogger(ContentServiceImpl.class);
    @Resource
    private ContentDao contentDao;
    @Resource
    private ConfigDao configDao;

    @Override
    public int insertSelective(Content record) {
        return contentDao.insertSelective(record);
    }

    @Override
    public Content selectByPrimaryKey(String contentId) {
        return contentDao.selectByPrimaryKey(contentId);
    }

    @Override
    public List<Content> selectContentsById(String busiId, String tableName, String contentTypeId) {
        return contentDao.selectContentsById(busiId,tableName,contentTypeId);
    }

    @Override
    public String saveFileUpload(MultipartFile upload, String contentName, String contentTypeId) {
        JSONObject resultJson = new JSONObject();
        if (upload != null && !upload.isEmpty() && upload.getSize() > 0) {
            List<Config> configList=configDao.selectConfigList("content_path",1);
            String uploadPathInDB ="/data";// 获取数据库中配置的文件的上传路径
            if(configList!=null&&configList.size()>0){
                uploadPathInDB=configList.get(0).getConfigValue();
            }
            if (StringUtils.isBlank(uploadPathInDB)) {
                resultJson.put("success", false);
                resultJson.put("message", "附件路径未设置，无法保存附件");
                return resultJson.toString();
            }
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd/hh/mm");
            String uploadPathInDisk=uploadPathInDB+"/"+sdf.format(new Date());//文件的上传路径按照日期进行存放
            File folder = new File(uploadPathInDisk);// 创建带日期文件夹
            if (!folder.exists()) {
                folder.mkdirs();
            }
            String filePath=uploadPathInDisk+ "/" + upload.getOriginalFilename();
            File file = new File(filePath);// 新文件在磁盘中的位置以及文件名
            try {
                upload.transferTo(file);// 将上传的文件写入磁盘中的指定位置
                //大于1兆的图片文件写入后进行压缩
                //Thumbnails.of("原图文件的路径").scale(1f).outputQuality(0.5f).toFile("压缩后文件的路径");
                String fileType =upload.getOriginalFilename().substring(upload.getOriginalFilename().lastIndexOf(".")+1);
                log.info("文件存放路径为:"+filePath+"fileType:"+fileType);
                if (isPhoto(fileType)&&upload.getSize() >= 1*1024*1024)
                {
                    Thumbnails.of(filePath).scale(1f).outputQuality(0.5f).toFile(filePath);
                }

            } catch (Exception e) {
                throw new ServiceException("保存文件到磁盘发生异常，请联系管理员", false);
            }
            // 将照片信息保存到附件表
            Content content = new Content();
            String contentId = UUID.randomUUID().toString();
            content.setCreateBy("user");
            content.setContentId(contentId);
            if(StringUtils.isNotEmpty(contentTypeId)){
                content.setContentTypeId(Long.valueOf(contentTypeId));
            }
            content.setComments(contentName);
            content.setFileName(upload.getOriginalFilename());
            content.setFileSize(file.length());
            content.setContentUrl(uploadPathInDisk + "/" + contentId
                    + upload.getOriginalFilename().substring(upload.getOriginalFilename().lastIndexOf(".")));
            content.setCreateTime(new Date());
            int count = contentDao.insertSelective(content);
            if (count > 0) {
                resultJson.put("success", true);
                resultJson.put("contentId", content.getContentId());
                resultJson.put("contentUrl", filePath);
            } else {
                resultJson.put("success", false);
                resultJson.put("message", "保存附件信息失败，请联系管理员");
                resultJson.put("contentUrl", "");
            }
        }else{
            resultJson.put("success", false);
            resultJson.put("message", "接收到的文件为空，请检查");
        }
        return resultJson.toString();
    }

    /**
     * 判断是否是图片
     * @param fileType
     * @return
     */
    public boolean isPhoto(String fileType) {
        if (fileType.equals("jpg") || fileType.equals("jpeg") || fileType.equals("jpe")||fileType.equals("gif")||fileType.equals("png")) {
            return true;
        }else{
            return false;
        }
    }
    @Override
    public String saveRemoteImg(String remotePath) {
        JSONObject resultJson=new JSONObject();
        //保存头像
        List<Config> configList=this.configDao.selectConfigList("content_path",1);
        String uploadPathInDB ="/data";// 获取数据库中配置的文件的上传路径
        if(configList!=null&&configList.size()>0){
            uploadPathInDB=configList.get(0).getConfigValue();
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd/hh/mm");
        String uploadPathInDisk=uploadPathInDB+"/"+sdf.format(new Date());//文件的上传路径按照日期进行存放
        File folder = new File(uploadPathInDisk);// 创建带日期文件夹
        if (!folder.exists()) {
            folder.mkdirs();
        }
        String contentName=remotePath.substring(remotePath.lastIndexOf("/")+1,remotePath.length())+".png";
        String fileSavePath=uploadPathInDisk+ "/" +contentName;
        log.info("保存图片地址为:"+fileSavePath);
        //调用工具类将图片保存到硬盘
        String result= JavaNetRequestImgUtil.saveRemoteImg(remotePath,fileSavePath);
        if(StringUtils.isNotBlank(result)&&((Boolean)JSONObject.parseObject(result).get("success"))){
            log.info("保存图片成功！");
            // 将照片信息保存到db附件表
            Content content = new Content();
            String contentId = UUID.randomUUID().toString();
            content.setCreateBy("user");
            content.setContentId(contentId);
            String contentTypeId="1001";
            content.setContentTypeId(Long.valueOf(contentTypeId));
            content.setComments("用户头像");
            content.setFileName(contentName);
           // content.setFileSize(upload.getSize());
            content.setContentUrl(fileSavePath);
            content.setCreateTime(new Date());
            int count = contentDao.insertSelective(content);
            if (count > 0) {
                resultJson.put("success", true);
                resultJson.put("message","操作成功");
                resultJson.put("contentId", content.getContentId());
            } else {
                resultJson.put("success", false);
                resultJson.put("message", "保存附件信息失败，请联系管理员");
                resultJson.put("contentId","");
            }
        }else{
            resultJson.put("success", false);
            resultJson.put("message", JSONObject.parseObject(result).get("message"));
            resultJson.put("contentId","");
        }
        return resultJson.toJSONString();
    }
}
