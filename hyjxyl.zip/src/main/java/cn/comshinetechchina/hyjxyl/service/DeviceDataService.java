package cn.comshinetechchina.hyjxyl.service;

/**
 * 数据中心接口
 */
public interface DeviceDataService {
    /**
     * 接收数据接口 JSON
     * @param data
     * @return
     */
    String receiveData(String data);

    /**
     * 接收数据接口 JSON new
     * @param requestData
     * @return
     */
   String receiveDataNew(String requestData);
}
