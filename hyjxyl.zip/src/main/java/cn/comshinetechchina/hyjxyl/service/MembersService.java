package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.MemberInfo;
import cn.comshinetechchina.hyjxyl.domain.MemberInfoObj;
import cn.comshinetechchina.hyjxyl.domain.MemberObj;
import cn.comshinetechchina.hyjxyl.domain.Members;

import java.util.List;
import java.util.Map;

/**
 * 老人用户服务接口
 */
public interface MembersService {
    /**
     * 查询用户信息
     * @param phoneNo 手机号
     * @param token
     * @return
     */
    public Members selectOneMembers(String phoneNo,String token);
    int insertSelective(Members record);
    int updateByPrimaryKeySelective(Members record);
    Members selectByPrimaryKey(String memberId);

    /**
     * 根据条件检索老人用户信息
     * @param map
     * @param bean
     * @return
     */
    public List<MemberInfo> selectMemberInfoList(Map<String,String> map,PageBean bean);

    /**
     * 查询个人明细信息
     * @param memberId
     * @return
     */
    public MemberInfo selectMemberInfoDetail(String memberId);
    /**
     * 批量更新用户状态接口
     * @param memberIds  客户id列表
     * @param available 状态
     * @param remark   备注
     * @param userId 用户id
     * @param userName 用户名
     * @return
     */
    public int batchUpdateMemberStatus(List<String> memberIds,int available,String remark,String userId,String userName);

    /**
     * 查询个人明细信息(扩展方法，查询所有属性)
     * @param memberId
     * @return
     */
    public MemberInfoObj selectMemberInfoObjDetail(String memberId);

    public MemberInfoObj selectOneMember(String openId);
    /**
     * 置空token值
     * @param memberId
     * @return
     */
    public int updateMembersToken(String memberId);

    /**
     * 通过身份证号查询信息
     * @param map
     * @return
     */
    MemberObj getMemberByPara(Map<String,Object> map);
}
