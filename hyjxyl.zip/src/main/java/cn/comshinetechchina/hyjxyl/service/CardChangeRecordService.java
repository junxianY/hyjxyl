package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.CardChangeRecord;

/**
 * 个人卡变更表接口
 */
public interface CardChangeRecordService {
      int insertSelective(CardChangeRecord record);
}
