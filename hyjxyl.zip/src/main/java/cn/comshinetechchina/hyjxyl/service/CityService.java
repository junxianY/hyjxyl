package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.City;

import java.util.List;

public interface CityService {
    /**
     * 查询城市列表
     * @param provinceId
     * @return
     */
    public List<City> selectCityList(String provinceId);
}
