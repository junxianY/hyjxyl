package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.dao.BloodOxygenDataDao;
import cn.comshinetechchina.hyjxyl.domain.BloodOxygenData;
import cn.comshinetechchina.hyjxyl.service.BloodOxygenDataService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service("bloodOxygenDataService")
public class BloodOxygenDataServiceImpl implements BloodOxygenDataService {
    private Logger log= LoggerFactory.getLogger(BloodOxygenDataServiceImpl.class);

    @Resource
    private BloodOxygenDataDao bloodOxygenDataDao;

    @Override
    public List<BloodOxygenData> selectBloodOxygenDataList(PageBean page, Map<String, Object> map) {
        return this.bloodOxygenDataDao.selectBloodOxygenDataList(page,map);
    }

    @Override
    public String packageChartData(List<BloodOxygenData> list) {
        JSONObject json=new JSONObject();
        //横坐标数据
        JSONObject xAxis=new JSONObject();
        xAxis.put("type","category");
        xAxis.put("boundaryGap",false);
        List<String> xList=new ArrayList<String>();
        List<String> yList=new ArrayList<String>();
        try {
            if (list != null && list.size() > 0) {
                for (BloodOxygenData data : list) {
                    if(data.getRt()!=null){
                        xList.add(DateUtil.transferDate2Str(data.getRt(), "yyyy-MM-dd"));
                        if(data.getOx()>=0){
                            yList.add(String.valueOf(data.getOx()));
                        }else{
                            yList.add("");
                        }

                    }
                }
            }
        }catch(ParseException ex){
            throw new ServiceException("强转出错",ex);
        }
        xAxis.put("data",xList);
        //纵坐标数据
        JSONObject series=new JSONObject();
        series.put("name","血氧值");
        series.put("type","line");
        series.put("data",yList);
        json.put("xAxis",xAxis);
        json.put("series",series);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    @Override
    public List<BloodOxygenData> selectMemberBloodOxygenDataList(String memberId) {
        return this.bloodOxygenDataDao.selectMemberBloodOxygenDataList(memberId);
    }


}
