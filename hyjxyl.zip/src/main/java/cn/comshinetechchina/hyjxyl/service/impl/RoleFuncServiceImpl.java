package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.RoleFuncDao;
import cn.comshinetechchina.hyjxyl.domain.RoleFuncKey;
import cn.comshinetechchina.hyjxyl.service.RoleFuncService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service("roleFuncService")
public class RoleFuncServiceImpl implements RoleFuncService {
    @Resource
    private RoleFuncDao roleFuncDao;
    @Override
    public int deleteRoleFunctions(Integer roleId) {
        return roleFuncDao.deleteRoleFunctions(roleId);
    }

    @Override
    public int batchInsertRoleFunc(List<RoleFuncKey> list) {
        return roleFuncDao.batchInsertRoleFunc(list);
    }

    @Override
    public List<RoleFuncKey> selectRoleFuncList(Integer roleId) {
        return roleFuncDao.selectRoleFuncList(roleId);
    }
}
