package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.CommentDao;
import cn.comshinetechchina.hyjxyl.dao.FavourRecordDao;
import cn.comshinetechchina.hyjxyl.domain.Comment;
import cn.comshinetechchina.hyjxyl.domain.FavourRecord;
import cn.comshinetechchina.hyjxyl.service.CommentService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service("commentService")
public class CommentServiceImpl implements CommentService {
    @Resource
    private CommentDao commentDao;
    @Resource
    private FavourRecordDao favourRecordDao;
    @Override
    public int deleteByPrimaryKey(String commentId) {
        return commentDao.deleteByPrimaryKey(commentId);
    }

    @Override
    public int insertSelective(Comment record) {
        return commentDao.insertSelective(record);
    }

    @Override
    public Comment selectByPrimaryKey(String commentId) {
        return commentDao.selectByPrimaryKey(commentId);
    }

    @Override
    public int updateByPrimaryKeySelective(Comment record) {
        return commentDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<Comment> selectCommentList(Map<String, Object> map) {
        return commentDao.selectCommentList(map);
    }

    @Override
    public int updateCommentFavour(String commentId,String userId,Integer operate) {
        //查询相应评论
        int i=0;
        Comment comment=this.commentDao.selectByPrimaryKey(commentId);
        if(comment==null){
            i=0;
        }else{
            if(null==comment.getFavour()){
                comment.setFavour(1);
            }else{
                if(operate==1){
                    comment.setFavour(comment.getFavour()+1);
                }
                if(operate==2){
                    comment.setFavour(comment.getFavour()-1);
                }
            }
            i=this.commentDao.updateByPrimaryKeySelective(comment);
            if(i>0){
                //插入一条点赞数
                FavourRecord record=new FavourRecord();
                record.setFavourId(UUID.randomUUID().toString());
                record.setRefId(commentId);
                record.setRefType("tbl_comments");
                record.setCreateBy(userId);
                record.setCreateDate(new Date());
                record.setType(operate);
                this.favourRecordDao.insertSelective(record);
            }
        }
        return i;
    }
}
