package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.RoleFuncKey;

import java.util.List;

/**
 * 角色功能服务类
 */
public interface RoleFuncService {
    /**
     * 删除某角色所有权限
     * @param roleId
     * @return
     */
    public int deleteRoleFunctions(Integer roleId);

    /**
     * 批量给角色授权
     * @param list
     * @return
     */
    public int batchInsertRoleFunc(List<RoleFuncKey> list);

    /**
     * 查询某角色功能权限
     * @param roleId
     * @return
     */
    public List<RoleFuncKey> selectRoleFuncList(Integer roleId);
}
