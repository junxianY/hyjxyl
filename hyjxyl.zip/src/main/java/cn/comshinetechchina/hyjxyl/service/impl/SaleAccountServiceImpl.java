package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.SaleAccountDao;
import cn.comshinetechchina.hyjxyl.domain.SaleAccount;
import cn.comshinetechchina.hyjxyl.service.SaleAccountService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
@Service("saleAccountService")
public class SaleAccountServiceImpl implements SaleAccountService {
    @Resource
    private SaleAccountDao saleAccountDao;
    @Override
    public int deleteByPrimaryKey(String code) {
        return saleAccountDao.deleteByPrimaryKey(code);
    }

    @Override
    public int insertSelective(SaleAccount record) {
        return saleAccountDao.insertSelective(record);
    }

    @Override
    public SaleAccount selectByPrimaryKey(String code) {
        return saleAccountDao.selectByPrimaryKey(code);
    }

    @Override
    public int updateByPrimaryKeySelective(SaleAccount record) {
        return saleAccountDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<SaleAccount> querySaleAccountList(Map<String, Object> map,PageBean page) {
        return saleAccountDao.querySaleAccountList(map,page);
    }
}
