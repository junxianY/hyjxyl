package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.PushMemberDao;
import cn.comshinetechchina.hyjxyl.dao.PushMessageDao;
import cn.comshinetechchina.hyjxyl.domain.PushMember;
import cn.comshinetechchina.hyjxyl.domain.PushMessage;
import cn.comshinetechchina.hyjxyl.domain.PushMessageObj;
import cn.comshinetechchina.hyjxyl.service.PushMessageService;
import cn.comshinetechchina.hyjxyl.util.PushMsg;
import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("pushMessageService")
public class PushMessageServiceImpl implements PushMessageService {
    @Resource
    private PushMessageDao pushMessageDao;
    @Resource
    private PushMemberDao pushMemberDao;
    @Override
    public int insertSelective(PushMessage record) {
        return pushMessageDao.insertSelective(record);
    }

    @Override
    public PushMessage selectByPrimaryKey(String id) {
        return pushMessageDao.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKeySelective(PushMessage record) {
        return pushMessageDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<PushMessageObj> selectPushMessageList(PageBean page, Map<String, Object> map) {
        return pushMessageDao.selectPushMessageList(page,map);
    }

    @Override
    public int batchUpdateMessageStatus(List<String> list) {
        return pushMessageDao.batchUpdateMessageStatus(list);
    }

    @Override
    public String pushMessageToOne(String memberId, String title, String msg) {
        //1 查询接收人是否开启消息推送
        JSONObject json=new JSONObject();
        Map<String,Object> map=new HashMap<>();
        map.put("memberId",memberId);
        map.put("available",1);
        List<PushMember> list= this.pushMemberDao.selectPushMembersList(map);
        PushMember pushMember=null;
        if(list!=null&&list.size()>0){
            pushMember=list.get(0);
        }
        //2.推送消息
        if(pushMember!=null){
           String res=PushMsg.push(title,msg,pushMember.getClientId(),pushMember.getPhoneType());
            json.put("success",true);
            json.put("message",res);
        }else{
            json.put("success",false);
            json.put("message","相应用户没有绑定个推");
        }
        return json.toJSONString();
    }
}
