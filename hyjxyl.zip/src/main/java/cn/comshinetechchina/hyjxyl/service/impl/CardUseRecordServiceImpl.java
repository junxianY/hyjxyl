package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.controller.CardController;
import cn.comshinetechchina.hyjxyl.dao.CardLeftNumberDao;
import cn.comshinetechchina.hyjxyl.dao.CardUseRecordDao;
import cn.comshinetechchina.hyjxyl.dao.DeviceDao;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.CardService;
import cn.comshinetechchina.hyjxyl.service.CardUseRecordService;
import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

@Service("cardUseRecordService")
public class CardUseRecordServiceImpl implements CardUseRecordService {
    @Resource
    private CardUseRecordDao cardUseRecordDao;
    @Resource
    private CardLeftNumberDao cardLeftNumberDao;
    @Resource
    private DeviceDao deviceDao;
    @Resource
    private CardService cardService;

    @Override
    public int insertSelective(CardUseRecord record) {
        return this.cardUseRecordDao.insertSelective(record);
    }
    @Override
    public CardUseRecord selectByPrimaryKey(String recordId) {
        return this.cardUseRecordDao.selectByPrimaryKey(recordId);
    }
    @Override
    public int updateByPrimaryKeySelective(CardUseRecord record) {
        return this.cardUseRecordDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<CardUseRecordObj> selectRecordList(PageBean page,Map<String, Object> map) {
        return this.cardUseRecordDao.selectRecordList(page,map);
    }

    @Override
    public String insertCardRecord(String cardNo, String deviceNo) {
        JSONObject json=new JSONObject();
        String serviceId=null;
        //1.判断设备是否存在
        List<Device> deviceList=this.deviceDao.selectDeviceList(deviceNo,null,null,1);
        if(null==deviceList||deviceList.size()==0){
            json.put("success",false);
            json.put("message","不存在该设备");
            return json.toJSONString();
        }else{
            serviceId=deviceList.get(0).getServiceId();
        }
        //2.判断卡是否被禁用
        Map<String,Object> map1=new HashMap<String,Object>();
        map1.put("cardNo",cardNo);
        List<CardObj> list1=cardService.selectCardList(map1);
        CardObj card=null;
        if(list1!=null&&list1.size()>0){
            card=list1.get(0);
            if(card!=null&&card.getAvailable()!=1){
                json.put("success",false);
                json.put("message","该卡为无效卡");
                return json.toJSONString();
            }
        }
        CardUseRecord record=new CardUseRecord();
        record.setRecordId(UUID.randomUUID().toString());
        record.setCardNo(cardNo);
        record.setSwipeDate(new Date());
        record.setCreateTime(new Date());
        record.setDeviceNo(deviceNo);
        //3.判断剩余次数是否充足，从剩余表拿取
        int leftCount=0;
        CardLeftNumber refRecord=null;
        //查询该卡该项服务剩余次数记录
        if(serviceId!=null) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("cardNo", cardNo);
            map.put("serviceId", serviceId);
            map.put("available", "1");
            List<CardLeftNumber> list = cardLeftNumberDao.selectCardLeftNumberList(map);
            if (list != null&&list.size()>0) {
                refRecord=list.get(0);
                leftCount=refRecord.getLeftNumber();
            }
        }
        if(leftCount<=0){
            json.put("success",false);
            json.put("message","剩余次数不足");
            return json.toJSONString();
        }else{
            record.setLeftNumber(leftCount-1);
        }
        //4.插入刷卡记录表
        int i=this.cardUseRecordDao.insertSelective(record);
        if(i>0){
           //4.更新相应卡服务剩余次数
            refRecord.setLeftNumber(refRecord.getLeftNumber()-1);
            int t=this.cardLeftNumberDao.updateByPrimaryKeySelective(refRecord);
            if(t>0){
                json.put("success",true);
                json.put("message","成功");
            }else{
                json.put("success",true);
                json.put("message","操作失败");
            }
        }else{
            json.put("success",true);
            json.put("message","操作失败");
        }
        return json.toJSONString();
    }

    @Override
    public List<CardUseRecordCountObj> countCardUseRecord(String memberId,String startDate, String endDate) {
        return this.cardUseRecordDao.countCardUseRecord(memberId,startDate,endDate);
    }
}
