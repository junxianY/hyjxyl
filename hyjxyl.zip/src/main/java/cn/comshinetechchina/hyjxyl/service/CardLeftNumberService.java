package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.CardLeftNumber;
import cn.comshinetechchina.hyjxyl.domain.CardLeftNumberKey;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 卡剩余次数服务接口
 */
public interface CardLeftNumberService {
    /**
     * 批量插入记录
     * @param list
     * @return
     */
    public int batchInsertRecord(List<CardLeftNumber> list);

    /**
     * 根据条件查询卡剩余次数
     * @param map
     * @return
     */
    public List<CardLeftNumber> selectCardLeftNumberList(Map<String,Object> map);

    /**
     * 更新卡编号方法
     * @param oldCardNo 旧卡编号
     * @param newCardNo 新卡编号
     * @return
     */
    public int changeCardNo(String oldCardNo,String newCardNo);
    int updateByPrimaryKeySelective(CardLeftNumber record);
    CardLeftNumber selectByPrimaryKey(CardLeftNumberKey key);

    /**
     * 修改卡服务剩余次数
     * @param cardNo 卡编号
     * @param serviceId 服务id
     * @param newLeftNum 新次数
     * @param userId 登陆用户id
     * @param remark 备注
     * @return
     */
    public int modifyCardLeftNumber(String cardNo,String serviceId,Integer newLeftNum,String userId,String remark);

    /**
     * 批量更新卡剩余次数记录状态
     * @param cardNo
     * @return
     */
    public int updateLeftNumberAvailable(String cardNo);

    /**
     * 删除接口
     * @param cardNo
     * @return
     */
    public int deleteInfoByPara(String cardNo);

    /**
     * 删除某时间之前的过期记录
     * @param endDate
     * @return
     */
    public int delRecordByTask(Date endDate);
}
