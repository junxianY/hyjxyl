package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.PushMemberDao;
import cn.comshinetechchina.hyjxyl.domain.PushMember;
import cn.comshinetechchina.hyjxyl.service.PushMemberService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("pushMemberService")
public class PushMemberServiceImpl implements PushMemberService {
    @Resource
    private PushMemberDao pushMemberDao;
    @Override
    public int insertSelective(PushMember record) {
        return pushMemberDao.insertSelective(record);
    }

    @Override
    public PushMember selectByPrimaryKey(String id) {
        return pushMemberDao.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKeySelective(PushMember record) {
        return pushMemberDao.updateByPrimaryKey(record);
    }

    @Override
    public List<PushMember> selectPushMembersList(Map<String, Object> map) {
        return pushMemberDao.selectPushMembersList(map);
    }

    @Override
    public int updatePushMember(PushMember record) {
        return pushMemberDao.updatePushMember(record);
    }

    @Override
    public int delPushMemberByClientId(String clientId) {
        return this.pushMemberDao.delPushMemberByClientId(clientId);
    }
}
