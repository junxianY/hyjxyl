package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.SmsRecordDao;
import cn.comshinetechchina.hyjxyl.domain.SmsRecord;
import cn.comshinetechchina.hyjxyl.service.SmsRecordService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service("smsRecordService")
public class SmsRecordServiceImpl implements SmsRecordService {
    @Resource
    private SmsRecordDao smsRecordDao;
    @Override
    public int insertSelective(SmsRecord record) {
        return smsRecordDao.insertSelective(record);
    }

    @Override
    public SmsRecord selectByPrimaryKey(String id) {
        return smsRecordDao.selectByPrimaryKey(id);
    }
}
