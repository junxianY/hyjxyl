package cn.comshinetechchina.hyjxyl.service;

import java.util.Date;

/**
 * 卡剩余次数历史表
 */
public interface CardLeftNumberHistoryService {
    /**
     * 转移卡剩余次数记录接口
     * @param cardNo 必填
     * @param serviceId
     * @return
     */
    public int moveCardLeftNumber(String cardNo,String serviceId);

    /**
     * 跑批插入过期记录
     * @return
     */
    public int batchInsertRecordByTask(Date endDate);
}
