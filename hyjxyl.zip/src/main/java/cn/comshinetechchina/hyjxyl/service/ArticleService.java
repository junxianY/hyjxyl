package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.Article;
import cn.comshinetechchina.hyjxyl.domain.ArticleObj;

import java.util.List;
import java.util.Map;

/**
 * 活动资讯服务接口
 */
public interface ArticleService {
    int insertSelective(Article record);
    Article selectByPrimaryKey(String articleId);
    int updateByPrimaryKeySelective(Article record);
    int deleteByPrimaryKey(String articleId);
    List<ArticleObj> selectArticleList(Map<String,Object> map, PageBean bean);

    /**
     * 点赞取消赞
     * @param articleId
     * @param userId
     * @param operate 1增加赞 2 取消赞
     * @return
     */
     int updateArticleFavor(String articleId,String userId,Integer operate);

    /**
     * 批量更新活动资讯浏览量接口
     * @param list
     * @return
     */
    int updateArticleArticleScol(List<String> list);

    /**
     * banner 获取随机五条活动资讯
     * @return
     */
     List<ArticleObj> selectRandom5Articles();

    /**
     * 查询某类型的编号是否存在
     * @param article
     * @return
     */
    Map  selectOneByOrderNo(Article article);
    int updateByPrimaryKeyWithBLOBs(Article record);
}
