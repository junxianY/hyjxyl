package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.controller.LoginController;
import cn.comshinetechchina.hyjxyl.dao.PointDao;
import cn.comshinetechchina.hyjxyl.dao.PointsDetailDao;
import cn.comshinetechchina.hyjxyl.domain.Point;
import cn.comshinetechchina.hyjxyl.domain.PointsDetail;
import cn.comshinetechchina.hyjxyl.service.PointService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.UUID;

@Service("pointService")
public class PointServiceImpl implements PointService {
    private static final Logger log= LoggerFactory.getLogger(PointServiceImpl.class);
    @Resource
    private PointDao pointDao;
    @Resource
    private PointsDetailDao pointsDetailDao;

    @Override
    public int deleteByPrimaryKey(String memberId) {
        return pointDao.deleteByPrimaryKey(memberId);
    }

    @Override
    public int insertSelective(Point record) {
        return pointDao.insertSelective(record);
    }

    @Override
    public Point selectByPrimaryKey(String memberId) {
        return pointDao.selectByPrimaryKey(memberId);
    }

    @Override
    public int updateByPrimaryKeySelective(Point record) {
        return pointDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public int savePointInfo(String memberId, int type, int age,String articleId) {
        //判断相应对象是否存在 不存在插入，存在更新
        Point p=pointDao.selectByPrimaryKey(memberId);
        int i=0;
        Point record=new Point();
        record.setMemberId(memberId);
        int point=0;
        String remark="";
        switch(type){
            case 1:
                if(age>=55){
                    point=10;
                }else{
                    point=5;
                }
                remark="完善个人资料加"+point+"分";
                break;
            case 2:
                point=15;
                remark="完善健康信息加15分";
                break;
            case 3:
                point=5;
                remark="添加病例档案、体检报告加5分";
                break;
            case 4:
                point=1;
                remark="阅读活动资讯加1分";
                break;
        }
        PointsDetail detail=new PointsDetail();
        detail.setMemberId(memberId);
        detail.setPointsDetailId(UUID.randomUUID().toString());
        detail.setType(type);
        detail.setCreateTime(new Date());
        detail.setRemark(remark);
        if(type==4){
            detail.setArticleId(articleId);
        }
        if(p!=null){
            //主表进行更新操作
            record.setPoint(p.getPoint()+point);
            record.setLastUpdateTime(new Date());
            record.setCreateTime(p.getCreateTime());
            i=this.pointDao.updateByPrimaryKey(record);
            detail.setPrePoint(p.getPoint());
            detail.setAfterPoint(p.getPoint()+point);
        }else{
            //主表进行插入操作
            record.setPoint(point);
            record.setCreateTime(new Date());
            i=pointDao.insertSelective(record);
            detail.setPrePoint(0);
            detail.setAfterPoint(point);
        }
        if(i>0){
            //插入明细表
            int j=this.pointsDetailDao.insertSelective(detail);
            if(j>0){
                System.out.println("插入积分明细表记录成功!");
                log.info("插入积分明细表记录成功!");
            }else{
                log.info("插入积分明细表记录失败!");
            }
        }
        return i;
    }
}
