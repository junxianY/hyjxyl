package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.User;

import java.util.List;
import java.util.Map;

public interface UserService {
    int deleteByPrimaryKey(String userId);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(String userId);

    int updateByPrimaryKeySelective(User record);

    /**
     * 查询用户信息
     * @param userName
     * @param password
     * @return
     */
    public User selectUserByPara(String userName,String password);

    /**
     * 根据条件查询用户列表
     * @param map
     * @return
     */
    public List<User> selectUserList(Map<String,Object> map);
}
