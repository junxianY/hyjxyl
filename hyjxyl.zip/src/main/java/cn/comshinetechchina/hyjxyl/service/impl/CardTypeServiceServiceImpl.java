package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.CardTypeServiceDao;
import cn.comshinetechchina.hyjxyl.domain.CardTypeService;
import cn.comshinetechchina.hyjxyl.service.CardTypeServiceService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("cardTypeServiceService")
public class CardTypeServiceServiceImpl implements CardTypeServiceService {
    @Resource
    private CardTypeServiceDao cardTypeServiceDao;

    @Override
    public int deleteByPrimaryKey(String cardTypeServiceId) {
        return this.cardTypeServiceDao.deleteByPrimaryKey(cardTypeServiceId);
    }

    @Override
    public int insertSelective(CardTypeService record) {
        return this.cardTypeServiceDao.insertSelective(record);
    }

    @Override
    public CardTypeService selectByPrimaryKey(String cardTypeServiceId) {
        return this.cardTypeServiceDao.selectByPrimaryKey(cardTypeServiceId);
    }

    @Override
    public int updateByPrimaryKeySelective(CardTypeService record) {
        return this.cardTypeServiceDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<CardTypeService> selectCardTypeServiceList(Map<String, String> map) {
        return this.cardTypeServiceDao.selectCardTypeServiceList(map);
    }

    @Override
    public int batchInsertSelective(List<CardTypeService> list) {
        return this.cardTypeServiceDao.batchInsertSelective(list);
    }

    @Override
    public int deleteRecordByPara(String cardTypeId) {
        return this.cardTypeServiceDao.deleteRecordByPara(cardTypeId);
    }
}
