package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.PushMessage;
import cn.comshinetechchina.hyjxyl.domain.PushMessageObj;

import java.util.List;
import java.util.Map;

/**
 * 推送消息管理接口
 */
public interface PushMessageService {
    int insertSelective(PushMessage record);

    PushMessage selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(PushMessage record);
    public List<PushMessageObj> selectPushMessageList(PageBean page, Map<String,Object> map);

    /**
     * 批量更新状态接口
     * @param list
     * @return
     */
    public int batchUpdateMessageStatus(List<String> list);

    /**
     * 给某人推送专属消息
     * @param memberId 接口人id
     * @param title 消息标题
     * @param msg  消息内容
     * @return
     */
    public String pushMessageToOne(String memberId,String title,String msg);
}
