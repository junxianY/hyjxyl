package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.CardChangeRecordDao;
import cn.comshinetechchina.hyjxyl.domain.CardChangeRecord;
import cn.comshinetechchina.hyjxyl.service.CardChangeRecordService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
@Service("cardChangeRecordService")
public class CardChangeRecordServiceImpl implements CardChangeRecordService {
    @Resource
    private CardChangeRecordDao cardChangeRecordDao;

    @Override
    public int insertSelective(CardChangeRecord record) {
        return cardChangeRecordDao.insertSelective(record);
    }
}
