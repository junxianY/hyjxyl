package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.KithAndKin;

import java.util.List;
import java.util.Map;

/**
 * 亲友关系服务类
 */
public interface KithAndKinService {
    int insertSelective(KithAndKin record);
    KithAndKin selectByPrimaryKey(String kinId);
    int updateByPrimaryKeySelective(KithAndKin record);
    /**
     * 查询某用户有效亲属列表
     * @param memberId
     * @return
     */
    public List<KithAndKin> selectUserKithList(String memberId);

    /**
     *
     * 通过条件查询亲友信息
     * @param memberId
     * @param nickMemberId
     * @param nickName
     * @param available
     * @return
     */
    public List<KithAndKin> selectKithListByPara(String memberId,String nickMemberId,String nickName,String available);

    /**
     * 通过条件查询某用户特别关心的有效亲属列表
     * @param memberId
     * @param concern 1是0否
     * @return
     */
    public List<KithAndKin> selectUserKithList(String memberId,int concern);
}
