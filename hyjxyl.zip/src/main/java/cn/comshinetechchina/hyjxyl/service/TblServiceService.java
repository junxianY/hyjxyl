package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.TblService;

import java.util.List;
import java.util.Map;

/**
 * 服务类
 */
public interface TblServiceService {
    int insertSelective(TblService record);
    TblService selectByPrimaryKey(String serviceId);
    int updateByPrimaryKeySelective(TblService record);
    int deleteByPrimaryKey(String serviceId);
    /**
     * 查询服务列表
     * @param map
     * @return
     */
    public List<TblService> queryServiceList(Map<String,String> map);
}
