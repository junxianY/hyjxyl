package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.CardLeftNumberHistoryDao;
import cn.comshinetechchina.hyjxyl.service.CardLeftNumberHistoryService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

@Service("cardLeftNumberHistoryService")
public class CardLeftNumberHistoryServiceImpl implements CardLeftNumberHistoryService {
    @Resource
    private CardLeftNumberHistoryDao cardLeftNumberHistoryDao;
    @Override
    public int moveCardLeftNumber(String cardNo, String serviceId) {
        return cardLeftNumberHistoryDao.moveCardLeftNumber(cardNo,serviceId);
    }

    @Override
    public int batchInsertRecordByTask(Date endDate) {
        return cardLeftNumberHistoryDao.batchInsertRecordByTask(endDate);
    }
}
