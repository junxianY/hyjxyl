package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.FavourRecordDao;
import cn.comshinetechchina.hyjxyl.domain.FavourRecord;
import cn.comshinetechchina.hyjxyl.service.FavourRecordService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service("favourRecordService")
public class FavourRecordServiceImpl implements FavourRecordService {
    @Resource
    private FavourRecordDao favourRecordDao;
    @Override
    public FavourRecord selectOneFavourRecord(String refId, String refType, String memberId) {
        return favourRecordDao.selectOneFavourRecord(refId,refType,memberId);
    }
}
