package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.BloodOxygenData;
import cn.comshinetechchina.hyjxyl.domain.FatData;

import java.util.List;
import java.util.Map;

/**
 * 脂肪信息接口
 */
public interface FatDataService {
    /**
     * 查询数据列表
     * @param page
     * @param map
     * @return
     */
    public List<FatData> selectFatDataList(PageBean page, Map<String, Object> map);

    /**
     * 组装数据接口
     * @param list
     * @return
     */
    public String packageChartData(List<FatData> list);

    /**
     * 查询脂肪信息
     * @param memberId
     * @return
     */
    List<FatData> selectFatDataList(String memberId);
}
