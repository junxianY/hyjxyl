package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.Constant;
import cn.comshinetechchina.hyjxyl.service.SmsService;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service("smsService")
public class SmsServiceImpl implements SmsService {
    private Logger log= LoggerFactory.getLogger(SmsServiceImpl.class);

    @Override
    public Map<String,Object> sendMessage(String phoneNum, String signName, String templeteCode, String paras) {
        Map<String,Object> map=new HashMap<String,Object>();
        log.info("sendMessage"+phoneNum);
        //初始化acsClient,暂不支持region化
        IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", Constant.accessKeyId, Constant.accessKeySecret);
        try {
            DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", Constant.product, Constant.domain);
        } catch (ClientException e) {
            e.printStackTrace();
        }
        IAcsClient acsClient = new DefaultAcsClient(profile);
        //组装请求对象-具体描述见控制台-文档部分内容
        SendSmsRequest request = new SendSmsRequest();
        //必填:待发送手机号
        request.setPhoneNumbers(phoneNum);
        //必填:短信签名-可在短信控制台中找到
        request.setSignName(signName);
        //必填:短信模板-可在短信控制台中找到
        request.setTemplateCode(templeteCode);
        //可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${code}"时,此处的值为
        //request.setTemplateParam("{\"name\":\"Tom\", \"code\":\"123\"}");
        request.setTemplateParam(paras);

        //选填-上行短信扩展码(无特殊需求用户请忽略此字段)
        //request.setSmsUpExtendCode("90997");

        //可选:outId为提供给业务方扩展字段,最终在短信回执消息中将此值带回给调用者
        request.setOutId("yourOutId");

        //hint 此处可能会抛出异常，注意catch
        try {
            SendSmsResponse sendSmsResponse = acsClient.getAcsResponse(request);
            //处理返回值
            String resCode=sendSmsResponse.getCode();
            log.info(resCode+"--1111--"+sendSmsResponse.getMessage());
            if("OK".equals(resCode)){
                map.put("success","true");
            }else{
                map.put("success","false");
                map.put("message",sendSmsResponse.getMessage());
            }
        } catch (ClientException e) {
            map.put("success","false");
            map.put("message",e.getMessage());
         //   e.printStackTrace();
        }

        return map;
    }

   /* public static void main(String[] args){
        String phoneNum="18201386455";
        String templeteCode="SMS_135755160";
        String signName="花样金夕项目";
        String paras="{\"code\":\"1223\"}";
        SmsService service=new SmsServiceImpl();
        String resJson=service.sendMessage(phoneNum,signName,templeteCode,paras);
        System.out.println(resJson);
    }*/
}
