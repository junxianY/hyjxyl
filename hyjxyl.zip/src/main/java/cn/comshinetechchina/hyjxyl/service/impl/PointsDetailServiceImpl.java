package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.PointsDetailDao;
import cn.comshinetechchina.hyjxyl.domain.PointsDetail;
import cn.comshinetechchina.hyjxyl.service.PointsDetailService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("pointsDetailService")
public class PointsDetailServiceImpl implements PointsDetailService {
    @Resource
    private PointsDetailDao pointsDetailDao;

    @Override
    public List<PointsDetail> selectPointsDetailList(Map<String, Object> map) {
        return pointsDetailDao.selectPointsDetailList(map);
    }

    @Override
    public int insertSelective(PointsDetail record) {
        return pointsDetailDao.insertSelective(record);
    }

    @Override
    public PointsDetail selectByPrimaryKey(String pointsDetailId) {
        return pointsDetailDao.selectByPrimaryKey(pointsDetailId);
    }

    @Override
    public int updateByPrimaryKeySelective(PointsDetail record) {
        return pointsDetailDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<PointsDetail> selectPointsDetailListByPage(Map<String, Object> map, PageBean bean) {
        return pointsDetailDao.selectPointsDetailListByPage(map,bean);
    }
}
