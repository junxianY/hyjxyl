package cn.comshinetechchina.hyjxyl.service.impl;

import cn.comshinetechchina.hyjxyl.dao.CardTypeDao;
import cn.comshinetechchina.hyjxyl.domain.CardType;
import cn.comshinetechchina.hyjxyl.service.CardTypeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service("cardTypeService")
public class CardTypeServiceImpl implements CardTypeService {
    @Resource
    private CardTypeDao cardTypeDao;
    @Override
    public int insertSelective(CardType record) {
        return cardTypeDao.insertSelective(record);
    }

    @Override
    public CardType selectByPrimaryKey(String cardTypeId) {
        return cardTypeDao.selectByPrimaryKey(cardTypeId);
    }

    @Override
    public int updateByPrimaryKeySelective(CardType record) {
        return cardTypeDao.updateByPrimaryKeySelective(record);
    }

    @Override
    public List<CardType> selectAllCardTypes(Map<String,Object> map) {
        return this.cardTypeDao.selectAllCardTypes(map);
    }

    @Override
    public int deleteByPrimaryKey(String cardTypeId) {
        return cardTypeDao.deleteByPrimaryKey(cardTypeId);
    }
}
