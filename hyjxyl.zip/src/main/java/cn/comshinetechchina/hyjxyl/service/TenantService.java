package cn.comshinetechchina.hyjxyl.service;

import cn.comshinetechchina.hyjxyl.domain.Tenant;

import java.util.List;
import java.util.Map;

/**
 * 租户服务类
 */
public interface TenantService {
    int insertSelective(Tenant record);
    Tenant selectByPrimaryKey(String tenantId);
    int updateByPrimaryKeySelective(Tenant record);
    int deleteByPrimaryKey(String tenantId);

    /**
     * 通过条件查询租户列表
     * @param map
     * @return
     */
    public List<Tenant> selectTenantList(Map<String,Object> map);
}
