package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.Location;
import cn.comshinetechchina.hyjxyl.service.LocationService;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import cn.comshinetechchina.hyjxyl.util.ToolUtil;
import cn.comshinetechchina.hyjxyl.util.UserAgentUtils;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

@RestController
@EnableAutoConfiguration
@RequestMapping("/locationController")
public class LocationController extends BaseController {
    private static final Logger log= LoggerFactory.getLogger(LocationController.class);
    @Resource
    private LocationService locationService;

    /**
     * 增加位置地图信息
     * @param info
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/addLocationInfo",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String  addLocationInfo(Location info,HttpServletRequest request) {
        JSONObject json = new JSONObject();
        if(null==info){
         json.put("success",false);
         json.put("message","参数不能为空");
         return json.toJSONString();
        }
        String uId= UUID.randomUUID().toString();
        info.setAvailable(1);
        info.setLocationId(uId);
        info.setIp(ToolUtil.getIpAddr(request));
        info.setCreatedDate(new Date());
        String longitude=request.getParameter("longitude");
        String latitude=request.getParameter("latitude");
        log.info("增加经纬度信息:"+longitude+"---"+latitude);
        if(StringUtils.isNotBlank(longitude)){
            info.setLongitude(Double.valueOf(longitude));
        }
        if(StringUtils.isNotBlank(latitude)){
            info.setLatitude(Double.valueOf(latitude));
        }
        //设备类型
        String ua= UserAgentUtils.getUaInfo(request);
        String deviceType=UserAgentUtils.getMobileOS(ua);
        log.info("当前用户ua:"+ua+"设备类型："+deviceType+"经度:"+info.getLatitude()+"纬度:"+info.getLongitude());
        info.setDeviceType(deviceType);
        String token = request.getHeader("token");
        //若对象没memberId 从token中取
        String memberId = "";
        try {
            Map<String, Object> map = JwtUtil.parseManagementToken(token);
            memberId = map.get("uid") == null ? "" : map.get("uid").toString();
            log.info("当前登录人memberId:" + memberId);
        } catch (Exception ex) {
            throw new ServiceException("token解析失败", ex);
        }
        if(StringUtils.isBlank(info.getMemberId())){
            info.setMemberId(memberId);
        }
        int i=this.locationService.insertSelective(info);
        if(i>0){
            json.put("success",true);
            json.put("message","插入成功");
            json.put("locationId",uId);
        }else{
            json.put("success",false);
            json.put("message","插入失败");
            json.put("locationId","");
        }
        return json.toJSONString();
    }

    @ResponseBody
    @RequestMapping(value="/queryLocationList",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String  queryLocationList(String memberId,HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if(StringUtils.isBlank(memberId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("memberId",memberId);
        map.put("available",1);
        //开始日期
        String startDate=request.getParameter("startDate");
        //结束日期
        String endDate=request.getParameter("endDate");
        map.put("startDate",startDate);
        map.put("endDate",endDate);
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        List<Location> list=new ArrayList<Location>();
        int totalCount=0;
        try {
            list = this.locationService.selectLocationList(bean, map);
            totalCount=bean.getTotalRows();
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("totalCount", totalCount);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        dataJson.put("list",list);
        json.put("data",dataJson);
        json.put("success",true);
        json.put("message","查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
