package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.domain.Members;
import cn.comshinetechchina.hyjxyl.service.MembersService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;

@Controller
public class Hello {

    @Resource
    MembersService membersService;
    @ResponseBody
    @RequestMapping(value="/hello")
    public Members hello(){
        Members members = membersService.selectOneMembers("11",null);
        return members;
    }

    @RequestMapping(value="/toTestUpload")
    public String  toTestUpload(){
        ModelAndView mav=new ModelAndView("test");

        return "/aaa";
    }
    @RequestMapping(value="/toAddKithKin")
    public String  toAddKithKin(){
        ModelAndView mav=new ModelAndView("test");

        return "/addKith";
    }
    @RequestMapping(value="/toAddIllness")
    public String  toAddIllness(){
        ModelAndView mav=new ModelAndView("test");

        return "/addIllness";
    }

    /**
     * 批量添加图片方法
     * @return
     */
    @RequestMapping(value="/toAddIllness1")
    public String  toAddIllness1(){
        ModelAndView mav=new ModelAndView("test");

        return "/addIllness1";
    }
    /**
     * 批量添加图片方法
     * @return
     */
    @RequestMapping(value="/testConnect")
    public String  toTestConnect(){
        ModelAndView mav=new ModelAndView("test");
        return "/test";
    }

    /**
     * 获取亲友列表
     * @return
     */
    @RequestMapping(value="/testQueryKids")
    public String  testQueryKids(){
        return "/testQueryKids";
    }

    /**
     * 新增卡类型并绑定服务测试
     * @return
     */
    @RequestMapping(value="/testCardTypeBindService")
    public String  testCardTypeBindService(){
        return "/testCardTypeBindService";
    }

    /**
     * 测试重置密码
     * @return
     */
    @RequestMapping(value="/testResetPwd")
    public String  testResetPwd(){
        return "/aaabb";
    }

    @RequestMapping(value="/testAA")
    public String  testAA(){
        return "/test2";
    }
}
