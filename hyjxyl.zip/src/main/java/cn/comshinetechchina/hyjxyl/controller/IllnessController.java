package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.*;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 病例档案控制层
 * Author:yjx
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/illnessController")
public class IllnessController extends BaseController {
    private static final Logger log= LoggerFactory.getLogger(IllnessController.class);
    @Resource
    private IllnessService illnessService;
    @Resource
    private ContentRefService contentRefService;
    @Resource
    private ContentService contentService;
    @Resource
    private PointsDetailService pointsDetailService;
    @Resource
    private PointService pointService;

    /**
     * 手机端获取病例列表信息
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/getIllnessList",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String getIllnessList(HttpServletRequest request){
        JSONObject json=new JSONObject();
        JSONObject dataJson=new JSONObject();
        String memberId=request.getParameter("memberId");
        log.info("---intoMethod:getIllnessList,memberId:"+memberId);

       //当前页码
       String pageIndex=request.getParameter("pageIndex")==null?"0":request.getParameter("pageIndex");
       //每页数量
       String pageSize=request.getParameter("pageSize")==null?"10":request.getParameter("pageSize");
       //类型
       String type=request.getParameter("type");
        //检查开始日期
        String startDate=request.getParameter("startDate");
        //结束日期
        String endDate=request.getParameter("endDate");
        //病因
        String testReason=request.getParameter("testReason");
        //姓名
        String memberName=request.getParameter("memberName");
        //手机号
        String phone=request.getParameter("phone");
        //是否有效
        String available=request.getParameter("available");
        PageBean bean=new PageBean();
        if(StringUtils.isNotBlank(pageSize)){
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("type",type);
        map.put("testReason",testReason);
        map.put("startDate",startDate);
        map.put("endDate",endDate);
        //map.put("available",1); //查询有效的
        map.put("available",available);
        map.put("memberId",memberId);
        map.put("memberName",memberName);
        map.put("phone",phone);
        List<IllnessObj> illList= new ArrayList<IllnessObj>();
        List<Content> contentList=new ArrayList<Content>();
        int totalCount=0;
        try {
            illList = illnessService.getIllnessList(map, bean);
            totalCount=bean.getTotalRows();
            if(illList!=null&&illList.size()>0){
                for(IllnessObj obj:illList){
                    if (obj != null) {
                        //循环查询其详细图片信息
                        contentList = contentService.selectContentsById(obj.getIllnessId(), "tbl_illness", "1002");
                        obj.setContentList(contentList);
                    }
                }
            }

        }catch(Exception ex){
            throw new ServiceException("数据操作异常",ex);
        }
        dataJson.put("illList",illList);
        dataJson.put("pageSize",pageSize);
        dataJson.put("pageIndex",pageIndex);
        dataJson.put("totalCount",totalCount);
        json.put("data",dataJson);
        json.put("success",true);
        json.put("message","成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 增加病例方法
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/addIllnessInfo",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addIllnessInfo(IllnessObj info){
        log.info("--进入方法addIllnessInfo1--");
        JSONObject json=new JSONObject();
        if(null==info||StringUtils.isBlank(info.getMemberId())){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        Illness illness=new Illness();
        BeanUtils.copyProperties(info,illness);
        //插入病例信息
        String illId=UUID.randomUUID().toString();
        illness.setIllnessId(illId);
        illness.setCreatedDate(new Date());
        illness.setAvailable(1);
        try{
            //体检日期
            if(info.getTestDate()!=null){
                illness.setTestDate(DateUtils.parseDate(info.getTestDate(),"yyyy-MM-dd"));
            }else{
                illness.setTestDate(new Date());
            }
            int i=this.illnessService.insertSelective(illness);
            if(i>0) {
                log.info("插入病例信息成功，id:" + illId);
                String[] contentIds=info.getContentIds();
                //批量插入附件业务关联表
                if (contentIds!= null&&contentIds.length>0) {
                    List<ContentRef> list=new ArrayList<ContentRef>();
                    for(int j=0;j<contentIds.length;j++){
                        ContentRef ref = new ContentRef();
                        String refId = UUID.randomUUID().toString();
                        ref.setContentRefId(refId);//关联表主键
                        ref.setContentRefType("tbl_illness"); //关联业务表名
                        ref.setContentId(contentIds[j]);//附件id
                        ref.setContentRefCode("illness_id");//关联业务表列名
                        ref.setExternalId(illId); //关联id
                        ref.setCreateTime(new Date());
                        list.add(ref);
                    }
                    int t = contentRefService.batchInsertContentRef(list);
                    if (t > 0) {
                        log.info("插入附件业务关联成功，插入数量:" + list.size());
                    }
                }
                json.put("success", true);
                json.put("message", "操作成功");

                //操作成功 计入积分 每天最多三次 add 20180829
                Map<String,Object> map=new HashMap<String,Object>();
                map.put("memberId",info.getMemberId());
                map.put("type",3);
                map.put("createDate", DateUtil.transferDate2Str(new Date(),"yyyy-MM-dd"));
                List<PointsDetail> list=this.pointsDetailService.selectPointsDetailList(map);
                if(list!=null&&list.size()<3){
                  this.pointService.savePointInfo(info.getMemberId(),3,0,null);
                }
            }else{
                json.put("success",false);
                json.put("message","数据插入出错");
                return json.toJSONString();
            }
        }catch(Exception ex){
            throw new ServiceException("数据插入出错",ex);
        }
        return json.toJSONString();
    }
    /**
     * 查询单条详情方法
     * @param illnessId 病例体检id
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/queryOneInfoDetail",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryOneInfoDetail(String illnessId){
        log.info("--进入方法queryOneInfoDetail--"+illnessId);
        JSONObject json=new JSONObject();
        JSONObject dataJson=new JSONObject();
        if(StringUtils.isBlank(illnessId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        IllnessObj infoObj=new IllnessObj();
        List<Content> contentList=null;
        try {
            //查询出病例信息
            infoObj = this.illnessService.selectOneIllness(illnessId);
            if (infoObj != null) {
                //查询其详细图片信息
                contentList = contentService.selectContentsById(illnessId, "tbl_illness", "1002");
            }
        }catch (Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("info",infoObj);
        dataJson.put("contentList",contentList);
        json.put("data",dataJson);
        json.put("success", true);
        json.put("message", "操作成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * 修改病例方法
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/updateIllnessInfo",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String updateIllnessInfo(IllnessObj info){
        log.info("--进入方法updateIllnessInfo--");
        JSONObject json=new JSONObject();
        if(null==info||StringUtils.isBlank(info.getIllnessId())){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        Illness illness=new Illness();
        BeanUtils.copyProperties(info,illness);
        //插入病例信息
        illness.setUpdatedDate(new Date());
        illness.setAvailable(1);
        try{
            //体检日期
            if(info.getTestDate()!=null){
                illness.setTestDate(DateUtils.parseDate(info.getTestDate(),"yyyy-MM-dd"));
            }
            int i=this.illnessService.updateByPrimaryKeySelective(illness);
            if(i>0) {
                log.info("更新病例信息成功，id:" + illness.getIllnessId());
                String[] contentIds=info.getContentIds();
                //先将旧的关联全部移除再插入新的
                int count=contentRefService.delContentRefById(info.getIllnessId());
                if(count>=0){
                    //批量插入附件业务关联表
                    if (contentIds!= null&&contentIds.length>0) {
                        List<ContentRef> list=new ArrayList<ContentRef>();
                        for(int j=0;j<contentIds.length;j++){
                            ContentRef ref = new ContentRef();
                            String refId = UUID.randomUUID().toString();
                            ref.setContentRefId(refId);//关联表主键
                            ref.setContentRefType("tbl_illness"); //关联业务表名
                            ref.setContentId(contentIds[j]);//附件id
                            ref.setContentRefCode("illness_id");//关联业务表列名
                            ref.setExternalId(info.getIllnessId()); //关联id
                            ref.setCreateTime(new Date());
                            list.add(ref);
                        }
                        int t = contentRefService.batchInsertContentRef(list);
                        if (t > 0) {
                            log.info("更新附件业务关联成功，插入数量:" + list.size());
                        }
                    }
                }
                json.put("success", true);
                json.put("message", "操作成功");
            }else{
                json.put("success",false);
                json.put("message","数据插入出错");
                return json.toJSONString();
            }
        }catch(Exception ex){
            throw new ServiceException("数据插入出错",ex);
        }
        return json.toJSONString();
    }

    /**
     * 删除病例接口
     * @param illnessId
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/delIllnessInfo",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String delIllnessInfo(String illnessId){
        log.info("--进入方法delIllnessInfo--"+illnessId);
        JSONObject json=new JSONObject();
        if(StringUtils.isBlank(illnessId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }

        int i=this.illnessService.deleteByPrimaryKey(illnessId);
        if(i>0){
            json.put("success",true);
            json.put("message","删除成功");
        }else{
            json.put("success",false);
            json.put("message","操作失败");
        }
        return json.toJSONString();
    }
}
