package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.Province;
import cn.comshinetechchina.hyjxyl.service.ProvinceService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/provinceController")
public class ProvinceController extends BaseController {
    @Resource
    private ProvinceService provinceService;
    @ResponseBody
    @RequestMapping(value = "/queryProvinceList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryProvinceList() {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        List<Province> list = new ArrayList<Province>();
        try {
            list =this.provinceService.selectProvinceList();
        } catch (Exception ex) {
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list", list);
        json.put("success", true);
        json.put("message", "查询成功");
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
