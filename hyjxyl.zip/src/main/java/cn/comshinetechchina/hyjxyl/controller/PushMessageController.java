package cn.comshinetechchina.hyjxyl.controller;
import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.PushMessage;
import cn.comshinetechchina.hyjxyl.domain.PushMessageObj;
import cn.comshinetechchina.hyjxyl.service.PushMessageService;
import cn.comshinetechchina.hyjxyl.util.AppPush;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * 推送控制层
 */
@RestController
@RequestMapping("/pushMessageController")
public class PushMessageController extends BaseController {
    private Logger log= LoggerFactory.getLogger(PushMessageController.class);
    @Resource
    private PushMessageService pushMessageService;
    /**
     * 实时推送接口
     * @param title
     * @param message
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/pushMessage", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String pushMessage(String title,String message) {
        JSONObject json = new JSONObject();
        log.info("title:"+title+"---message:"+message);
//        String title="提醒";
//        String text="读书，写字，旅游，约会，做自己感到惬意的事";
//        String pushTime="2018-06-07 11:26:00";
        String ss= AppPush.pushMessage(title,message,null);
        if(StringUtils.isNotBlank(ss)&&ss.indexOf("result=ok")!=-1){
            json.put("success", true);
            json.put("message", "推送成功");
        }else{
            json.put("success", false);
            json.put("message", "推送失败,原因："+ss.substring((ss.indexOf(",")+1),(ss.length()-1)));
        }
        log.info("推送消息返回:"+ss);
        return json.toJSONString();
    }
    /**
     * 后台增加推送消息接口
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addPushMessageInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addPushMessageInfo(PushMessage info,HttpServletRequest request) {
        log.info("进入addPushMessageInfo方法");
        JSONObject json = new JSONObject();
        if (null == info||StringUtils.isBlank(info.getMessage())||StringUtils.isBlank(info.getTitle())||null==info.getSendDate()) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        String uId= UUID.randomUUID().toString();
        info.setId(uId);
        info.setAvailable(1);
        //状态 0新建 1已发送
        info.setStatus(0);
        info.setCreateTime(new Date());
        String token = request.getHeader("token");
        try {
            Map<String, Object> map = JwtUtil.parseManagementToken(token);
            String userId = map.get("uid") == null ? "" : map.get("uid").toString();
            log.info("当前后台登录人id:" + userId);
            info.setCreateBy(userId);
            int i = this.pushMessageService.insertSelective(info);
            if (i > 0) {
                json.put("messageId", uId);
                json.put("success", true);
                json.put("message", "增加成功");
            } else {
                json.put("messageId", "");
                json.put("success", false);
                json.put("message", "增加失败");
            }
        }catch(Exception ex){
            throw new ServiceException("增加出现异常",ex);
        }
        return json.toJSONString();
    }

    /**
     * 后台查询推送列表方法
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryPushMessageList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryPushMessageList(HttpServletRequest request) {
        log.info("进入queryPushMessageList方法");
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        //当前页码
        String pageIndex=request.getParameter("pageIndex")==null?"0":request.getParameter("pageIndex");
        //每页数量
        String pageSize=request.getParameter("pageSize")==null?"10":request.getParameter("pageSize");
        //状态
        String status=request.getParameter("status");
        //计划发送开始日期
        String startDate=request.getParameter("startDate");
        //计划发送结束日期
        String endDate=request.getParameter("endDate");
        PageBean bean=new PageBean();
        if(StringUtils.isNotBlank(pageSize)){
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("status",status);
        map.put("startDate",startDate);
        map.put("endDate",endDate);
        map.put("available",1); //查询有效的
        List<PushMessageObj> list=new ArrayList<PushMessageObj>();
        int totalCount=0;
        try{
            list=this.pushMessageService.selectPushMessageList(bean,map);
            totalCount=bean.getTotalRows();
        }catch(Exception ex){
           throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list",list);
        dataJson.put("pageSize",pageSize);
        dataJson.put("pageIndex",pageIndex);
        dataJson.put("totalCount",totalCount);
        json.put("data",dataJson);
        json.put("success",true);
        json.put("message","成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 假删除方法
     * @param ids
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/delPushMessageInfo",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String delPushMessageInfo(String ids){
        log.info("--进入方法delPushMessageInfo--"+ids);
        JSONObject json = new JSONObject();
        if (StringUtils.isBlank(ids)) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        int i=0;
        if(ids.indexOf(",")!=-1){
            //代表多个
            String[] ids1=ids.split(",");
            PushMessage info=null;
            for(String id:ids1){
                info =new PushMessage();
                info.setId(id);
                info.setAvailable(0);
                int t=this.pushMessageService.updateByPrimaryKeySelective(info);
                i+=t;
            }
        }else{
            //就一个
            PushMessage info=new PushMessage();
            info.setId(ids);
            info.setAvailable(0);
            i=this.pushMessageService.updateByPrimaryKeySelective(info);
        }
        if(i>0){
            json.put("success",true);
            json.put("message","操作成功");
        }else{
            json.put("success",false);
            json.put("message","操作失败");
        }
        return json.toJSONString();
    }

    /**
     * 修改方法
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updatePushMessageInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String updatePushMessageInfo(PushMessage info) {
        log.info("进入updatePushMessageInfo方法");
        JSONObject json = new JSONObject();
        if (null == info||StringUtils.isBlank(info.getId())||StringUtils.isBlank(info.getMessage())||StringUtils.isBlank(info.getTitle())||null==info.getSendDate()) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        info.setUpdateTime(new Date());
        try {
            int i = this.pushMessageService.updateByPrimaryKeySelective(info);
            if (i > 0) {
                json.put("success", true);
                json.put("message", "修改成功");
            } else {
                json.put("success", false);
                json.put("message", "修改失败");
            }
        }catch(Exception ex){
            throw new ServiceException("修改出现异常",ex);
        }
        return json.toJSONString();
    }
}