package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.ArticleObj;
import cn.comshinetechchina.hyjxyl.domain.CarouselFigure;
import cn.comshinetechchina.hyjxyl.domain.CarouselFigureObj;
import cn.comshinetechchina.hyjxyl.domain.Content;
import cn.comshinetechchina.hyjxyl.service.CarouselFigureService;
import cn.comshinetechchina.hyjxyl.service.ContentService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * 轮播图控制器
 */
@RestController
@RequestMapping("/carouselFigureController")
public class CarouselFigureController extends BaseController {
    private Logger log= LoggerFactory.getLogger(CarouselFigureController.class);
    @Resource
    private CarouselFigureService carouselFigureService;
    @Resource
    private ContentService contentService;

    /**
     * 增加轮播图接口
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/addCarouselFigureInfo",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addCarouselFigureInfo(CarouselFigure info) {
        log.info("--进入方法addCarouselFigureInfo--");
        JSONObject json = new JSONObject();
        if (null == info || StringUtils.isBlank(info.getArticleId())) {
            json.put("success", false);
            json.put("message", "活动id不能为空");
            return json.toJSONString();
        }
        //判断表中相应序号是否存在
        if(info.getOrderNo()!=null){
            CarouselFigure oldData=this.carouselFigureService.selectOneCarouselFigureByOrder(info.getOrderNo());
            if(oldData!=null){
                json.put("success", false);
                json.put("message", "序号已经存在");
                return json.toJSONString();
            }
        }
        info.setAvailable(1);
        String uId="";
        //通过articleId判断是否是已删除的重新增加,是的话 更新状态图片，否则插入
        CarouselFigure oldInfo=this.carouselFigureService.selectOneCarouselFigure(info.getArticleId(),0);
        int i=0;
        if(oldInfo!=null){
            uId=oldInfo.getId();
            info.setId(oldInfo.getId());
            info.setLastUpdateTime(new Date());
            i=this.carouselFigureService.updateByPrimaryKeySelective(info);
        }else{
            uId= UUID.randomUUID().toString();
            info.setId(uId);
            info.setCreateTime(new Date());
            i=this.carouselFigureService.insertSelective(info);
        }
        if(i>0){
             json.put("success",true);
             json.put("message","增加成功");
             json.put("id",uId);
        }else{
            json.put("success",false);
            json.put("message","增加失败");
            json.put("id","");
        }
        return json.toJSONString();
    }
    @ResponseBody
    @RequestMapping(value="/updateCarouselFigureInfo",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String updateCarouselFigureInfo(CarouselFigure info) {
        log.info("--进入方法addCarouselFigureInfo--");
        JSONObject json = new JSONObject();
        if (null == info ||StringUtils.isBlank(info.getId())) {
            json.put("success", false);
            json.put("message", "參數不能为空");
            return json.toJSONString();
        }
        if(info.getOrderNo()!=null&&info.getOrderNo()!=-1){
            CarouselFigure oldData=this.carouselFigureService.selectOneCarouselFigureByOrder(info.getOrderNo());
            if(oldData!=null&&!oldData.getId().equals(info.getId())){
                json.put("success", false);
                json.put("message", "序号已经存在");
                return json.toJSONString();
            }
        }
        info.setLastUpdateTime(new Date());
        int i=this.carouselFigureService.updateByPrimaryKeySelective(info);
        if(i>0){
            json.put("success",true);
            json.put("message","修改成功");
        }else{
            json.put("success",false);
            json.put("message","修改失败");
        }
        return json.toJSONString();
    }
    /**
     * 假删除数据 状态置为无效
     * @param ids
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/delCarouselFigureInfo",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String delCarouselFigureInfo(String ids) {
        log.info("--进入方法delCarouselFigureInfo--"+ids);
        JSONObject json = new JSONObject();
        if (StringUtils.isBlank(ids)) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        int i=0;
        if(ids.indexOf(",")!=-1){
            //代表多个
            String[] ids1=ids.split(",");
            CarouselFigure info=null;
            for(String id:ids1){
                info =new CarouselFigure();
                info.setId(id);
                info.setAvailable(0);
                int t=this.carouselFigureService.updateByPrimaryKeySelective(info);
                i+=t;
            }
        }else{
            //就一个
            CarouselFigure info=new CarouselFigure();
            info.setId(ids);
            info.setAvailable(0);
            i=this.carouselFigureService.updateByPrimaryKeySelective(info);
        }
        if(i>0){
            json.put("success",true);
            json.put("message","操作成功");
        }else{
            json.put("success",false);
            json.put("message","操作失败");
        }
        return json.toJSONString();
    }

    /**
     *  查询轮播图列表信息
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/queryCarouselFigureList",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryCarouselFigureList(HttpServletRequest request){
        JSONObject json=new JSONObject();
        JSONObject dataJson=new JSONObject();
        log.info("---intoMethod:queryCarouselFigureList");
        //当前页码
        String pageIndex=request.getParameter("pageIndex")==null?"0":request.getParameter("pageIndex");
        //每页数量
        String pageSize=request.getParameter("pageSize")==null?"10":request.getParameter("pageSize");

        //检查开始日期
        String startDate=request.getParameter("startDate");
        //结束日期
        String endDate=request.getParameter("endDate");

        PageBean bean=new PageBean();
        if(StringUtils.isNotBlank(pageSize)){
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("startDate",startDate);
        map.put("endDate",endDate);
        map.put("available",1); //查询有效的
        List<CarouselFigureObj> list= new ArrayList<CarouselFigureObj>();
        int totalCount=0;
        try {
            list =this.carouselFigureService.selectCarouselFigureList(bean,map);
            totalCount = bean.getTotalRows();
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list",list);
        dataJson.put("pageSize",pageSize);
        dataJson.put("pageIndex",pageIndex);
        dataJson.put("totalCount",totalCount);
        json.put("data",dataJson);
        json.put("success",true);
        json.put("message","成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 查询banner图片文章
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryBannerCarouselFigures", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryBannerCarouselFigures() {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        List<CarouselFigureObj> list = new ArrayList<CarouselFigureObj>();
        try {
            list = this.carouselFigureService.selectRandom5Articles();
        } catch (Exception ex) {
            throw new ServiceException("查询异常", ex);
        }
        dataJson.put("list", list);
        json.put("data", dataJson);
        json.put("success", true);
        json.put("message", "查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 查询未添加到轮播图中的活动资讯
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryAvailableArticles", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryAvailableArticles(HttpServletRequest request){
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("startDate",request.getParameter("startDate"));
        map.put("endDate",request.getParameter("endDate"));
        List<ArticleObj> list=new ArrayList<ArticleObj>();
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        int totalCount=0;
        //标题检索
        map.put("title",request.getParameter("title"));
        try{
            list=this.carouselFigureService.queryAvailableArticles(bean,map);
            totalCount=bean.getTotalRows();
            if (list != null && list.size() > 0) {
            String contentType = "";
            List<Content> contentList = null;
            for (ArticleObj obj : list) {
                if ("01".equals(obj.getTypeId())) {
                    contentType = "1004";
                } else if ("02".equals(obj.getTypeId())) {
                    contentType = "1003";
                } else if ("03".equals(obj.getTypeId())) {
                    contentType = "1005";
                } else if ("04".equals(obj.getTypeId())) {
                    contentType = "1006";
                }
                contentList = contentService.selectContentsById(obj.getArticleId(), "tbl_articles", contentType);
                if (contentList != null && contentList.size() > 0) {
                    obj.setContentId(contentList.get(0).getContentId());
                }
            }
          }
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("totalCount", totalCount);
        dataJson.put("list", list);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        json.put("data",dataJson);
        json.put("success", true);
        json.put("message", "查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
