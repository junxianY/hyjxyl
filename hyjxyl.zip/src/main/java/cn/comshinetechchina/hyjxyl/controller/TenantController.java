package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.Tenant;
import cn.comshinetechchina.hyjxyl.service.TenantService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 租户控制层
 * Author:yjx
 */
@RestController
@RequestMapping("/tenantController")
public class TenantController  extends BaseController{
    private Logger log= LoggerFactory.getLogger(TenantController.class);
    @Resource
    private TenantService tenantService;

    @ResponseBody
    @RequestMapping(value = "/queryTenantList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryTenantList(HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        String name = request.getParameter("name");
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("name", name);
        map.put("available", 1);
        List<Tenant> list = new ArrayList<Tenant>();
        try {
            list = this.tenantService.selectTenantList(map);
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list", list);
        json.put("data", dataJson);
        json.put("success", true);
        json.put("message", "查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
