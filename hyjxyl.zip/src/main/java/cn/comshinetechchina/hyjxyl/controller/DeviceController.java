package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.Device;
import cn.comshinetechchina.hyjxyl.service.DeviceService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * 设备控制层
 */
@RestController
@RequestMapping("/deviceController")
public class DeviceController extends BaseController {
    private Logger log= LoggerFactory.getLogger(DeviceController.class);
    @Resource
    private DeviceService deviceService;
    /**
     * 增加设备方法
     * @param device
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addDevice", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String  addDevice(Device device){
        JSONObject json = new JSONObject();
        if(null==device||StringUtils.isBlank(device.getDeviceNo())){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        //验证设备编号是否存在
        List<Device> list=this.deviceService.selectDeviceList(device.getDeviceNo(),null,null,1);
        if(list!=null&&list.size()>0){
            json.put("success",false);
            json.put("message","设备编号已经存在");
            return json.toJSONString();
        }
        try {
            String uId= UUID.randomUUID().toString();
            device.setDeviceId(uId);
            device.setCreatedDate(new Date());
            if(null==device.getAvailable()){
                device.setAvailable(1);
            }
            int i=this.deviceService.insertSelective(device);
            if(i>0){
                json.put("uId",uId);
                json.put("success", true);
                json.put("message", "操作成功");
            }else{
                json.put("uId","");
                json.put("success", false);
                json.put("message", "操作失败");
            }
        }catch(Exception ex){
            throw new ServiceException("增加异常",ex);
        }
        return json.toJSONString();
    }

    /**
     * 删除设备方法(假删除、状态置为无效)
     * @param deviceId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/delDevice", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String  delDevice(String deviceId){
        JSONObject json = new JSONObject();
        if(StringUtils.isBlank(deviceId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        try {
            Device record=new Device();
            record.setDeviceId(deviceId);
            record.setAvailable(0);
            record.setUpdatedDate(new Date());
            int i=this.deviceService.updateByPrimaryKeySelective(record);
            if(i>0){
                log.info("设备："+deviceId+"状态置为无效成功");
                json.put("success", true);
                json.put("message", "操作成功");
            }else{
                json.put("success", false);
                json.put("message", "操作失败");
            }
        }catch(Exception ex){
            throw new ServiceException("删除异常",ex);
        }
        return json.toJSONString();
    }

    /**
     * 分页查询设备列表
     * @param request
     * @param session
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryDeviceList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String  queryDeviceList(HttpServletRequest request, HttpSession session){
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        //设备编号
        String deviceNo = request.getParameter("deviceNo");
        //租户id
        String tenantId = request.getParameter("tenantId");
        //服务id
        String serviceId = request.getParameter("serviceId");
        //是否有效 1有效 0无效
        String available = request.getParameter("available")==null?"1":request.getParameter("available");
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("deviceNo", deviceNo);
        map.put("tenantId", tenantId);
        map.put("serviceId", serviceId);
        map.put("available", available);
        List<Device> list = new ArrayList<Device>();
        int totalCount = 0;
        try {
            //需要分页
            PageBean bean = new PageBean();
             if (StringUtils.isNotBlank(pageSize)) {
                bean.setPageSize(Integer.parseInt(pageSize));
            }
            if (StringUtils.isNotBlank(pageIndex)) {
                bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
            }
            list = this.deviceService.selectPageDeviceList(map, bean);
            totalCount = bean.getTotalRows();
        } catch (Exception ex) {
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("pageSize", pageSize);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("totalCount", totalCount);
        dataJson.put("list", list);
        json.put("data", dataJson);
        json.put("success", true);
        json.put("message", "查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * 修改设备方法
     * @param device
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateDevice", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String  updateDevice(Device device){
        JSONObject json = new JSONObject();
        if(null==device||StringUtils.isBlank(device.getDeviceNo())||StringUtils.isBlank(device.getDeviceId())){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        //若编号改变 验证设备编号是否存在
        Device device1=this.deviceService.selectByPrimaryKey(device.getDeviceId());
        if(device1!=null&&!device1.getDeviceNo().equals(device.getDeviceNo())){
            List<Device> list=this.deviceService.selectDeviceList(device.getDeviceNo(),null,null,1);
            if(list!=null&&list.size()>0){
                json.put("success",false);
                json.put("message","设备编号已经存在");
                return json.toJSONString();
            }
        }
        try {
            device.setUpdatedDate(new Date());
            int i=this.deviceService.updateByPrimaryKeySelective(device);
            if(i>0){
                json.put("success", true);
                json.put("message", "操作成功");
            }else{
                json.put("success", false);
                json.put("message", "操作失败");
            }
        }catch(Exception ex){
            throw new ServiceException("修改异常",ex);
        }
        return json.toJSONString();
    }
}
