package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.filter.TokenState;
import cn.comshinetechchina.hyjxyl.service.*;
import cn.comshinetechchina.hyjxyl.util.*;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.rowset.serial.SerialException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.*;

/**
 * 老人用户信息控制层
 * Author:yjx
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/membersController")
public class MembersController extends BaseController {
    private static final Logger log = LoggerFactory.getLogger(MembersController.class);
    @Resource
    private MembersService membersService;
    @Resource
    private MemberExtendService memberExtendService;
    @Resource
    private SelfCenterConfigService selfCenterConfigService;
    @Resource
    private ContentService contentService;
    @Resource
    private KithAndKinService kithAndKinService;
    @Resource
    private MemberHealthService memberHealthService;
    @Resource
    private PointService pointService;
    @Resource
    private ContentTypeService contentTypeService;
    @Resource
    private ContentRefService contentRefService;
    @Resource
    private PointsDetailService pointsDetailService;
    @Resource
    private TestRecordService testRecordService;

    /**
     * 获取个人资料方法
     *
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/getMemberInfo", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public String getMemberInfo(String memberId, HttpServletRequest request) {
        JSONObject json = new JSONObject();
        if (StringUtils.isBlank(memberId)) {
            json.put("success", false);
            json.put("message", "参数不能为空");
        }
        String token = request.getHeader("token");
        log.info("进入getMemberInfo方法：memberId:" + memberId + "--token:" + token);
        MemberExtendObj obj = new MemberExtendObj();
        MemberExtend info = this.memberExtendService.selectByPrimaryKey(memberId);
        Members m = this.membersService.selectByPrimaryKey(memberId);
        if (info != null) {
            BeanUtils.copyProperties(info, obj);
            try {
                if (info.getBirthday() != null) {
                    obj.setBirthday(DateUtil.transferDate2Str(info.getBirthday(), "yyyy-MM-dd"));
                }
                if (info.getCreatedDate() != null) {
                    obj.setCreatedDate(DateUtil.transferDate2Str(info.getCreatedDate(), "yyyy-MM-dd"));
                }
                if (info.getLastUpdateTime() != null) {
                    obj.setLastUpdateTime(DateUtil.transferDate2Str(info.getLastUpdateTime(), "yyyy-MM-dd HH:mm:ss"));
                }
                if (m != null) {
                    obj.setPhone(m.getPhone());
                    obj.setToken(m.getToken());
                }
            } catch (ParseException e) {
                // e.printStackTrace();
                log.info("转换日期出错");
                throw new ServiceException("后台出现异常");
            }
        }
        //查询个人头像
        String contentId = "";
        List<Content> contentList = this.contentService.selectContentsById(memberId, "tbl_members", "1001");
        if (contentList != null && contentList.size() > 0) {
            contentId = contentList.get(0).getContentId();
        }
        //查询个人积分
        String pointNum = "";
        Point point = pointService.selectByPrimaryKey(memberId);
        if (point != null) {
            pointNum = point.getPoint().toString();
        }
        JSONObject data = new JSONObject();
        data.put("info", obj);
        data.put("contentId", contentId);
        data.put("pointNum", pointNum);
        json.put("data", data);
        json.put("success", true);
        json.put("message", "查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 通过参数查询个人信息
     * @param request
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryMemberInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryMemberInfo(MemberExtend info, HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        String contentId = "";
        String name = "";
        //将查询的人客户id
        String memberId = "";
        boolean isFriend = false;
        boolean isSelf=false;//是否是自身
        String kinId="";//亲友id
        if (info == null) {
            json.put("success", false);
            json.put("message", "参数为空");
            return json.toJSONString();
        } else {
            String token = request.getHeader("token");
            String currentMemberId = "";
            try {
                Map<String, Object> map = JwtUtil.parseManagementToken(token);
                currentMemberId = map.get("uid") == null ? "" : map.get("uid").toString();
                log.info("当前登录人memberId:" + currentMemberId);

            } catch (Exception ex) {
                throw new ServiceException("token解析失败", ex);
            }
            //判断是否为查询自身手机号
            if(StringUtils.isNotBlank(currentMemberId)){
                Members member=this.membersService.selectByPrimaryKey(currentMemberId);
                if(member!=null&&info.getPhone()!=null&&info.getPhone().equals(member.getPhone())){
                    isSelf=true;
                }
            }
            try {
                List<MemberExtend> resultList = this.memberExtendService.selectMemberExtendList(info);
                if (resultList != null && resultList.size() > 0) {
                    MemberExtend resultObj = resultList.get(0);
                    if (resultObj != null) {
                        name = resultObj.getName();
                        memberId = resultObj.getMemberId();
                        //查询用户头像
                        List<Content> list = contentService.selectContentsById(resultObj.getMemberId(), "tbl_members", "1001");
                        if (list != null && list.size() > 0) {
                            contentId = list.get(0).getContentId();
                        }
                    }
                     //判断查询的用户是否已经是本人亲友
                     List<KithAndKin> list = kithAndKinService.selectKithListByPara(currentMemberId, memberId, null, "1");
                      if (list != null && list.size() > 0) {
                          isFriend = true;
                          kinId=list.get(0).getKinId();
                      }
                }
            } catch (Exception ex) {
                throw new ServiceException("查询出错", ex);
            }
        }
        dataJson.put("memberId", memberId);
        if(StringUtils.isBlank(name)){
            name=info.getPhone();
        }
        dataJson.put("name", name);
        dataJson.put("isSelf", isSelf);
        dataJson.put("contentId", contentId);
        dataJson.put("isFriend", isFriend);
        dataJson.put("kinId", kinId);
        json.put("data", dataJson);
        json.put("success", true);
        json.put("message", "查询成功");
        return json.toJSONString();
    }

    /**
     * 增加、修改个人资料方法
     *
     * @param info
     * @param type    1增加 2更新
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateMemberInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 36000, rollbackFor = Exception.class)
    public String updateMemberInfo(MemberExtend info, int type, HttpServletRequest request) {
        JSONObject json = new JSONObject();
        if ((type != 1 && type != 2) || info == null || (null == info.getMemberId())) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        String token = request.getHeader("token");
        log.info("updateMemberInfo方法" + "--token:" + token + "---" + type);
        //根据出生年月计算年龄
        try {
            if (info.getBirthday() != null) {
                info.setAge(IdcardUtil.getAgeByBirthday1(info.getBirthday()));
            }
            //根据身份证id计算年龄
            if (StringUtils.isNotBlank(info.getIdNo())) {
                info.setAge(IdcardUtil.getAgeByIdNo(info.getIdNo()));
            }
            info.setLastUpdateTime(new Date());
            int i=0;
            if (type == 1) {
                //若能查询到，执行更新，查询不到执行插入操作
                MemberExtend data = memberExtendService.selectByPrimaryKey(info.getMemberId());
                if (data != null) {
                    json.put("success", false);
                    json.put("message", "操作失败，请进行更新操作");
                } else {
                    i= this.memberExtendService.insertSelective(info);
                    if (i > 0) {
                        log.info("成功插入" + i + "行数据");
                        json.put("success", true);
                        json.put("message", "插入数据成功");
                    }
                }
            }
            if (type == 2) {
                i = this.memberExtendService.updateByPrimaryKeySelective(info);
                if (i > 0) {
                    log.info("成功更新" + i + "行数据");
                    json.put("success", true);
                    json.put("message", "更新数据成功");
                } else {
                    json.put("success", false);
                    json.put("message", "更新数据失败");
                }
            }
            //增加积分判定规则 add 20180829
            if(i>0&&info.getAge()!=null&&info.getAge()>0) {
                //若各个属性都不为空,增加积分 只记录一次
                //个人资料中的"身份证号"以下的信息改成了只有年龄>=55岁的人才可以填写，所以年龄小于55岁的用户下面的信息没有填写也不影响完整性 update 20180910
                boolean insertPoints = false;
                if (info.getAge() >= 55) {
                    ExtendsMemberInfo eInfo = new ExtendsMemberInfo();
                    BeanUtils.copyProperties(info, eInfo);
                    if (ToolUtil.checkObjFieldIsNotNull(eInfo)) {
                        insertPoints = true;
                    }
                } else {
                    ExtendsMemberInfo1 eInfo = new  ExtendsMemberInfo1();
                    BeanUtils.copyProperties(info, eInfo);
                    if (ToolUtil.checkObjFieldIsNotNull(eInfo)) {
                        insertPoints = true;
                    }
                }
                if (insertPoints) {
                    Map<String, Object> map = new HashMap<String, Object>();
                    map.put("memberId", info.getMemberId());
                    map.put("type", 1);
                    List<PointsDetail> list = this.pointsDetailService.selectPointsDetailList(map);
                    if (list == null || list.size() == 0) {
                        //代表首次补全资料
                       int t= this.pointService.savePointInfo(info.getMemberId(), 1, info.getAge(), null);
                       if(t>0){
                           log.info("首次插入积分成功");
                       }
                    }
                }
            }
        } catch (Exception ex) {
            throw new ServiceException("更新异常", ex);
        }
        return json.toJSONString();
    }

    /**
     * 查询个人配置方法
     *
     * @param memberId
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/getSelfCenterConfigInfo", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public String getSelfCenterConfigInfo(String memberId, HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject data = new JSONObject();
        if (StringUtils.isBlank(memberId)) {
            json.put("success", false);
            json.put("message", "参数不能为空");
        }
        String token = request.getHeader("token");
        log.info("getSelfCenterConfigInfo方法" + "--token:" + token);
        SelfCenterConfig info = null;
        try {
            info = this.selfCenterConfigService.selectByPrimaryKey(memberId);
        } catch (Exception ex) {
            throw new ServiceException("查询错误", ex);
        }
        data.put("info", info);
        json.put("data", data);
        json.put("success", true);
        json.put("message", "查询数据成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 更新个人隐私、推送配置信息
     *
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateSelfCenterConfigInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 36000, rollbackFor = Exception.class)
    public String updateSelfCenterConfigInfo(SelfCenterConfig info) {
        JSONObject json = new JSONObject();
        if (null == info || null == info.getMemberId()) {
            json.put("success", false);
            json.put("message", "参数错误");
            return json.toJSONString();
        }
        log.info("updateSelfCenterConfigInfo" + info.getMemberId());
        SelfCenterConfig config = selfCenterConfigService.selectByPrimaryKey(info.getMemberId());
        int i = 0;
        if (config == null) {
            i = this.selfCenterConfigService.insertSelective(info);
        } else {
            i = this.selfCenterConfigService.updateByPrimaryKeySelective(info);
        }
        if (i > 0) {
            json.put("success", true);
            json.put("message", "操作成功");
        } else {
            json.put("success", false);
            json.put("message", "操作失败");
        }

        return json.toJSONString();
    }

    /**
     * 根据条件查询用户列表信息方法
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryMembersList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryMembersList(HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        //卡编号或者手机号或者姓名
        String cardNo = request.getParameter("cardNo");
        //性别
        String sex = request.getParameter("sex");
        //民族id
        String nationId = request.getParameter("nationId");
        //省份
        String provinceId = request.getParameter("provinceId");
        //城市id
        String cityId = request.getParameter("cityId");
        //区域id
        String areaId = request.getParameter("areaId");
        //社区id
        String communityId = request.getParameter("communityId");
        //租户id
        String tenantId = request.getParameter("tenantId");
        //年龄起始
        String ageStr = request.getParameter("ageStr");
        //年龄最大
        String ageEnd = request.getParameter("ageEnd");
        //注册起始日
        String registerStr = request.getParameter("registerStr");
        //注册结束日
        String registerEnd = request.getParameter("registerEnd");
        //小区名
        String areaName = request.getParameter("areaName");
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        //状态
        String state = request.getParameter("state");
        Map<String, String> map = new HashMap<String, String>();
        map.put("cardNo", cardNo);
        map.put("sex", sex);
        map.put("nationId", nationId);
        map.put("provinceId", provinceId);
        map.put("cityId", cityId);
        map.put("areaId", areaId);
        map.put("communityId", communityId);
        map.put("tenantId", tenantId);
        map.put("ageStr", ageStr);
        map.put("ageEnd", ageEnd);

        map.put("registerStr", registerStr);
        map.put("registerEnd", registerEnd);
        map.put("state", state);
        map.put("areaName", areaName);
        List<MemberInfo> list = new ArrayList<MemberInfo>();
        int totalCount = 0;
        //需要分页
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        try {
            list = this.membersService.selectMemberInfoList(map, bean);
            totalCount = bean.getTotalRows();
        } catch (Exception ex) {
            throw new ServiceException("查询异常", ex);
        }
        dataJson.put("totalCount", totalCount);
        dataJson.put("list", list);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        json.put("success", true);
        json.put("message", "成功");
        json.put("data", dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 后台查询个人明细信息
     *
     * @param memberId
     * @param session
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryMemberInfoDetail", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryMemberInfoDetail(String memberId, HttpSession session) {
        JSONObject json = new JSONObject();
        if (StringUtils.isBlank(memberId)) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        JSONObject dataJson = new JSONObject();
        //查询个人基本信息
        MemberInfoObj info = new MemberInfoObj();
        //查询个人亲友信息
        List<KithAndKin> list = new ArrayList<KithAndKin>();
        //查询个人健康信息
        MemberHealth healthInfo = new MemberHealth();
        try {
            info = this.membersService.selectMemberInfoObjDetail(memberId);
            if(info!=null){
                //查询用户头像
                List<Content> list1 = contentService.selectContentsById(memberId, "tbl_members", "1001");
                if (list1 != null && list1.size() > 0) {
                   String contentId = list1.get(0).getContentId();
                   info.setContentId(contentId);
                }
            }
            list = kithAndKinService.selectUserKithList(memberId);
            healthInfo = memberHealthService.selectMemberHealthInfo(memberId);
            if(healthInfo!=null&&healthInfo.getAllergicHistory()!=null){
                healthInfo.setAllergicHistory(healthInfo.getAllergicHistory().replaceAll("null",""));
            }
            if(healthInfo!=null&&healthInfo.getDiseasesHistory()!=null){
                healthInfo.setDiseasesHistory(healthInfo.getDiseasesHistory().replaceAll("null",""));
            }
        } catch (Exception ex) {
            throw new ServiceException("查询异常", ex);
        }
        dataJson.put("memberInfo", info);
        dataJson.put("kithList", list);
        dataJson.put("healthInfo", healthInfo);
        json.put("success", true);
        json.put("message", "查询成功");
        json.put("data", dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 修改客户头像接口
     *
     * @param file
     * @param memberId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/changeMemberPhoto", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 36000, rollbackFor = Exception.class)
    public String changeMemberPhoto(@RequestParam("file") MultipartFile file,String memberId) {
        JSONObject json = new JSONObject();
        System.out.println(memberId+"---"+file);
        if (null == file || StringUtils.isBlank(memberId)) {
            json.put("success", false);
            json.put("message", "文件上传参数异常");
            return json.toJSONString();
        }
        try {
            String fileName = file.getOriginalFilename();
            String fileType = fileName.substring(fileName.lastIndexOf(".") + 1);
            log.info("-----changeMemberPhoto---"+fileName);
            fileType = fileType.toLowerCase();
            boolean b = checkFileType(fileType);
            if (!b) {
                json.put("success", false);
                json.put("message", "文件格式异常");
                return json.toJSONString();
            }
            String contentName = "";
            String contentTypeId = "";
            //通过code查询相应配置
            ContentType contentType = this.contentTypeService.selectOneContentType("member_photo", 1);
            if (contentType != null) {
                contentName = contentType.getContentTypeName();
                contentTypeId = contentType.getContentTypeId().toString();
            } else {
                json.put("success", false);
                json.put("message", "附件类型不存在");
                return json.toJSONString();
            }
            String uploadJson = contentService.saveFileUpload(file, contentName, contentTypeId);
            JSONObject uploadJsonObj = JSONObject.parseObject(uploadJson);
            Boolean sucFlag = uploadJsonObj.getBoolean("success");
            if (!sucFlag) {
                json.put("success", false);
                json.put("message", "文件上传异常");
                return json.toJSONString();
            }
            //如果上传成功，则将content_Id返回客户端
            String contentId = uploadJsonObj.getString("contentId");
            JSONObject dataJson = new JSONObject();

            //绑定客户头像附件
            ContentRef ref = new ContentRef();
            ref.setContentRefId(UUID.randomUUID().toString());
            ref.setContentId(contentId);
            ref.setContentRefCode("member_id");
            ref.setContentRefType("tbl_members");
            ref.setExternalId(memberId);
            ref.setCreateTime(new Date());
            ref.setComments("换头像");
            int t = this.contentRefService.insertSelective(ref);
            if (t <= 0) {
                json.put("success", false);
                json.put("message", "文件上传异常");
                return json.toJSONString();
            }
            dataJson.put("contentId", contentId);
            dataJson.put("fileName", fileName);
            json.put("success", true);
            json.put("data", dataJson);

            json.put("message", "文件上传成功");
        } catch (Exception e) {
            json.put("success", false);
            json.put("message", "文件上传异常");
            log.error(e.getMessage());
        }
        return json.toJSONString();
    }

    /**
     * 64位更换头像方法
     * @param baseFile
     * @param typeCode
     * @param memberId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/changeMemberPhotoBase64", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 36000, rollbackFor = Exception.class)
    public String changeMemberPhotoBase64(String baseFile,String typeCode, String memberId) {
        log.info("-----changeMemberPhotoBase64---"+typeCode+"----"+baseFile);
        JSONObject json = new JSONObject();
        if (StringUtils.isBlank(baseFile)||StringUtils.isBlank(typeCode)|| StringUtils.isBlank(memberId)) {
            json.put("success", false);
            json.put("message", "文件上传参数异常");
            return json.toJSONString();
        }
        MultipartFile file= BASE64DecodedMultipartFile.base64ToMultipart(baseFile);
        try {
            String fileName = file.getOriginalFilename();
            String fileType = fileName.substring(fileName.lastIndexOf(".") + 1);
            fileType = fileType.toLowerCase();
            boolean b = checkFileType(fileType);
            if (!b) {
                json.put("success", false);
                json.put("message", "文件格式异常");
                return json.toJSONString();
            }
            String contentName = "";
            String contentTypeId = "";
            //通过code查询相应配置
            ContentType contentType = this.contentTypeService.selectOneContentType(typeCode, 1);
            if (contentType != null) {
                contentName = contentType.getContentTypeName();
                contentTypeId = contentType.getContentTypeId().toString();
            } else {
                json.put("success", false);
                json.put("message", "文件上传参数异常");
                return json.toJSONString();
            }
            String uploadJson = contentService.saveFileUpload(file, contentName, contentTypeId);
            JSONObject uploadJsonObj = JSONObject.parseObject(uploadJson);
            Boolean sucFlag = uploadJsonObj.getBoolean("success");
            if (!sucFlag) {
                json.put("success", false);
                json.put("message", "文件上传异常");
                return json.toJSONString();
            }
            //如果上传成功，则将content_Id返回客户端
            String contentId = uploadJsonObj.getString("contentId");
            JSONObject dataJson = new JSONObject();

            //绑定客户头像附件
            ContentRef ref = new ContentRef();
            ref.setContentRefId(UUID.randomUUID().toString());
            ref.setContentId(contentId);
            ref.setContentRefCode("member_id");
            ref.setContentRefType("tbl_members");
            ref.setExternalId(memberId);
            ref.setCreateTime(new Date());
            ref.setComments("换头像");
            int t = this.contentRefService.insertSelective(ref);
            if (t <= 0) {
                json.put("success", false);
                json.put("message", "文件上传异常");
                return json.toJSONString();
            }
            dataJson.put("contentId", contentId);
            dataJson.put("fileName", fileName);
            json.put("success", true);
            json.put("data", dataJson);

            json.put("message", "文件上传成功");
        } catch (Exception e) {
            json.put("success", false);
            json.put("message", "文件上传异常");
            log.error(e.getMessage());
        }
        return json.toJSONString();
    }
    /**
     * @param fileType
     * @return 设定文件
     * boolean    返回类型
     * @throws 2018年3月29日下午9:15:29
     * @Title: checkFileType
     * @Description: 只能是常用视频文件或者压缩文件或者图片文件
     * @author yjx
     */
    private boolean checkFileType(String fileType) {
        boolean flag = false;
        if (fileType.equals("zip") || fileType.equals("rar") || fileType.equals("arj") || fileType.equals("gz")) {
            flag = true;
        }
        if (fileType.equals("bmp") || fileType.equals("jpeg") || fileType.equals("jpg") || fileType.equals("png")
                || fileType.equals("tiff") || fileType.equals("jpe") || fileType.equals("jfif") ||
                fileType.equals("tif")) {
            flag = true;
        }
        if (fileType.equals("3gp") || fileType.equals("rm") || fileType.equals("rmvb") || fileType.equals("mp4")
                || fileType.equals("mov") || fileType.equals("mpeg") || fileType.equals("mpg") ||
                fileType.equals("3gp") || fileType.equals("mtv") || fileType.equals("wmv") || fileType.equals("avi")
                || fileType.equals("amv") || fileType.equals("dmv") || fileType.equals("dat")) {
            flag = true;
        }
        return flag;
    }

    /**
     * 批量修改老人客户状态
     *
     * @param request
     * @param session
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/batchUpdateMemberState", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 36000, rollbackFor = Exception.class)
    public String batchUpdateMemberState(HttpServletRequest request, HttpSession session) {
        JSONObject json = new JSONObject();
        //所有卡编号
        String memberIds = request.getParameter("memberIds");
        //卡状态 1启用 0禁用
        String available = request.getParameter("available");
        //备注
        String remark = request.getParameter("remark");
        log.info("changeCardState方法：memberIds-----" + memberIds + "---available" + available);
        if (org.junit.platform.commons.util.StringUtils.isBlank(memberIds) || org.junit.platform.commons.util.StringUtils.isBlank(available)) {
            json.put("success", false);
            json.put("message", "参数错误");
            return json.toJSONString();
        } else {
            //available 必须为0 1
            if (!("1".equals(available) || "0".equals(available))) {
                json.put("success", false);
                json.put("message", "参数错误");
                return json.toJSONString();
            }
        }
        String[] nos = null;
        if (memberIds.indexOf(",") != -1) {
            nos = memberIds.split(",");
        } else {
            nos = new String[1];
            nos[0] = memberIds;
        }
        if (nos != null) {
            List<String> list = new ArrayList<String>();
            for (String cardNo : nos) {
                list.add(cardNo);
            }
            //拿取当前用户信息
            String token = request.getHeader("token");
            try {
                Map<String, Object> map = JwtUtil.parseManagementToken(token);
                String userId = map.get("uid") == null ? "" : map.get("uid").toString();
                log.info("当前后台登录人id:" + userId);
                String userName = map.get("userName") == null ? "" : map.get("userName").toString();
                log.info("当前后台登录人userName:" + userName);
                if (!list.isEmpty()) {
                    int i = this.membersService.batchUpdateMemberStatus(list, Integer.parseInt(available), remark, userId, userName);
                    if (i > 0) {
                        json.put("success", true);
                        json.put("message", "操作成功");
                    } else {
                        json.put("success", false);
                        json.put("message", "操作失败");
                    }
                }
            } catch (Exception ex) {
                throw new ServiceException("更新状态失败", ex);
            }
        }
        return json.toJSONString();
    }

    /**
     * 后台增加客户方法
     *
     * @param info
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addMemberInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 36000, rollbackFor = Exception.class)
    public String addMemberInfo(MemberExtend info, HttpServletRequest request) {
        JSONObject json = new JSONObject();
        if (null == info || StringUtils.isBlank(info.getName()) || StringUtils.isBlank(info.getPhone())) {
            json.put("success", false);
            json.put("message", "姓名、手机号不能为空");
            return json.toJSONString();
        } else if (RegexUtils.checkMobile(info.getPhone()) == false) {
            //正则校验手机号
            json.put("success", false);
            json.put("message", "手机号格式不正确");
            return json.toJSONString();
        }
        if (StringUtils.isNotBlank(info.getIdNo())) {
            if (RegexUtils.checkIdCard(info.getIdNo()) == false) {
                //正则校验身份证号
                json.put("success", false);
                json.put("message", "身份证号不正确");
                return json.toJSONString();
            }
        }
        //校验库里手机号是否存在
        Members member = membersService.selectOneMembers(info.getPhone(), null);
        if (member != null) {
            json.put("success", false);
            json.put("message", "该手机号已经注册，请使用其他");
            return json.toJSONString();
        }
        //校验身份证号是否存在
        MemberExtend newExtend=new MemberExtend();
        newExtend.setIdNo(info.getIdNo());
        List<MemberExtend> list=this.memberExtendService.selectMemberExtendList(newExtend);
        if(list!=null&&list.size()>0){
            json.put("success", false);
            json.put("message", "该身份证号已经被使用，请使用其他");
            return json.toJSONString();
        }
        info.setAvailable(1);
        info.setCreatedDate(new Date());
        //1.先增加客户主表信息
        Members record = new Members();
        String uId = UUID.randomUUID().toString();
        record.setMemberId(uId);
        record.setPassword("123456");
        record.setCreateType(2);
        //拿取当前用户信息
        String token = request.getHeader("token");
        String userName = "";
        try {
            Map<String, Object> map = JwtUtil.parseManagementToken(token);
            userName = map.get("userName") == null ? "" : map.get("userName").toString();
            log.info("当前后台登录人userName:" + userName);
        } catch (Exception ex) {
            throw new ServiceException("token解析失败", ex);
        }
        record.setCreateBy(userName);
        record.setPhone(info.getPhone());
        record.setCreatedDate(new Date());
        record.setAvailable(1);
        record.setUpdatedDate(new Date());
        try {
            int t = this.membersService.insertSelective(record);
            if (t > 0) {
                //2.增加客户从表信息
                info.setMemberId(uId);
                info.setCreatedDate(new Date());
                info.setAvailable(1);
                //计算年龄
                if (info.getBirthday() != null) {
                    info.setAge(IdcardUtil.getAgeByBirthday1(info.getBirthday()));
                }
                info.setCreateBy(userName);
                info.setLastUpdateTime(new Date());
                int i = this.memberExtendService.insertSelective(info);
                if (i > 0) {
                    json.put("memberId", uId);
                    json.put("success", true);
                    json.put("message", "增加成功");
                } else {
                    json.put("memberId", "");
                    json.put("success", false);
                    json.put("message", "增加失败");
                }
            } else {
                json.put("success", false);
                json.put("message", "增加失败");
            }
        } catch (Exception ex) {
            throw new ServiceException("操作异常", ex);
        }
        return json.toJSONString();
    }

    /**
     * 后台修改客户方法
     *
     * @param info
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/backUpdateMemberInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 36000, rollbackFor = Exception.class)
    public String backUpdateMemberInfo(MemberExtend info, HttpServletRequest request) {
        JSONObject json = new JSONObject();
        if (null == info || StringUtils.isBlank(info.getMemberId()) || StringUtils.isBlank(info.getName()) || StringUtils.isBlank(info.getPhone())) {
            json.put("success", false);
            json.put("message", "姓名、手机号不能为空");
            return json.toJSONString();
        } else if (RegexUtils.checkMobile(info.getPhone()) == false) {
            //正则校验手机号
            json.put("success", false);
            json.put("message", "手机号格式不正确");
            return json.toJSONString();
        }
        if (StringUtils.isNotBlank(info.getIdNo())) {
            if (RegexUtils.checkIdCard(info.getIdNo()) == false) {
                //正则校验身份证号
                json.put("success", false);
                json.put("message", "身份证号不正确");
                return json.toJSONString();
            }
        }
        Members oldMember = this.membersService.selectByPrimaryKey(info.getMemberId());
        MemberExtend oldInfo = this.memberExtendService.selectByPrimaryKey(info.getMemberId());
        if (oldMember == null) {
            json.put("success", false);
            json.put("message", "对应客户不存在");
            return json.toJSONString();
        }
        //拿取当前用户信息
        String token = request.getHeader("token");
        String userName = "";
        try {
            Map<String, Object> map = JwtUtil.parseManagementToken(token);
            userName = map.get("userName") == null ? "" : map.get("userName").toString();
            log.info("当前后台登录人userName:" + userName);
        } catch (Exception ex) {
            throw new ServiceException("token解析失败", ex);
        }
        try {
            //若身份证号改变校验是否存在
            if (StringUtils.isNotBlank(info.getIdNo())&&!info.getIdNo().equals(oldInfo.getIdNo())) {
                MemberExtend newExtend = new MemberExtend();
                newExtend.setIdNo(info.getIdNo());
                List<MemberExtend> list = this.memberExtendService.selectMemberExtendList(newExtend);
                if (list != null && list.size() > 0) {
                    json.put("success", false);
                    json.put("message", "该身份证号已经被使用，请使用其他");
                    return json.toJSONString();
                }
            }
             //若手机号不同 进行更新
            if (!info.getPhone().equals(oldMember.getPhone())) {
                //若手机号改变 校验库里是否存在
                Members member = membersService.selectOneMembers(info.getPhone(), null);
                if (member != null) {
                    json.put("success", false);
                    json.put("message", "该手机号已经注册，请使用其他");
                    return json.toJSONString();
                }
                oldMember.setPhone(info.getPhone());
                oldMember.setUpdatedDate(new Date());
                int i = this.membersService.updateByPrimaryKeySelective(oldMember);
                if (i > 0) {
                    log.info("更新客户" + info.getMemberId() + "的手机号为" + info.getPhone());
                }
            }
            //若出生日期改变，修改年龄
            if(info.getBirthday()!=null){
                info.setAge(IdcardUtil.getAgeByBirthday1(info.getBirthday()));
            }
            //复制属性到旧的
            BeanUtils.copyProperties(info, oldInfo);
            oldInfo.setLastUpdateTime(new Date());
            oldInfo.setLastUpdateBy(userName);

            int t = this.memberExtendService.updateByPrimaryKeySelective(oldInfo);
            if (t > 0) {
                json.put("success", true);
                json.put("message", "修改成功");
                log.info("更新客户" + info.getMemberId() + "信息成功");
            } else {
                json.put("success", false);
                json.put("message", "修改失败");
            }
        } catch (Exception ex) {
            throw new ServiceException("更新异常", ex);
        }
        return json.toJSONString();
    }
    /**
     * app首页查询个人及亲友健康情况
     *
     * @param memberId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryMemberHealthData", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryMemberHealthData(String memberId) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        //存放组装结果集
        List<KithHealthObj> healthList = new ArrayList<KithHealthObj>();
        KithHealthObj healthObj = null;
        String contentId = "";
        //查询个人信息
        Members members = this.membersService.selectByPrimaryKey(memberId);
        if (members != null) {
            healthObj = new KithHealthObj();
            healthObj.setRelationRemark("我");
            healthObj.setNickName("我");
            //头像id
            List<Content> cList = this.contentService.selectContentsById(memberId, "tbl_members", "1001");
            if (!cList.isEmpty() && cList.size() > 0) {
                contentId = cList.get(0).getContentId();
                healthObj.setContentId(contentId);
            }
            //体检信息
            healthObj=addCheckInfo(healthObj,memberId);
            healthList.add(healthObj);
        } else {
            json.put("success", false);
            json.put("message", "不存在的客户id");
            return json.toJSONString();
        }
        //查询特别关注且有效的亲友列表
        List<KithAndKin> list = this.kithAndKinService.selectUserKithList(memberId,1);
        if (!list.isEmpty()) {
            //循环放置附件id
            log.info("查询出亲友个数:" + list.size());
            for (KithAndKin kith : list) {
                healthObj = new KithHealthObj();
                healthObj.setNickMemberId(kith.getNickMemberId());
                healthObj.setAccessNick(kith.getAccessNick());//申请访问
                //若姓名为空 显示手机号
                if(StringUtils.isBlank(kith.getNickName())){
                    Members extend= this.membersService.selectByPrimaryKey(kith.getNickMemberId());
                    if(extend!=null){
                        healthObj.setNickName(extend.getPhone());
                    }else{
                        healthObj.setNickName("");
                    }
                }else{
                    healthObj.setNickName(kith.getNickName());
                }
                healthObj.setRelationRemark(kith.getRelationRemark());
                List<Content> cList = this.contentService.selectContentsById(kith.getNickMemberId(), "tbl_members", "1001");
                if (!cList.isEmpty() && cList.size() > 0) {
                    contentId = cList.get(0).getContentId();
                    healthObj.setContentId(contentId);
                }
                //查询亲友的体检信息
                if (StringUtils.isNotBlank(kith.getNickMemberId())) {
                    healthObj=addCheckInfo(healthObj,kith.getNickMemberId());
                    healthList.add(healthObj);
                }
            }
          }
            dataJson.put("data", healthList);
            json.put("data", dataJson);
            json.put("success", true);
            json.put("message", "查询成功");
            return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
        }
    /**
     * 拼接检测信息
     * @param healthObj
     * @param memberId
     * @return
     */
    public KithHealthObj addCheckInfo(KithHealthObj healthObj,String memberId){
            Map<String,Object> map=new HashMap<String,Object>();
            map.put("memberId",memberId);
            PageBean bean=new PageBean();
            bean.setPageSize(1);
            bean.setRowStart(0);
            List<TestRecord> testList=this.testRecordService.selectTestRecordList(map,bean);
            if(testList!=null&&testList.size()>0){
                TestRecord record=testList.get(0);
                String text= record.getRecord();
                if(StringUtils.isNotBlank(text)){
                    CheckData checkData=JSONObject.parseObject(text,CheckData.class);
                    log.info(checkData.getReportNo());
                    if(checkData!=null){
                        //血糖
                        if(checkData.getBloodSugarState()==3){
                            healthObj.setBloodSugar(1);
                        }else if(checkData.getBloodSugarState()==0){
                            healthObj.setBloodSugar(0);
                        }else{
                            healthObj.setBloodSugar(2);
                        }
                        //血压
                        if(checkData.getHeightPressureState()==0&&checkData.getLowPressureState()==0){
                            healthObj.setBloodPressure(0);
                        }else if(checkData.getHeightPressureState()==5&&checkData.getLowPressureState()==5){
                            healthObj.setBloodPressure(1);
                        }else{
                            healthObj.setBloodPressure(2);
                        }
                        //体重
                        if(checkData.getHwBmiState()==0){
                            healthObj.setWeightState(0);
                        }else  if(checkData.getHwBmiState()==1){
                            healthObj.setWeightState(1);
                        }else{
                            healthObj.setWeightState(2);
                        }
                        //血氧
                        if(checkData.getOxygenSaturationState()==1){
                            healthObj.setBloodOxygenState(0);
                        }else if(checkData.getOxygenSaturationState()==3){
                            healthObj.setBloodOxygenState(1);
                        }else{
                            healthObj.setBloodOxygenState(2);
                        }
                        //体脂
                        if(checkData.getFatRateState()==0){
                            healthObj.setFatRateState(0);
                        }else if(checkData.getFatRateState()==3){
                            healthObj.setFatRateState(1);
                        }else{
                            healthObj.setFatRateState(2);
                        }
                        //尿酸
                        if(checkData.getUricAcidState()==0){
                            healthObj.setUrineState(0);
                        }else if(checkData.getUricAcidState()==3){
                            healthObj.setUrineState(1);
                        }else{
                            healthObj.setUrineState(2);
                        }
                        //血脂  胆固醇 甘油三酯 高密度蛋白  低密度蛋白 mmol/L
                        if(checkData.getTotalCholesterolState()==0&&checkData.getTriglyceridesState()==0&&checkData.getHeightLipoproteinState()==0&&checkData.getLowLipoprotein()==0){
                            healthObj.setBloodFatState(0);
                        }else if(checkData.getTotalCholesterolState()==3&&checkData.getTriglyceridesState()==3&&checkData.getHeightLipoproteinState()==3&&checkData.getLowLipoprotein()==3){
                            healthObj.setBloodFatState(1);
                        }else{
                            healthObj.setBloodFatState(2);
                        }
                        //心率
                        if(checkData.getEcgRateState()==0){
                            healthObj.setEcgRateState(0);
                        }else  if(checkData.getEcgRateState()==3){
                            healthObj.setEcgRateState(1);
                        }else{
                            healthObj.setEcgRateState(2);
                        }
                    }
                }
            }else{
                healthObj.setBloodSugar(0);
                healthObj.setBloodPressure(0);
                healthObj.setWeightState(0);
                healthObj.setBloodOxygenState(0);
                healthObj.setFatRateState(0);
                healthObj.setUrineState(0);
            }
          return healthObj;
    }

    /**
     * 通过身份证获取用户信息 体检接口
     * @param requestJson
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/getUserByIdcard", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String getUserByIdcard(@RequestBody  String requestJson){
        JSONObject json=new JSONObject();
        if(StringUtils.isBlank(requestJson)){
            json.put("code",2);
            json.put("msg","参数为空");
            json.put("data","");
        }
        JSONObject para=JSONObject.parseObject(requestJson);
        String idNo="";
        if(para!=null&&para.get("idcard")!=null){
            idNo=para.get("idcard").toString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("idNo",idNo);
        MemberObj obj=this.membersService.getMemberByPara(map);
        if(obj!=null){
            //查询用户头像
            List<Content> list1 = contentService.selectContentsById(obj.getMemberId(), "tbl_members", "1001");
            if (list1 != null && list1.size() > 0) {
                String contentId = list1.get(0).getContentId();
                String url="https://www.hyjxyl.xyz/api/contentController/fileDownloadForFrontPlatForm?contentId="+contentId;
                obj.setPhotoPath(url);
            }
            json.put("code",1);
            json.put("msg","查询成功");
            json.put("data",obj);
        }else{
            json.put("code",2);
            json.put("msg","查询对象不存在");
            json.put("data",obj);
        }
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 通过用户手机号获取用户信息
     * @param requestJson
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/getUserByPhone", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String getUserByPhone(String requestJson){
        JSONObject json=new JSONObject();
        if(StringUtils.isBlank(requestJson)){
            json.put("code",2);
            json.put("msg","参数为空");
            json.put("data","");
        }
        JSONObject para=JSONObject.parseObject(requestJson);
        String phone="";
        if(para!=null&&para.get("phone")!=null){
            phone=para.get("phone").toString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("phone",phone);
        MemberObj obj=this.membersService.getMemberByPara(map);
        if(obj!=null){
            //查询用户头像
            List<Content> list1 = contentService.selectContentsById(obj.getMemberId(), "tbl_members", "1001");
            if (list1 != null && list1.size() > 0) {
                String contentId = list1.get(0).getContentId();
                String url="https://www.hyjxyl.xyz/api/contentController/fileDownloadForFrontPlatForm?contentId="+contentId;
                obj.setPhotoPath(url);
            }
            json.put("code",1);
            json.put("msg","查询成功");
            json.put("data",obj);
        }else{
            json.put("code",2);
            json.put("msg","查询对象不存在");
            json.put("data",obj);
        }
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 检查手机号是否被使用(身份证体检)
     * @param requestJson
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/checkPhoneByIdcard", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String checkPhoneByIdcard(String requestJson){
        JSONObject json=new JSONObject();
        if(StringUtils.isBlank(requestJson)){
            json.put("code",2);
            json.put("msg","参数为空");
            json.put("data","");
        }
        JSONObject para=JSONObject.parseObject(requestJson);
        String phone="";
        if(para!=null&&para.get("phone")!=null){
            phone=para.get("phone").toString();
        }
        String idNo="";
        if(para!=null&&para.get("idcard")!=null){
            idNo=para.get("idcard").toString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("idNo",idNo);
        map.put("phone",phone);
        MemberObj obj=this.membersService.getMemberByPara(map);
        if(obj!=null){
            //查询用户头像
            List<Content> list1 = contentService.selectContentsById(obj.getMemberId(), "tbl_members", "1001");
            if (list1 != null && list1.size() > 0) {
                String contentId = list1.get(0).getContentId();
                String url="https://www.hyjxyl.xyz/api/contentController/fileDownloadForFrontPlatForm?contentId="+contentId;
                obj.setPhotoPath(url);
            }
            json.put("code",1);
            json.put("msg","查询成功");
            json.put("data",obj);
        }else{
            json.put("code",2);
            json.put("msg","该手机号已被使用,请重新输入");
            json.put("data","");
        }
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 卡号验证
     * @param requestJson cardNo
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/checkUserByCardNo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String checkUserByCardNo(String requestJson){
        JSONObject json=new JSONObject();
        if(StringUtils.isBlank(requestJson)){
            json.put("code",2);
            json.put("msg","参数为空");
            json.put("data","");
        }
        JSONObject para=JSONObject.parseObject(requestJson);
        String cardNo="";
        if(para!=null&&para.get("cardNo")!=null){
            cardNo=para.get("cardNo").toString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardNo",cardNo);
        MemberObj obj=this.membersService.getMemberByPara(map);
        if(obj!=null){
            //查询用户头像
            List<Content> list1 = contentService.selectContentsById(obj.getMemberId(), "tbl_members", "1001");
            if (list1 != null && list1.size() > 0) {
                String contentId = list1.get(0).getContentId();
                String url="https://www.hyjxyl.xyz/api/contentController/fileDownloadForFrontPlatForm?contentId="+contentId;
                obj.setPhotoPath(url);
            }
            json.put("code",1);
            json.put("msg","查询成功");
            json.put("data",obj);
        }else{
            json.put("code",2);
            json.put("msg","卡号不存在");
            json.put("data","");
        }
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
