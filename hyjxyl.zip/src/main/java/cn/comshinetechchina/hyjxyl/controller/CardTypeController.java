package cn.comshinetechchina.hyjxyl.controller;
import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.CardType;
import cn.comshinetechchina.hyjxyl.domain.CardTypeServiceBean;
import cn.comshinetechchina.hyjxyl.domain.TblLog;
import cn.comshinetechchina.hyjxyl.service.CardTypeService;
import cn.comshinetechchina.hyjxyl.service.CardTypeServiceService;
import cn.comshinetechchina.hyjxyl.service.TblLogService;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.junit.platform.commons.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.util.*;

/**
 * 卡类型控制层
 * Author：yjx
 */
@RestController
@RequestMapping("/cardTypeController")
public class CardTypeController extends BaseController {
    private Logger log= LoggerFactory.getLogger(CardTypeController.class);
    @Resource
    private CardTypeService cardTypeService;
    @Resource
    private CardTypeServiceService cardTypeServiceService;
    @Resource
    private TblLogService logService;

    /**
     * 查询卡类别列表接口
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryCardTypes", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryCardTypes(HttpServletRequest request){
        JSONObject json=new JSONObject();
        JSONObject dataJson=new JSONObject();
        String name=request.getParameter("name");
        String available=request.getParameter("available")==null?"1":request.getParameter("available");
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("name",name);
        map.put("available",available);
        List<CardType> list=new ArrayList<CardType>();
        try {
            list = cardTypeService.selectAllCardTypes(map);
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list",list);
        json.put("data",list);
        json.put("success",true);
        json.put("message","查询成功");
        return json.toJSONString();
    }
    /**
     * 增加卡类别接口
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addCardType", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addCardType(CardType info){
        JSONObject json=new JSONObject();
        JSONObject dataJson=new JSONObject();
        if(null==info|| StringUtils.isBlank(info.getName())){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        //若名称改变 验证类别名称不能重复
        CardType oldInfo=this.cardTypeService.selectByPrimaryKey(info.getCardTypeId());
        if(!oldInfo.getName().equals(info.getName())){
            Map<String,Object> map=new HashMap<String,Object>();
            map.put("name",info.getName());
            List<CardType> list=this.cardTypeService.selectAllCardTypes(map);
            if(list!=null&&list.size()>0){
                json.put("success",false);
                json.put("message","类别名称已经存在");
                return json.toJSONString();
            }
        }

        String uId= UUID.randomUUID().toString();
        info.setCardTypeId(uId);
        info.setAvailable(1);
        info.setCreatedDate(new Date());
        try {
            int i = cardTypeService.insertSelective(info);
            dataJson.put("cardTypeId",uId);
            json.put("data",dataJson);
            if(i>0){
                json.put("success",true);
                json.put("message","增加成功");
            }else{
                json.put("success",false);
                json.put("message","增加失败");
            }
        }catch(Exception ex){
            throw new ServiceException("增加异常",ex);
        }
        return json.toJSONString();
    }

    /**
     * 删除卡类别接口(假删除、状态置为无效)
     * @param cardTypeId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/delCardTypeById", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String delCardTypeById(String cardTypeId){
        JSONObject json=new JSONObject();
        if(StringUtils.isBlank(cardTypeId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        try {
            CardType cardType=new CardType();
            cardType.setCardTypeId(cardTypeId);
            cardType.setAvailable(0);
            cardType.setUpdatedDate(new Date());
            int i = cardTypeService.updateByPrimaryKeySelective(cardType);
            if(i>0){
                log.info("卡类型："+cardTypeId+"状态置为无效成功");
                json.put("success",true);
                json.put("message","操作成功");
            }else{
                json.put("success",false);
                json.put("message","操作失败");
            }
        }catch(Exception ex){
            throw new ServiceException("删除异常",ex);
        }
        return json.toJSONString();
    }

    /**
     * 修改卡类型接口
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateCardType", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String updateCardType(CardType info){
        JSONObject json=new JSONObject();
        if(null==info|| StringUtils.isBlank(info.getName())||StringUtils.isBlank(info.getCardTypeId())){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        CardType type=this.cardTypeService.selectByPrimaryKey(info.getCardTypeId());
        if(type==null){
            json.put("success",false);
            json.put("message","该卡类型不存在");
            return json.toJSONString();
        }
        try {
            type.setUpdatedDate(new Date());
            type.setName(info.getName());
            type.setDescription(info.getDescription());
            type.setAvailable(info.getAvailable());
            int i = cardTypeService.updateByPrimaryKeySelective(type);
            if(i>0){
                json.put("success",true);
                json.put("message","更新成功");
            }else{
                json.put("success",false);
                json.put("message","更新失败");
            }
        }catch(Exception ex){
            throw new ServiceException("更新异常",ex);
        }
        return json.toJSONString();
    }
    /**
     * 新增卡类型并绑定服务列表
     * @param bean
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/cardTypeBindService", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String cardTypeBindService(@RequestBody CardTypeServiceBean bean,HttpServletRequest request) throws ParseException {
        log.info("进入cardTypeBindService方法");
        JSONObject json = new JSONObject();
        if (null==bean||StringUtils.isBlank(bean.getName())) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        if (bean.getServices().size()<=0) {
            json.put("success", false);
            json.put("message", "服务不能为空");
            return json.toJSONString();
        }
        CardType cardType=new CardType();
        cardType.setName(bean.getName());
        cardType.setDescription(bean.getDescription());
        log.info("cardTypename:"+cardType.getName());
        String uId=UUID.randomUUID().toString();
        cardType.setCardTypeId(uId);
        cardType.setAvailable(1);
        cardType.setCreatedDate(new Date());
        int i=this.cardTypeService.insertSelective(cardType);
        JSONObject dataJson = new JSONObject();
        dataJson.put("cardTypeId",uId);
        json.put("data",dataJson);
        List<cn.comshinetechchina.hyjxyl.domain.CardTypeService> services=bean.getServices();
        if(i>0){
            //批量插入服务信息
            if(services!=null&&services.size()>0){
                for(cn.comshinetechchina.hyjxyl.domain.CardTypeService obj:services){
                    obj.setCardTypeServiceId(UUID.randomUUID().toString());
                    obj.setCreateTime(new Date());
                    obj.setCardTypeId(uId);
                    String token = request.getHeader("token");
                    Map<String, Object> map = JwtUtil.parseManagementToken(token);
                    String userId = map.get("uid") == null ? "" : map.get("uid").toString();
                    obj.setCreateBy(userId);
                }
                int t =this.cardTypeServiceService.batchInsertSelective(services);
                if (t > 0) {
                    json.put("success", true);
                    json.put("message", "成功");
                } else {
                    json.put("success", false);
                    json.put("message", "操作失败");
                }
            }
        }else{
            json.put("success", false);
            json.put("message", "操作失败");
        }
        return json.toJSONString();
    }

    /**
     * 更新卡类型绑定服务接口
     * @param bean
     * @param request
     * @return
     * @throws ParseException
     */
    @ResponseBody
    @RequestMapping(value = "/updateCardTypeBindService", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String updateCardTypeBindService(@RequestBody CardTypeServiceBean bean,HttpServletRequest request) throws ParseException {
        log.info("进入updateCardTypeBindService方法");
        JSONObject json = new JSONObject();
        if (null==bean||StringUtils.isBlank(bean.getCardTypeId())||StringUtils.isBlank(bean.getName())) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        if (bean.getServices().size()<=0) {
            json.put("success", false);
            json.put("message", "服务不能为空");
            return json.toJSONString();
        }
        //查询对应卡类型
        CardType cardType=this.cardTypeService.selectByPrimaryKey(bean.getCardTypeId());
        if(cardType==null){
            json.put("success", false);
            json.put("message", "对应卡类型不存在");
            return json.toJSONString();
        }
        if(StringUtils.isNotBlank(bean.getName())){
            cardType.setName(bean.getName());
        }
        if(StringUtils.isNotBlank(bean.getDescription())){
            cardType.setDescription(bean.getDescription());
        }
        log.info("cardTypename:"+cardType.getName());
        cardType.setUpdatedDate(new Date());
        int i=this.cardTypeService.updateByPrimaryKeySelective(cardType);
        List<cn.comshinetechchina.hyjxyl.domain.CardTypeService> services=bean.getServices();
        String userId="";
        String userName="";
        if(i>0){
            //先删除旧的绑定服务
             int j=this.cardTypeServiceService.deleteRecordByPara(bean.getCardTypeId());
             if(j>=0){
                 log.info("成功删除了卡类型"+cardType.getName()+"的"+j+"条绑定服务");
             }
             StringBuffer newServiceIds=new StringBuffer("");
            //再批量插入新绑定服务信息
            if(services!=null&&services.size()>0){
                for(cn.comshinetechchina.hyjxyl.domain.CardTypeService obj:services){
                    newServiceIds.append("服务id:"+obj.getServiceId()+"新次数："+obj.getTotalCount()).append(";");
                    obj.setCardTypeServiceId(UUID.randomUUID().toString());
                    obj.setCreateTime(new Date());
                    obj.setCardTypeId(bean.getCardTypeId());
                    String token = request.getHeader("token");
                    Map<String, Object> map = JwtUtil.parseManagementToken(token);
                    userId = map.get("uid") == null ? "" : map.get("uid").toString();
                    userName = map.get("userName") == null ? "" : map.get("userName").toString();
                    obj.setCreateBy(userId);
                }
                log.info("当前用户："+userName);
                int t =this.cardTypeServiceService.batchInsertSelective(services);
                if (t > 0) {
                    log.info("卡类型"+cardType.getName()+"批量插入了"+t+"条绑定服务");
                    json.put("success", true);
                    json.put("message", "操作成功");
                } else {
                    json.put("success", false);
                    json.put("message", "操作失败");
                }
            }
            //最后插入日志
            TblLog record=new TblLog();
            record.setLogId(UUID.randomUUID().toString());
            record.setOperateTime(new Date());
            record.setOperateContent(newServiceIds.toString());
            record.setOperateTableId(bean.getCardTypeId());
            record.setOperateTableName("tbl_card_type_services");
            record.setUserId(userId);
            record.setUserName(userName);
            this.logService.insertSelective(record);
        }else{
            json.put("success", false);
            json.put("message", "操作失败");
        }
        return json.toJSONString();
    }
    /**
     * 查询卡类别详情接口
     * @param cardTypeId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryCardTypeDetail", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryCardTypeDetail(String cardTypeId){
        JSONObject json=new JSONObject();
        JSONObject dataJson=new JSONObject();
        if (StringUtils.isBlank(cardTypeId)) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //卡类型信息
        CardType info=null;
        //卡对应服务信息
        List<cn.comshinetechchina.hyjxyl.domain.CardTypeService> servicelist=new ArrayList<cn.comshinetechchina.hyjxyl.domain.CardTypeService>();
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardTypeId",cardTypeId);
        List<CardType> list=null;
        try {
            list = cardTypeService.selectAllCardTypes(map);
            if(list!=null&&list.size()>0){
                info=list.get(0);
            }
            Map<String,String> map1=new HashMap<String,String>();
            map1.put("cardTypeId",cardTypeId);
            servicelist=this.cardTypeServiceService.selectCardTypeServiceList(map1);
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("cardTypeInfo",info);
        dataJson.put("serviceList",servicelist);
        json.put("data",dataJson);
        json.put("success",true);
        json.put("message","查询成功");
        return json.toJSONString();
    }
}
