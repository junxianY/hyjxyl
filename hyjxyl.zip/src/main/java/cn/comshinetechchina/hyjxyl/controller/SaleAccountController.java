package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.RequestPara;
import cn.comshinetechchina.hyjxyl.domain.SaleAccount;
import cn.comshinetechchina.hyjxyl.service.SaleAccountService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 服务专员控制器
 */
@RestController
@RequestMapping("/saleAccountController")
public class SaleAccountController extends BaseController{
    @Resource
    private SaleAccountService saleAccountService;

    /**
     * 分页查询接口
     * @param para
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/querySaleAccountList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String querySaleAccountList(RequestPara para){
    JSONObject json=new JSONObject();
    JSONObject dataJson = new JSONObject();
    PageBean bean = new PageBean();
     if (para.getPageSize()>=0) {
          bean.setPageSize(para.getPageSize());
     }
     if (para.getPageIndex()>=0) {
        bean.setRowStart(para.getPageSize()*para.getPageIndex());
     }
     Map<String,Object> map=new HashMap<String,Object>();
     map.put("name",para.getName());
     map.put("available",para.getAvailable());
     map.put("startDate",para.getStartDate());
     map.put("endDate",para.getEndDate());
     int totalCount = 0;
     List<SaleAccount> list=null;
     try {
         list = saleAccountService.querySaleAccountList(map, bean);
         totalCount=bean.getTotalRows();
     }catch(Exception ex){
         throw new ServiceException("查询异常",ex);
     }
     dataJson.put("totalCount", totalCount);
     dataJson.put("pageIndex", para.getPageIndex());
     dataJson.put("list", list);
     json.put("data",dataJson);
     json.put("success",true);
     json.put("msg","查询成功");
     return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 增加接口
     * @param account
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addSaleAccount", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addSaleAccount(SaleAccount account){
        JSONObject json=new JSONObject();
        if(account!=null){
            if(StringUtils.isBlank(account.getCode())){
                json.put("success",false);
                json.put("msg","编号不能为空");
                return json.toJSONString();
            }
            if(StringUtils.isBlank(account.getName())){
                json.put("success",false);
                json.put("msg","姓名不能为空");
                return json.toJSONString();
            }else{
                //判断库里是否存在此编号
                SaleAccount saleAccount=this.saleAccountService.selectByPrimaryKey(account.getCode());
                if(saleAccount!=null){
                    json.put("success",false);
                    json.put("msg","该编号已经存在，请使用其他");
                    return json.toJSONString();
                }
            }
        }
        account.setCreatedDate(new Date());
        account.setAvailable(1);
        int i=this.saleAccountService.insertSelective(account);
        if(i>0){
            json.put("success",true);
            json.put("msg","操作成功");
        }else{
            json.put("success",false);
            json.put("msg","操作失败");
        }
        return json.toJSONString();
    }

    /**
     * 删除接口
     * @param code
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/delSaleAccount", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String delSaleAccount(String code){
        JSONObject json=new JSONObject();
        if(StringUtils.isBlank(code)){
            json.put("success",false);
            json.put("msg","参数不能为空");
            return json.toJSONString();
        }
        int i=this.saleAccountService.deleteByPrimaryKey(code);
        if(i>0){
            json.put("success",true);
            json.put("msg","操作成功");
        }else{
            json.put("success",false);
            json.put("msg","操作失败");
        }
        return json.toJSONString();
    }

    /**
     * 修改信息接口
     * @param account
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateSaleAccount", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String updateSaleAccount(SaleAccount account){
        JSONObject json=new JSONObject();
        if(null==account||StringUtils.isBlank(account.getCode())){
            json.put("success",false);
            json.put("msg","参数不能为空");
            return json.toJSONString();
        }
        account.setUpdatedDate(new Date());
        int i=this.saleAccountService.updateByPrimaryKeySelective(account);
        if(i>0){
            json.put("success",true);
            json.put("msg","操作成功");
        }else{
            json.put("success",false);
            json.put("msg","操作失败");
        }
        return json.toJSONString();
    }
}
