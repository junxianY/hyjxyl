package cn.comshinetechchina.hyjxyl.controller;
import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecordCountObj;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecordObj;
import cn.comshinetechchina.hyjxyl.domain.UseCardObj;
import cn.comshinetechchina.hyjxyl.service.CardUseRecordService;
import cn.comshinetechchina.hyjxyl.service.DeviceService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.sql.rowset.serial.SerialException;
import java.text.ParseException;
import java.util.*;

/**
 * 刷卡记录控制层
 * Author:yjx
 */
@RestController
@RequestMapping("/cardUseRecordController")
public class CardUseRecordController extends BaseController {
  private Logger log= LoggerFactory.getLogger(CardUseRecordController.class);
  @Resource
  private DeviceService deviceService;
  @Resource
  private CardUseRecordService cardUseRecordService;

    /**
     * 中控回传刷卡记录接口
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/useCardInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String useCardInfo(@RequestBody UseCardObj info) {
        JSONObject json=new JSONObject();
        if(null==info||StringUtils.isBlank(info.getCardNo())||StringUtils.isBlank(info.getDeviceNo())){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        //判断插入记录
        String res=this.cardUseRecordService.insertCardRecord(info.getCardNo(),info.getDeviceNo());
        return res;
    }

    /**
     * 查询个人用卡记录
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryUseRecord", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryUseRecord(HttpServletRequest request) {
        JSONObject json=new JSONObject();
        //用户id
        String memberId=request.getParameter("memberId");
        if(StringUtils.isBlank(memberId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("memberId",memberId);
        int totalCount=0;
        //开始时间
        String startDate=request.getParameter("startDate");
        map.put("startDate",startDate);
        //结束时间
        String endDate=request.getParameter("endDate");
        map.put("endDate",endDate);
        List<CardUseRecordObj> list=new ArrayList<CardUseRecordObj>();
        try {
            list = this.cardUseRecordService.selectRecordList(bean, map);
            totalCount=bean.getTotalRows();
            json.put("success",true);
            json.put("message","查询成功");
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        JSONObject dataJson=new JSONObject();
        dataJson.put("list",list);
        dataJson.put("totalCount", totalCount);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 按时间段分服务统计次数
     * @param memberId
     * @param type 1半月 2一个月 3半年 4一年
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryCountUseRecord", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryCountUseRecord(String memberId,Integer type) {
        JSONObject json = new JSONObject();
        if(StringUtils.isBlank(memberId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        JSONObject dataJson = new JSONObject();
        String startDate="";
        String endDate= null;
        try {
            endDate = DateUtil.transferDate2Str(new Date(),"yyyy-MM-dd");
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Date d1=null;
        if(type==1){
             d1=DateUtil.getSysDate(0,0,-15);
        }else if(type==2){
             d1=DateUtil.getSysDate(0,-1,0);
        }else if(type==3){
            d1=DateUtil.getSysDate(0,-6,0);
        }else if(type==4){
            d1=DateUtil.getSysDate(-1,0,0);
        }
        try {
            startDate=DateUtil.transferDate2Str(d1,"yyyy-MM-dd");
        } catch (ParseException e) {
            e.printStackTrace();
        }
        log.info("---memberId:"+memberId+"--startDate:"+startDate+"--endDate:"+endDate);
        List<CardUseRecordCountObj> list=new ArrayList<CardUseRecordCountObj>();

        list=this.cardUseRecordService.countCardUseRecord(memberId,startDate,endDate);
        dataJson.put("list",list);
        json.put("data",dataJson);
        json.put("success",true);
        json.put("message","查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
