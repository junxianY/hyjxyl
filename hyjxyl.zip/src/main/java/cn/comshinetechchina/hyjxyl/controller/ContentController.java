package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.Config;
import cn.comshinetechchina.hyjxyl.domain.Content;
import cn.comshinetechchina.hyjxyl.domain.ContentType;
import cn.comshinetechchina.hyjxyl.service.ConfigService;
import cn.comshinetechchina.hyjxyl.service.ContentService;
import cn.comshinetechchina.hyjxyl.service.ContentTypeService;
import cn.comshinetechchina.hyjxyl.util.BASE64DecodedMultipartFile;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

/**
 * 附件控制层
 * createTime:2018.03.29
 * author:yjx
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/contentController")
public class ContentController extends BaseController {
    private static final Logger log= LoggerFactory.getLogger(ContentController.class);
    @Resource
    private ContentService contentService;
    @Resource
    private ContentTypeService contentTypeService;
    @Resource
    private ConfigService configService;

    /**
     * 上传附件方法
     * @param file 文件流
     * @param typeCode  文件类型code
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/uploadFile",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String uploadFile(@RequestParam("file") MultipartFile file,@RequestParam("typeCode")String typeCode){
        JSONObject json = new JSONObject();
        if(StringUtils.isEmpty(typeCode)||null == file){
            json.put("success", false);
            json.put("message", "文件上传参数异常");
            return json.toJSONString();
        }
        if (file.getSize() >= 10*1024*1024)
        {
            json.put("success", false);
            json.put("message", "文件大小不能大于10兆");
            return json.toJSONString();
        }

         try {
            String fileName = file.getOriginalFilename();
             log.info("-----uploadFile---"+typeCode+"---"+fileName);
            String fileType = fileName.substring(fileName.lastIndexOf(".")+1);
            fileType = fileType.toLowerCase();
            boolean b = checkFileType(fileType);
            if(!b){
                json.put("success", false);
                json.put("message", "文件格式异常");
                return json.toJSONString();
            }
            String contentName = "";
            String contentTypeId="";
            //通过code查询相应配置
            ContentType contentType=this.contentTypeService.selectOneContentType(typeCode,1);
            if(contentType!=null){
                contentName=contentType.getContentTypeName();
                contentTypeId=contentType.getContentTypeId().toString();
            }else{
                json.put("success", false);
                json.put("message", "文件上传参数异常");
                return json.toJSONString();
            }
            String uploadJson = contentService.saveFileUpload(file, contentName,contentTypeId);
            JSONObject uploadJsonObj = JSONObject.parseObject(uploadJson);
            Boolean sucFlag = uploadJsonObj.getBoolean("success");
            if(!sucFlag){
                json.put("success", false);
                json.put("message", "文件上传异常");
                return json.toJSONString();
            }
            //如果上传成功，则将content_Id返回客户端
            String contentId = uploadJsonObj.getString("contentId");
            JSONObject dataJson = new JSONObject();
            dataJson.put("contentId",contentId);
            dataJson.put("fileName",fileName);
            json.put("success", true);
            json.put("data", dataJson);
            json.put("message", "文件上传成功");
        } catch (Exception e) {
            json.put("success", false);
            json.put("message", "文件上传异常");
            log.error(e.getMessage());
        }
        return json.toJSONString();
    }

    /**
     * 上传base64图片方法
     * @param baseFile
     * @param typeCode
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/uploadBase64File",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String uploadBase64File(String baseFile,String typeCode){
        log.info("-----uploadBase64File---"+typeCode+"----"+baseFile);
        MultipartFile file= BASE64DecodedMultipartFile.base64ToMultipart(baseFile);
        JSONObject json = new JSONObject();
        if(null == file||StringUtils.isEmpty(typeCode)){
            json.put("success", false);
            json.put("message", "文件上传参数异常");
            return json.toJSONString();
        }
        try {
            String fileName = file.getOriginalFilename();
            String fileType = fileName.substring(fileName.lastIndexOf(".")+1);
            fileType = fileType.toLowerCase();
            boolean b = checkFileType(fileType);
            if(!b){
                json.put("success", false);
                json.put("message", "文件格式异常");
                return json.toJSONString();
            }
            String contentName = "";
            String contentTypeId="";
            //通过code查询相应配置
            ContentType contentType=this.contentTypeService.selectOneContentType(typeCode,1);
            if(contentType!=null){
                contentName=contentType.getContentTypeName();
                contentTypeId=contentType.getContentTypeId().toString();
            }else{
                json.put("success", false);
                json.put("message", "文件上传参数异常");
                return json.toJSONString();
            }
            String uploadJson = contentService.saveFileUpload(file, contentName,contentTypeId);
            JSONObject uploadJsonObj = JSONObject.parseObject(uploadJson);
            Boolean sucFlag = uploadJsonObj.getBoolean("success");
            if(!sucFlag){
                json.put("success", false);
                json.put("message", "文件上传异常");
                return json.toJSONString();
            }
            //如果上传成功，则将content_Id返回客户端
            String contentId = uploadJsonObj.getString("contentId");
            JSONObject dataJson = new JSONObject();
            dataJson.put("contentId",contentId);
            dataJson.put("fileName",fileName);
            json.put("success", true);
            json.put("data", dataJson);
            json.put("message", "文件上传成功");
        } catch (Exception e) {
            json.put("success", false);
            json.put("message", "文件上传异常");
            log.error(e.getMessage());
        }
        return json.toJSONString();
    }
    /**
     * 后台富文本上传图片返回文件下载路径
     * @param upload
     * @param CKEditorFuncNum
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/uploadRichFile",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String uploadRichFile(@RequestParam("upload") MultipartFile upload,String CKEditorFuncNum){
        JSONObject json=new JSONObject();
        if(null == upload){
            json.put("success", false);
            json.put("message", "文件上传参数异常");
            return json.toJSONString();
        }
        log.info("进入uploadRichFile--"+CKEditorFuncNum);
        try {
            String fileName = upload.getOriginalFilename();
            String fileType = fileName.substring(fileName.lastIndexOf(".")+1);
            fileType = fileType.toLowerCase();
            boolean b = checkFileType(fileType);
            if(!b){
                json.put("success", false);
                json.put("message", "文件格式异常");
                return json.toJSONString();
            }
            String contentName = "";
            String contentTypeId="";
            String typeCode="rich_img"; //图片类型 富文本图片
            //通过code查询相应配置
            ContentType contentType=this.contentTypeService.selectOneContentType(typeCode,1);
            if(contentType!=null){
                contentName=contentType.getContentTypeName();
                contentTypeId=contentType.getContentTypeId().toString();
            }
            String uploadJson = contentService.saveFileUpload(upload, contentName,contentTypeId);
            JSONObject uploadJsonObj = JSONObject.parseObject(uploadJson);
            Boolean sucFlag = uploadJsonObj.getBoolean("success");
            if(!sucFlag){
                json.put("success", false);
                json.put("message", "文件上传异常");
                return json.toJSONString();
            }
            //如果上传成功，则将下载content_url返回客户端
            String contentId = uploadJsonObj.getString("contentId");
            //下载路径 数据库配置
            //优化StringBuffer构建
            String apiUrl="";
            List<Config> list=this.configService.selectConfigList("api_address",1);
            if(list!=null&&list.size()>0){
                apiUrl=list.get(0).getConfigValue();
            }
            String contentUrl =apiUrl+"/contentController/fileDownloadForRich/"+contentId;
            log.info("返回内容为:"+contentUrl);
            json.put("uploaded",1);
            json.put("fileName",fileName);
            json.put("url",contentUrl);
            json.put("success",true);
        } catch (Exception e) {
            json.put("success", false);
            json.put("message", "文件上传异常");
            log.error(e.getMessage());
        }
        return json.toJSONString();
    }
    /**
     * @Title: checkFileType
     * @Description: 只能是常用视频文件或者压缩文件或者图片文件
     * @param fileType
     * @return    设定文件
     * boolean    返回类型
     * @throws
     * 2018年3月29日下午9:15:29
     * @author yjx
     */
    private boolean checkFileType(String fileType) {
        boolean flag = false;
        if(fileType.equals("zip")||fileType.equals("rar")||fileType.equals("arj")||fileType.equals("gz")){
            flag=true;
        }
        if(fileType.equals("bmp")||fileType.equals("jpeg")||fileType.equals("jpg")||fileType.equals("png")
                ||fileType.equals("tiff")||fileType.equals("jpe")||fileType.equals("jfif")||
                fileType.equals("tif")){
            flag=true;
        }
        if(fileType.equals("3gp")||fileType.equals("rm")||fileType.equals("rmvb")||fileType.equals("mp4")
                ||fileType.equals("mov")||fileType.equals("mpeg")||fileType.equals("mpg")||
                fileType.equals("3gp")||fileType.equals("mtv")||fileType.equals("wmv")||fileType.equals("avi")
                ||fileType.equals("amv")||fileType.equals("dmv")||fileType.equals("dat")){
            flag=true;
        }
        return flag;
    }

    /**
     * 文件下载方法
     * @param contentId
     * @param response
     * @throws IOException
     */
    @ResponseBody
    @RequestMapping(value="/fileDownloadForFrontPlatForm",produces="text/html;charset=utf-8")
    public void fileDownloadForFrontPlatForm(String contentId,HttpServletResponse response) throws IOException {
        Long startTime=System.currentTimeMillis();
        FileInputStream fis = null;
        OutputStream os = null;
        try {
            Content content =contentService.selectByPrimaryKey(contentId);//获取要下载的文件
                if(content!=null){
                    response.setCharacterEncoding("utf-8");// 设置响应的编码
                    response.setContentType("application/octet-stream");
                    //根据扩展名设置返回文件类型
                    //String fileType = content.getFileName().substring(content.getFileName().lastIndexOf(".")+1);
                    //String contentType=getContentType(fileType);
                    //log.info("----contentType:"+contentType);
                    //response.setContentType(contentType);
                    response.setHeader("Content-Disposition",
                            "attachment;filename=" + new String(content.getFileName().getBytes(), "iso-8859-1"));// 设置响应的文件信息
                    response.setHeader("Content-Length", content.getFileSize() + "");// 设置文件大小，用于浏览器显示下载的进度
                    String downLoadPath=content.getContentUrl().substring(0,content.getContentUrl().lastIndexOf("/"));//下载的路径
                    //判断文件是否存在
                    File downFile = new File(downLoadPath);
                    if(!downFile.exists()){
                        throw new ServiceException("未找到您要下载的附件", false);
                    }
                    fis = new FileInputStream(downLoadPath+"/"+content.getFileName());
                    os = response.getOutputStream();
                    int len;
                    byte[] byt = new byte[2048];
                    while ((len = fis.read(byt)) > 0) {
                        os.write(byt,0,len);
                        os.flush();
                    }
                }else{
                    log.error("未找到您要下载的附件");
                    throw new ServiceException("未找到您要下载的附件", false);
                }
        } catch (Exception e) {
            log.error("附件下载异常,原因:"+e.getMessage());
            throw new ServiceException("附件下载异常", e);
        }finally {
            if(os!=null){
                os.close();
            }
            if(fis!=null){
                fis.close();
            }
        }
        log.info("下载完毕，用时："+(System.currentTimeMillis()-startTime));
    }
    /**
     * 文件下载（前台调用pdf专用）
     * @param contentId
     * @param response
     * @throws IOException
     */
    @ResponseBody
    @RequestMapping(value="/fileDownloadForFrontPlatFormPdf",produces="text/html;charset=utf-8")
    public void fileDownloadForFrontPlatFormPdf(String contentId,HttpServletResponse response) throws IOException {
        FileInputStream fis = null;
        OutputStream os = null;
        try {
                Content content = contentService.selectByPrimaryKey(contentId);//获取要下载的文件
                if(content!=null){
                    response.setCharacterEncoding("utf-8");// 设置响应的编码
                    response.setContentType("application/pdf");
                    response.setHeader("Content-Disposition",
                            "attachment;filename=" + new String(content.getFileName().getBytes(), "iso-8859-1"));// 设置响应的文件信息
                    response.setHeader("Content-Length", content.getFileSize() + "");// 设置文件大小，用于浏览器显示下载的进度
                    String downLoadPath=content.getContentUrl().substring(0,content.getContentUrl().lastIndexOf("/"));//下载的路径
                    //判断文件是否存在
                    File downFile = new File(downLoadPath);
                    if(!downFile.exists()){
                        throw new ServiceException("未找到您要下载的附件", false);
                    }
                    fis = new FileInputStream(downLoadPath+"/"+content.getFileName());
                    os = response.getOutputStream();
                    int len;
                    byte[] byt = new byte[(int) downFile.length()];
                    while ((len = fis.read(byt)) > 0) {
                        os.write(byt,0,len);
                        os.flush();
                    }
                }else{
                    log.error("参数为空");
                    throw new ServiceException("未找到您要下载的附件", false);
                }
        } catch (Exception e) {
            log.error("附件下载异常");
            throw new ServiceException("附件下载异常", false);
        }finally {
            if(os!=null){
                os.close();
            }
            if(fis!=null){
                fis.close();
            }
        }
    }
    /**
     * 富文本文件下载方法
     * @param contentId
     * @param response
     * @throws IOException
     */
    @ResponseBody
    @RequestMapping(value="/fileDownloadForRich/{contentId}",produces="text/html;charset=utf-8")
    public void fileDownloadForRich(@PathVariable String contentId,HttpServletResponse response) throws IOException {
        //modify by yjx 添加try catch 以及增加文件存在的判断,优化下载
        FileInputStream fis = null;
        OutputStream os = null;
        try {
            Content content =contentService.selectByPrimaryKey(contentId);//获取要下载的文件
            //下载权限判断
//            if(StringUtils.isNotBlank("aa")){
//                throw new ServiceException("您没有权限下载该附件", false);
//            }else{
            if(content!=null){
                response.setCharacterEncoding("utf-8");// 设置响应的编码
                response.setContentType("application/octet-stream");
                response.setHeader("Content-Disposition",
                        "attachment;filename=" + new String(content.getFileName().getBytes(), "iso-8859-1"));// 设置响应的文件信息
                response.setHeader("Content-Length", content.getFileSize() + "");// 设置文件大小，用于浏览器显示下载的进度
                String downLoadPath=content.getContentUrl().substring(0,content.getContentUrl().lastIndexOf("/"));//下载的路径
                //判断文件是否存在
                File downFile = new File(downLoadPath);
                if(!downFile.exists()){
                    throw new ServiceException("未找到您要下载的附件", false);
                }
                fis = new FileInputStream(downLoadPath+"/"+content.getFileName());
                os = response.getOutputStream();
                int len;
                byte[] byt = new byte[2048];
                while ((len = fis.read(byt)) > 0) {
                    os.write(byt,0,len);
                    os.flush();
                }
            }else{
                log.error("未找到您要下载的附件");
                throw new ServiceException("未找到您要下载的附件", false);
            }
            //}
        } catch (Exception e) {
            log.error("附件下载异常");
            throw new ServiceException("附件下载异常", false);
        }finally {
            if(os!=null){
                os.close();
            }
            if(fis!=null){
                fis.close();
            }
        }

    }
    /**
     * 根据文件类型设置返回类型
     * @param fileType
     * @return
     */
    public String getContentType(String fileType){
       if(fileType.equals("jpg")||fileType.equals("jpeg")||fileType.equals("jpe")){
           return "image/jpeg";
       }else  if(fileType.equals("gif")){
           return "image/gif";
       }else  if(fileType.equals("png")){
           return "image/png";
       }else  if(fileType.equals("bmp")){
           return "application/x-MS-bmp";
       }else  if(fileType.equals("tiff")||fileType.equals("tif")){
           return "image/tiff";
       }else if(fileType.equals("pdf")){
           return "application/pdf";
       }else if(fileType.equals("3gp")||fileType.equals("3gpp")){
           return "video/3gpp";
       }else if(fileType.equals("mp4")){
            return "video/mp4";
        }else if(fileType.equals("mpeg")||fileType.equals("mpg")){
           return "video/mpeg";
       }else if(fileType.equals("avi")){
           return "video/x-msvideo";
       }else if(fileType.equals("rm")||fileType.equals("rmm")||fileType.equals("rmvb")){
           return "audio/x-pn-realaudio";
       }else if(fileType.equals("wmv")){
           return "audio/x-ms-wmv";
       }else{
           return "application/octet-stream";
       }
    }
}
