package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.AreaService;
import cn.comshinetechchina.hyjxyl.service.CityService;
import cn.comshinetechchina.hyjxyl.service.ConfigService;
import cn.comshinetechchina.hyjxyl.service.ProvinceService;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 配置控制层
 * Author:yjx
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/configController")
public class ConfigController extends BaseController {
    @Resource
    private ProvinceService provinceService;
    @Resource
    private AreaService areaService;
    @Resource
    private CityService cityService;
    @Resource
    private ConfigService configService;

    /**
     * 查询配置列表方法
     * @param code 配置项code
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/selectConfigList",method= RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public String selectConfigList(String code){
     JSONObject json=new JSONObject();
     JSONObject data=new JSONObject();
     List<Config> list=new ArrayList<Config>();
     if(StringUtils.isNotBlank(code)){
         //通过code查询有效配置
         list=this.configService.selectConfigList(code,1);
     }
        data.put("configList",list);
        json.put("data",data);
        json.put("success",true);
        json.put("message","查询成功");
        return json.toJSONString();
    }

    /**
     * 返回省市区json
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/queryPcaTree",method= RequestMethod.POST,produces = "application/json;charset=UTF-8")
    public String queryPcaTree(){
        JSONObject json=new JSONObject();
        JSONObject data=new JSONObject();
        long time1=System.currentTimeMillis();
        SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        System.out.println("开始时间为"+dateformat.format(System.currentTimeMillis()));
        List<Province> list=this.provinceService.selectProvinceList();
        List<PcaObj> lista=new ArrayList<PcaObj>();
        List<PcaObj2> list2=null;
        List<City> list1=null;
        PcaObj o1=null;
        for(Province p:list){
            list1 =this.cityService.selectCityList(String.valueOf(p.getProvinceId()));
            List<PcaObj1> list3=new ArrayList<PcaObj1>();
            PcaObj1 o2=null;
            for(City c:list1){
                list2= this.areaService.selectPcaObj2List(String.valueOf(c.getCityId()));
                o2=new PcaObj1();
                o2.setValue(c.getCityId().toString());
                o2.setLabel(c.getName());
                o2.setChildren(list2);
                list3.add(o2);
            }
            o1=new PcaObj();
            o1.setValue(p.getProvinceId().toString());
            o1.setChildren(list3);
            o1.setLabel(p.getName());
            lista.add(o1);
        }
        Long time2=System.currentTimeMillis();
        System.out.println("遍历构建省市区tree耗时："+(time2-time1));
        data.put("pcaJson",lista);
        json.put("data",data);
        json.put("success",true);
        json.put("message","查询成功");
        System.out.println("结束时间为"+dateformat.format(System.currentTimeMillis()));
        return json.toJSONString();
    }
}
