package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.Column;
import cn.comshinetechchina.hyjxyl.service.ColumnService;
import cn.comshinetechchina.hyjxyl.service.CommentService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/columnController")
public class ColumnController extends BaseController{
    @Resource
    private ColumnService columnService;

    /**
     * 分类查询类别列表
     * @param type 分类 1 资讯 2 居家服务
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryColumnList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String  queryColumnList(Integer type){
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        Map<String,String> map=new HashMap<String,String>();
        map.put("available","1");
        map.put("type",String.valueOf(type));
        List<Column> list=new ArrayList<Column>();
        try {
            list = this.columnService.queryColumnList(map);
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list",list);
        json.put("data", dataJson);
        json.put("success", true);
        json.put("message", "查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
