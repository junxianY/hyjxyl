package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.domain.Content;
import cn.comshinetechchina.hyjxyl.domain.MemberObj;
import cn.comshinetechchina.hyjxyl.service.ContentService;
import cn.comshinetechchina.hyjxyl.service.DeviceDataService;
import cn.comshinetechchina.hyjxyl.service.MembersService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 设备体检接口
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/sh05")
public class DeviceTestController {
    private static final Logger log = LoggerFactory.getLogger(DeviceTestController.class);
    @Resource
    private MembersService membersService;
    @Resource
    private ContentService contentService;
    @Resource
    private DeviceDataService deviceDataService;
    @Value("${downLoadUrl}")
    private String downLoadUrl;
    /**
     * 获取用户信息 卡号体检接口
     * @param requestJson
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/getUserByIdcard", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String getUserByIdcard(@RequestBody String requestJson){
        log.info("into getUserByIdcard---requestJson:"+requestJson);
        JSONObject json=new JSONObject();
        if(StringUtils.isBlank(requestJson)){
            json.put("code",2);
            json.put("msg","参数为空");
            json.put("data","");
        }
        JSONObject para=JSONObject.parseObject(requestJson);
        String cardNo="";
        //idcard传的卡号
        if(para!=null&&para.get("idcard")!=null){
            cardNo=para.get("idcard").toString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardNo",cardNo);
        MemberObj obj=this.membersService.getMemberByPara(map);
        if(obj!=null){
            //查询用户头像
            List<Content> list1 = contentService.selectContentsById(obj.getMemberId(), "tbl_members", "1001");
            if (list1 != null && list1.size() > 0) {
                String contentId = list1.get(0).getContentId();
                String url=downLoadUrl+contentId;
                obj.setPhotoPath(url);
            }
            obj.setIdcard(cardNo); //需要返回卡号
            json.put("code",2);
            json.put("msg","查询成功");
            json.put("data",obj);
        }else{
            json.put("code",1);
            json.put("msg","卡号不存在");
            json.put("data","");
        }
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * 新接收数据接口
     * @param requestData
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/uploadData", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String uploadData(@RequestBody String requestData){
        JSONObject json=new JSONObject();
        if(StringUtils.isBlank(requestData)){
            json.put("code",2);
            json.put("msg","数据不能为空");
            return json.toJSONString();
        }
        log.info("接收数据成功:"+requestData);
        return deviceDataService.receiveDataNew(requestData);
    }
}
