package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.*;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 活动资讯控制层
 * Author:yjx
 */
@RestController
@RequestMapping("/articleController")
public class ArticleController extends BaseController {
    private Logger log= LoggerFactory.getLogger(ArticleController.class);
    @Resource
    private ArticleService articleService;
    @Resource
    private ContentService contentService;
    @Resource
    private ColumnService columnService;
    @Resource
    private ContentRefService contentRefService;
    @Resource
    private CommentService commentService;
    @Resource
    private FavourRecordService favourRecordService;
    @Resource
    private PointsDetailService pointsDetailService;
    @Resource
    private PointService pointService;

    /**
     * 查询活动资讯列表
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryArticleList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String  queryArticleList(HttpServletRequest request){
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();

        Map<String, Object> map = new HashMap<String, Object>();
        String tenantId = request.getParameter("tenantId");
        // 新增 05  查询的是所有线下服务
        String typeId = request.getParameter("typeId");
        String columnId = request.getParameter("columnId");
        String startTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");
        String title = request.getParameter("title");
        map.put("tenantId", tenantId);
        map.put("columnId", columnId);
        map.put("typeId", typeId);
        map.put("startTime", startTime);
        map.put("endTime", endTime);
        map.put("title", title);
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        List<ArticleObj> list = new ArrayList<ArticleObj>();
        int totalCount = 0;
        try {
            list = this.articleService.selectArticleList(map, bean);
            totalCount = bean.getTotalRows();
            //循环查询其首图附件 01资讯 02活动 03社区养老 04居家养老
            if(list!=null&&list.size()>0){
                String contentType="";
                List<Content> contentList=null;
                for(ArticleObj obj:list){
                    if("01".equals(obj.getTypeId())){
                        contentType="1004";
                    }else if("02".equals(obj.getTypeId())){
                        contentType="1003";
                    }else if("03".equals(obj.getTypeId())){
                        contentType="1005";
                    }else if("04".equals(obj.getTypeId())){
                        contentType="1006";
                    }
                    contentList=contentService.selectContentsById(obj.getArticleId(),"tbl_articles",contentType);
                    if(contentList!=null&&contentList.size()>0){
                        obj.setContentId(contentList.get(0).getContentId());
                    }
                }
            }
        } catch (Exception ex) {
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("totalCount", totalCount);
        dataJson.put("list", list);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        json.put("data", dataJson);
        json.put("success", true);
        json.put("message", "查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 增加活动资讯线下服务接口
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addArticle", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String  addArticle(Article info,HttpServletRequest request){
        JSONObject json = new JSONObject();
        log.info("------addArticle-------");
        if(null==info){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        //验证当前类型序号是否存在 typeId  类型：01咨讯 02活动03社区养老 04居家养老
        if(info.getOrderNo()!=null){
         Map map=this.articleService.selectOneByOrderNo(info);
         if(map!=null){
             json.put("success",false);
             json.put("message","该序号已经存在");
             return json.toJSONString();
         }
        }
        String uid=UUID.randomUUID().toString();
        info.setArticleId(uid);
        info.setCreatedDate(new Date());
        info.setAvailable(1);
        //初始化参数
        info.setFavour(0);
        info.setArticlescol(0);
        info.setCommentCount(0);
        try {
            int i=this.articleService.insertSelective(info);
            if(i>0){
                //附件信息
                String contentIDs=request.getParameter("contentIDs");
                log.info("------------contentIDs:"+contentIDs);
                List<ContentRef> newList=new ArrayList<ContentRef>();
                if(StringUtils.isNotBlank(contentIDs)){
                    String[] contentIds=null;
                    if(contentIDs.indexOf(",")!=-1){
                        contentIds=contentIDs.split(",");
                    }else{
                        contentIds=new String[1];
                        contentIds[0]=contentIDs;
                    }
                    ContentRef ref=null;
                    for(String ss:contentIds){
                        ref=new ContentRef();
                        ref.setContentId(ss);
                        ref.setContentRefId(UUID.randomUUID().toString());
                        ref.setCreateTime(new Date());
                        ref.setExternalId(uid);
                        ref.setContentRefType("tbl_articles");
                        ref.setContentRefCode("article_id");
                        newList.add(ref);
                    }
                }
                int t=this.contentRefService.batchInsertContentRef(newList);
                log.info("活动资讯："+uid+"插入附件"+t+"条");
                json.put("articleId", uid);
                json.put("success", true);
                json.put("message", "操作成功");
            }else{
                json.put("articleId", "");
                json.put("success", false);
                json.put("message", "操作失败");
            }
        }catch(Exception ex){
            throw new ServiceException("插入异常",ex);
        }
        return json.toJSONString();
    }
    /**
     * 修改活动资讯接口
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateArticle", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String  updateArticle(Article info,HttpServletRequest request){
        JSONObject json = new JSONObject();
        if(null==info||null==info.getArticleId()){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        //验证当前类型序号是否存在 typeId  类型：01咨讯 02活动03社区养老 04居家养老
        Article oldInfo=this.articleService.selectByPrimaryKey(info.getArticleId());
        if(null==oldInfo){
            json.put("success",false);
            json.put("message","对应主键id不存在");
            return json.toJSONString();
        }
        if(oldInfo!=null&&info.getOrderNo()!=null&&info.getOrderNo()!=-1){
            oldInfo.setOrderNo(info.getOrderNo());
            Map map=this.articleService.selectOneByOrderNo(oldInfo);
            if(map!=null&&map.get("article_id")!=null&&!map.get("article_id").toString().equals(info.getArticleId())){
                json.put("success",false);
                json.put("message","该序号已经存在");
                return json.toJSONString();
            }
        }

        info.setLastUpdatedDate(new Date());
        try {
            int i=this.articleService.updateByPrimaryKeySelective(info);
            if(i>0){
                //附件信息
                String contentIDs=request.getParameter("contentIDs");
                log.info("------------contentIDs:"+contentIDs);
                List<ContentRef> newList=new ArrayList<ContentRef>();
                if(StringUtils.isNotBlank(contentIDs)){
                    String[] contentIds=null;
                    if(contentIDs.indexOf(",")!=-1){
                        contentIds=contentIDs.split(",");
                    }else{
                        contentIds=new String[1];
                        contentIds[0]=contentIDs;
                    }
                    ContentRef ref=null;
                    for(String ss:contentIds){
                        ref=new ContentRef();
                        ref.setContentId(ss);
                        ref.setContentRefId(UUID.randomUUID().toString());
                        ref.setCreateTime(new Date());
                        ref.setExternalId(info.getArticleId());
                        ref.setContentRefType("tbl_articles");
                        ref.setContentRefCode("article_id");
                        newList.add(ref);
                    }
                }
                if(!newList.isEmpty()){
                    int t=this.contentRefService.batchInsertContentRef(newList);
                    log.info("活动资讯："+info.getArticleId()+"插入附件"+t+"条");
                }
                json.put("success", true);
                json.put("message", "操作成功");
            }else{
                json.put("success", false);
                json.put("message", "操作失败");
            }
        }catch(Exception ex){
            throw new ServiceException("更新异常",ex);
        }
        return json.toJSONString();
    }
    /**
     * 删除活动咨讯方法
     * @param articleId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/delArticle", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String  delArticle(String articleId){
        JSONObject json = new JSONObject();
        if(StringUtils.isBlank(articleId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
         try {
            int i=this.articleService.deleteByPrimaryKey(articleId);
            if(i>0){
                json.put("success", true);
                json.put("message", "操作成功");
            }else{
                json.put("success", false);
                json.put("message", "操作失败");
            }
        }catch(Exception ex){
            throw new ServiceException("删除异常",ex);
        }
        return json.toJSONString();
    }
    /**
     * 查询活动资讯明细方法
     * @param articleId
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryArticleDetail", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String queryArticleDetail(String articleId,HttpServletRequest request){
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if(StringUtils.isBlank(articleId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        String token = request.getHeader("token");
        //1 app 2 后台
        String type=request.getParameter("type")==null?"2":request.getParameter("type");
        Article info=null;
        List<Content> contentList=new ArrayList<Content>();
        List<Comment> commentList=new ArrayList<Comment>();
        ArticleObj data=new ArticleObj();
        //是否点赞 0未点赞 默认 1已点赞
        int isFavour=0;
        try {
            info = this.articleService.selectByPrimaryKey(articleId);

            List<String> articleIds=new ArrayList<String>();
            articleIds.add(articleId);
            //app的话更新相应活动浏览量
            if(!articleIds.isEmpty()&&"1".equals(type)){
                int i=this.articleService.updateArticleArticleScol(articleIds);
                log.info("更新了"+i+"条相应活动浏览量");
            }
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            if (info != null) {
                BeanUtils.copyProperties(info, data);
                if (info.getCreatedDate() != null) {
                    data.setCreatedDate(sdf.format(info.getCreatedDate()));
                }
                if (info.getActivityStartTime() != null) {
                    data.setActivityStartTime(sdf.format(info.getActivityStartTime()));
                }
                if (info.getActivityEndTime() != null) {
                    data.setActivityEndTime(sdf.format(info.getActivityEndTime()));
                }
                if (info.getLastUpdatedDate() != null) {
                    data.setLastUpdatedDate(sdf.format(info.getLastUpdatedDate()));
                }
                if (StringUtils.isNotBlank(info.getColumnId())) {
                    Column cc = columnService.selectByPrimaryKey(Integer.parseInt(info.getColumnId()));
                    if (cc != null) {
                        data.setColumnName(cc.getColumnName());
                    }
                }
            //查询其所有附件信息 01资讯 02活动 03社区养老 04居家养老
            String contentType = "";
            if ("01".equals(info.getTypeId())) {
                contentType = "1004";
            } else if ("02".equals(info.getTypeId())) {
                contentType = "1003";
            }else if ("03".equals(info.getTypeId())) {
                contentType = "1005";
            }else if ("04".equals(info.getTypeId())) {
                contentType = "1006";
            }
            contentList = contentService.selectContentsById(info.getArticleId(), "tbl_articles", contentType);
            log.info("---------");
            //查询其评论信息
            Map<String, Object> para = new HashMap<String, Object>();
            para.put("refType", "tbl_articles");
            para.put("refId", articleId);
            para.put("available", 1);
            commentList = commentService.selectCommentList(para);
            if(commentList!=null&&commentList.size()>0){
                //循环遍历 拿取头像
               for(Comment com:commentList){
                   if(StringUtils.isNotBlank(com.getCreateBy())){
                     List<Content> list=this.contentService.selectContentsById(com.getCreateBy(),"tbl_members","1001");
                     if(list!=null&&list.size()>0){
                         com.setContentId(list.get(0).getContentId());
                     }
                   }
              }
            }
          //查询其点赞情况
          Map<String, Object> map = JwtUtil.parseAppToken(token);
          String memberId = map.get("memberId") == null ? "" : map.get("memberId").toString();
          log.info("当前app登录人id:" + memberId);
          FavourRecord record=favourRecordService.selectOneFavourRecord(articleId,"tbl_articles",memberId);
          if(record!=null){
              int type1=record.getType();
              if(type1==1){
                  isFavour=1;
              }
          }
        }
            //app查看活动资讯明细操作成功 计入积分 每天最多5次 add 20180829
            if("1".equals(type)&&("01".equals(info.getTypeId())||"02".equals(info.getTypeId()))){
                String memberId="";
                try {
                    //如果token有效 查询出其对应的memberId返回
                    Map<String, Object> map = JwtUtil.parseManagementToken(token);
                    memberId = map.get("uid") == null ? "" : map.get("uid").toString();
                    log.info("当前app登录人memberId:" + memberId);
                }catch(Exception ex){
                    throw new ServiceException("token解析失败",ex);
                }
                if(StringUtils.isNotBlank(memberId)){
                    Map<String,Object> map=new HashMap<String,Object>();
                    map.put("memberId",memberId);
                    map.put("type",4);
                    map.put("createDate", DateUtil.transferDate2Str(new Date(),"yyyy-MM-dd"));
                    List<PointsDetail> list=this.pointsDetailService.selectPointsDetailList(map);
                    if(list!=null&&list.size()<5){
                        //判断是否看过该篇文章
                        boolean isRead=false;
                        for(PointsDetail detail:list){
                            if(articleId.equals(detail.getArticleId())){
                                isRead=true;
                            }
                        }
                        if(!isRead){
                            this.pointService.savePointInfo(memberId,4,0,articleId);
                        }
                    }
                }
            }
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("info",data);
        dataJson.put("contentList",contentList);
        dataJson.put("commentList",commentList);
        dataJson.put("isFavour",isFavour);
        json.put("data",dataJson);
        json.put("success",true);
        json.put("message","查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 查询banner图片文章
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryBannerArticles", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryBannerArticles(){
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        List<ArticleObj> list=new ArrayList<ArticleObj>();
        try {
            list = this.articleService.selectRandom5Articles();
            if (list != null && list.size() > 0) {
                String contentType = "";
                List<Content> contentList = null;
                for (ArticleObj obj : list) {
                    if ("01".equals(obj.getTypeId())) {
                        contentType = "1004";
                    } else if ("02".equals(obj.getTypeId())) {
                        contentType = "1003";
                    } else if ("03".equals(obj.getTypeId())) {
                        contentType = "1005";
                    } else if ("04".equals(obj.getTypeId())) {
                        contentType = "1006";
                    }
                    contentList = contentService.selectContentsById(obj.getArticleId(), "tbl_articles", contentType);
                    if (contentList != null && contentList.size() > 0) {
                        obj.setContentId(contentList.get(0).getContentId());
                    }
                }
            }
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list",list);
        json.put("data",dataJson);
        json.put("success",true);
        json.put("message","查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
