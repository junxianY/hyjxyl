package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.domain.ServiceStatistics;
import cn.comshinetechchina.hyjxyl.domain.StatisticsArticle;
import cn.comshinetechchina.hyjxyl.service.ScreenService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 大屏报表控制层
 * Author:yjx
 */
@RestController
@RequestMapping("/screenController")
public class ScreenController extends BaseController {
    private static final Logger log= LoggerFactory.getLogger(ScreenController.class);
    @Resource
    private ScreenService screenService;

    /**
     * 根据年龄统计
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/statisticsMembersByAge",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String statisticsMembersByAge(HttpServletRequest request){
      log.info("---statisticsMembersByAge--");
      return screenService.statisticsMembersByAge();
    }

    /**
     * 根据文化程度统计
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/statisticsMembersByEducation",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String statisticsMembersByEducation(HttpServletRequest request){
        log.info("---statisticsMembersByEducation--");
        return screenService.statisticsMembersByEducation();
    }

    /**
     * 根据居住类型统计
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/statisticsByLiveCategory",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String statisticsByLiveCategory(HttpServletRequest request){
        log.info("---statisticsMembersByEducation--");
        return screenService.statisticsByLiveCategory();
    }

    /**
     * 服务总次数统计
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/statisticsByServices",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String statisticsByServices(HttpServletRequest request){
        log.info("---statisticsByServices--");
       // return screenService.statisticsByService();
        String startDate=request.getParameter("startDate");
        String endDate=request.getParameter("endDate");
        //都为空的话 默认最近一周
        if(StringUtils.isBlank(startDate)&&StringUtils.isBlank(endDate)){
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
            startDate=sdf.format(DateUtil.getSysDate(0,0,-6));
            endDate=sdf.format(new Date());
        }
        return screenService.statisticMemberService(startDate,endDate);
    }

    /**
     * 用户数统计
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/statisticsByMembers",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String statisticsByMembers(HttpServletRequest request){
        log.info("---statisticsByMembers--");
        JSONObject json=new JSONObject();
        JSONObject data=new JSONObject();
        //当天
        int count1=this.screenService.countMembers(1);
        //近30天
        int count2=this.screenService.countMembers(3);
        //总数
        int count3=this.screenService.countMembers(100);
        data.put("totalCount",count3);
        data.put("dayCount",count1);
        data.put("monthCount",count2);
        json.put("data",data);
        json.put("success",true);
        json.put("message","查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 根据疾病统计
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/statisticsByDisease",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String statisticsByDisease(HttpServletRequest request){
        String sex=request.getParameter("sex");
        log.info("---statisticsByDisease--sex:"+sex);
        if(StringUtils.isBlank(sex)){
            sex="-1";
        }
        return this.screenService.statisticsByDisease(Integer.parseInt(sex));
    }

    /**
     * 服务类型排名
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/statisticsByServiceName",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String statisticsByServiceName(HttpServletRequest request){
        JSONObject json=new JSONObject();
        JSONObject data=new JSONObject();
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("type","1");
        List<ServiceStatistics> list=this.screenService.statisticsMembersByServiceName(map);
        data.put("list",list);
        json.put("data",data);
        json.put("success",true);
        json.put("message","查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * 仪器使用记录
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/statisticsCardUseRecord",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String statisticsCardUseRecord(HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject data = new JSONObject();
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("type",1);
        List<ServiceStatistics> list=this.screenService.statisticsCardUseRecord(map);
        data.put("list",list);
        json.put("data",data);
        json.put("success",true);
        json.put("message","查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 活动资讯浏览数  随机6条
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/statisticsArticles",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String statisticsArticles(HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject data = new JSONObject();
        List<StatisticsArticle> list=this.screenService.statisticsArticles(null);
        data.put("list",list);
        json.put("data",data);
        json.put("success",true);
        json.put("message","查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 健康监测数据
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/statisticsHealthMonitorData",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String statisticsHealthMonitorData(HttpServletRequest request){
        log.info("---statisticsMembersByEducation--");
        return screenService.statisticsHealthMonitorData();
    }

}
