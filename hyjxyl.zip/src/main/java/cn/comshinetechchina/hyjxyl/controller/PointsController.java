package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.KithAndKin;
import cn.comshinetechchina.hyjxyl.domain.Point;
import cn.comshinetechchina.hyjxyl.domain.PointsDetail;
import cn.comshinetechchina.hyjxyl.domain.Province;
import cn.comshinetechchina.hyjxyl.service.PointService;
import cn.comshinetechchina.hyjxyl.service.PointsDetailService;
import cn.comshinetechchina.hyjxyl.service.ProvinceService;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/pointsController")
public class PointsController extends BaseController {
    @Resource
    private PointService pointService;
    @Resource
    private PointsDetailService pointsDetailService;
    private static final Logger log = LoggerFactory.getLogger(PointsController.class);

    /**
     * 查询积分中心数据信息
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryPointsCenterInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryPointsCenterInfo(HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        String token = request.getHeader("token");
        String currentMemberId = "";
        try {
            Map<String, Object> map = JwtUtil.parseManagementToken(token);
            currentMemberId = map.get("uid") == null ? "" : map.get("uid").toString();
            log.info("当前登录人memberId:" + currentMemberId);
        } catch (Exception ex) {
            throw new ServiceException("token解析失败", ex);
        }
        if(StringUtils.isNotBlank(currentMemberId)){
            try {
                PageBean bean=new PageBean();
                //当前页码
                String pageIndex=request.getParameter("pageIndex")==null?"0":request.getParameter("pageIndex");
                //每页数量
                String pageSize=request.getParameter("pageSize")==null?"10":request.getParameter("pageSize");
                if(StringUtils.isNotBlank(pageSize)){
                    bean.setPageSize(Integer.parseInt(pageSize));
                }
                if (StringUtils.isNotBlank(pageIndex)) {
                    bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
                }
                //查询个人总积分
                Point point=this.pointService.selectByPrimaryKey(currentMemberId);
                //查询个人积分明细
                Map<String,Object> map=new HashMap<String,Object>();
                int totalPoint=0;
                if(point!=null){
                    totalPoint=point.getPoint();
                }
                map.put("memberId",currentMemberId);
                List<PointsDetail> list=this.pointsDetailService.selectPointsDetailListByPage(map,bean);
                dataJson.put("detailList",list);
                dataJson.put("totalPoint",totalPoint);
                dataJson.put("totalCount",bean.getTotalRows());
                json.put("success", true);
                json.put("message", "查询成功");
                json.put("data",dataJson);
            } catch (Exception ex) {
                throw new ServiceException("查询异常",ex);
            }
        }else{
            json.put("success",false);
            json.put("message","客户id为空");
        }
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
