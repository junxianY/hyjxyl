package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.service.ArticleService;
import cn.comshinetechchina.hyjxyl.service.CommentService;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Map;

@RestController
@RequestMapping("/favourController")
public class FavourController extends BaseController {
    private Logger log= LoggerFactory.getLogger(FavourController.class);
    @Resource
    private CommentService commentService;
    @Resource
    private ArticleService articleService;
    /**
     * 点赞方法
     * @param request
     * @param primaryId 对象id
     * @param type    区分对应对象
     * @param operate 操作类型 1点赞 2取消赞
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/commonUpdateFavour", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String commonUpdateFavour(HttpServletRequest request,String primaryId,Integer type,Integer operate) {
        JSONObject json = new JSONObject();
        if (StringUtils.isBlank(primaryId) ||null==type||null==operate) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        String token = request.getHeader("token");
        try {
            Map<String, Object> map = JwtUtil.parseAppToken(token);
            String memberId = map.get("memberId") == null ? "" : map.get("memberId").toString();
            log.info("当前app登录人id:" + memberId);
            int i = 0;
            if (type==1) {
                //1.资讯、活动 点赞
                i = articleService.updateArticleFavor(primaryId, memberId,operate);
            } else if (type==2) {
                //2.评论点赞
                i = commentService.updateCommentFavour(primaryId, memberId,operate);
            }
            if (i > 0) {
                json.put("success", true);
                json.put("message", "操作成功");
            } else {
                json.put("success", false);
                json.put("message", "操作失败");
            }
        }catch(Exception ex){
            throw new ServiceException("更新失败",ex);
        }
        return json.toJSONString();
    }
}
