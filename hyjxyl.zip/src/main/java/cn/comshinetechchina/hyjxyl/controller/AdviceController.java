package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.Advice;
import cn.comshinetechchina.hyjxyl.domain.AdviceObj;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecordCountObj;
import cn.comshinetechchina.hyjxyl.service.AdviceService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.*;

/**
 * 意见反馈控制层
 */
@RestController
@RequestMapping("/adviceController")
public class AdviceController extends BaseController {
    private Logger log= LoggerFactory.getLogger(AdviceController.class);
    @Resource
    private AdviceService adviceService;

    /**
     * 插入建议方法
     * @param info
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addAdviceInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addAdviceInfo(Advice info, HttpServletRequest request){
      JSONObject json=new JSONObject();
      if(null==info|| StringUtils.isBlank(info.getContent())){
          json.put("success",false);
          json.put("message","参数不能为空");
          return json.toJSONString();
      }
        String uId= UUID.randomUUID().toString();
        info.setAdviceId(uId);
        info.setCreateTime(new Date());
        String token = request.getHeader("token");
        String memberId="";
        try {
            Map<String, Object> map = JwtUtil.parseAppToken(token);
            memberId = map.get("memberId") == null ? "" : map.get("memberId").toString();
            log.info("当前app登录人id:" + memberId);

        }catch(Exception ex){
            throw new ServiceException("token解析异常",ex);
        }
        info.setCreateBy(memberId);
        int i=this.adviceService.insertSelective(info);
        if(i>0){
            json.put("success",true);
            json.put("message","增加成功");
            json.put("adviceId",uId);
        }else{
            json.put("success",false);
            json.put("message","增加失败");
            json.put("adviceId","");
        }

      return json.toJSONString();
    }

    /**
     * 查询意见建议列表信息
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryAdviceList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryAdviceList(HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        //开始日期
        String startDate=request.getParameter("startDate");
        //结束日期
        String endDate=request.getParameter("endDate");
        log.info("---startDate:"+startDate+"--endDate:"+endDate);
        List<AdviceObj> list=new ArrayList<AdviceObj>();
        int totalCount=0;
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        Map<String,String> map=new HashMap<String,String>();
        map.put("startDate",startDate);
        map.put("endDate",endDate);
        try {
            list = this.adviceService.selectAdviceList(bean, map);
            totalCount = bean.getTotalRows();
            json.put("success",true);
            json.put("message","查询成功");
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("totalCount", totalCount);
        dataJson.put("list", list);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 删除接口
     * @param adviceId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/delAdvice", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String delAdvice(String adviceId){
        JSONObject json = new JSONObject();
        if(StringUtils.isBlank(adviceId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        int i=this.adviceService.deleteByPrimaryKey(adviceId);
        if(i>0){
            json.put("success",true);
            json.put("message","操作成功");
        }else{
            json.put("success",false);
            json.put("message","操作失败");
        }
        return json.toJSONString();
    }
}
