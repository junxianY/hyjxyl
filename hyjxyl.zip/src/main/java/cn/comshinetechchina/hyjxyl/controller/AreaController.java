package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.Area;
import cn.comshinetechchina.hyjxyl.service.AreaService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/areaController")
public class AreaController extends BaseController {
    @Resource
    private AreaService areaService;
    @ResponseBody
    @RequestMapping(value = "/queryAreaList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryAreaList(String cityId) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if (null == cityId) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        List<Area> list = new ArrayList<Area>();
        try {
            list =this.areaService.selectAreaList(cityId);
        } catch (Exception ex) {
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list", list);
        json.put("success", true);
        json.put("message", "查询成功");
        json.put("data", dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
