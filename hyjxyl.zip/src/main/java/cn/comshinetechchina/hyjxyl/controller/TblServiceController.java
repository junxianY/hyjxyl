package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.TblService;
import cn.comshinetechchina.hyjxyl.service.TblServiceService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * 服务控制层
 * Author:yjx
 */
@RestController
@RequestMapping("/tblServiceController")
public class TblServiceController extends BaseController {
    private static final Logger log = LoggerFactory.getLogger(TblServiceController.class);
    @Resource
    private TblServiceService tblServiceService;

    /**
     * 增加服务方法
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addServiceInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addServiceInfo(TblService info) {
        JSONObject json = new JSONObject();
        if (null == info||null==info.getName()) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //服务名称重复
        Map<String,String> map=new HashMap<String,String>();
        map.put("name",info.getName());
        List<TblService> list=this.tblServiceService.queryServiceList(map);
        if(list!=null&&list.size()>0){
            json.put("success",false);
            json.put("message","服务名称已经存在");
            return json.toJSONString();
        }
        String uId= UUID.randomUUID().toString();
        info.setServiceId(uId);
        info.setAvailable(1);
        info.setCreatedDate(new Date());
        int i=this.tblServiceService.insertSelective(info);
        if (i > 0) {
            json.put("success", true);
            json.put("message", "成功");
            json.put("serviceId",uId);
        } else {
            json.put("success", false);
            json.put("message", "插入数据失败");
            json.put("serviceId","");
        }
        return json.toJSONString();
    }

    /**
     * 查询服务列表
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryServiceList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryServiceList(HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        //服务名称
        String name=request.getParameter("name");
        String type=request.getParameter("type");
        Map<String,String> map=new HashMap<String,String>();
        //map.put("available","1");
        map.put("name",name);
        map.put("type",type);
        List<TblService> list=new ArrayList<TblService>();
        try {
            list = this.tblServiceService.queryServiceList(map);
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list",list);
        json.put("data",dataJson);
        json.put("success",true);
        json.put("message","成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 删除服务接口
     * @param serviceId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/delService", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String delService(String serviceId){
        JSONObject json = new JSONObject();
        if(StringUtils.isBlank(serviceId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        int i=this.tblServiceService.deleteByPrimaryKey(serviceId);
        if(i>0){
            json.put("success",true);
            json.put("message","删除成功");
        }else{
            json.put("success",false);
            json.put("message","删除失败");
        }
        return json.toJSONString();
    }
    /**
     * 修改服务方法
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateServiceInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String updateServiceInfo(TblService info) {
        log.info("进入updateServiceInfo方法啊");
        JSONObject json = new JSONObject();
        if (null == info ||StringUtils.isBlank(info.getServiceId())) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //若名称改变验证服务名称重复
        TblService oldInfo=this.tblServiceService.selectByPrimaryKey(info.getServiceId());
        if(!oldInfo.getName().equals(info.getName())){
            Map<String,String> map=new HashMap<String,String>();
            map.put("name",info.getName());
            List<TblService> list=this.tblServiceService.queryServiceList(map);
            if(list!=null&&list.size()>0){
                json.put("success",false);
                json.put("message","服务名称已经存在");
                return json.toJSONString();
            }
        }
        info.setUpdatedDate(new Date());
        int i = this.tblServiceService.updateByPrimaryKeySelective(info);
        if (i > 0) {
            json.put("success", true);
            json.put("message", "成功");
        } else {
            json.put("success", false);
            json.put("message", "更新失败");
        }
        return json.toJSONString();
    }
}
