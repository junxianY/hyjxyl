package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.domain.PushMember;
import cn.comshinetechchina.hyjxyl.domain.PushMessage;
import cn.comshinetechchina.hyjxyl.domain.PushMessageObj;
import cn.comshinetechchina.hyjxyl.service.CardLeftNumberHistoryService;
import cn.comshinetechchina.hyjxyl.service.CardLeftNumberService;
import cn.comshinetechchina.hyjxyl.service.PushMemberService;
import cn.comshinetechchina.hyjxyl.service.PushMessageService;
import cn.comshinetechchina.hyjxyl.util.AppPush;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

/**
 * 定时跑批类
 */
@Configuration
@EnableScheduling
public class ScheduleJobs {
    private static final Logger log = LoggerFactory.getLogger(ScheduleJobs.class);
    @Resource
    private CardLeftNumberService cardLeftNumberService;
    @Resource
    private CardLeftNumberHistoryService cardLeftNumberHistoryService;
    @Resource
    private PushMessageService pushMessageService;
    @Resource
    private PushMemberService pushMemberService;

    //每天凌晨0点跑批，将过期的卡剩余次数表记录跑批进历史表
    @Scheduled(cron = "0 0 0 * * ?")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public void cardLeftNumberMoveTask() {
        log.info("跑批cardLeftNumberMoveTask: " + LocalDateTime.now());
        Date d1=new Date();
        //批量插入卡剩余记录历史表
        int i=this.cardLeftNumberHistoryService.batchInsertRecordByTask(d1);
        int t=this.cardLeftNumberService.delRecordByTask(d1);

        if(i>0&&t>0){
          log.info("----卡剩余次数记录跑入历史表成功"+i+"条");
        }else{
          log.info("----沒有符合的卡剩余次数记录需要跑批");
        }
        log.info("----跑批结束"+LocalDateTime.now());
    }

    /**
     * 每分钟跑批消息推送
     */
    @Scheduled(cron = "0 */1 * * * ?")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public void autoPushMessage() {
        Long currTime=new Date().getTime();
        log.info("跑批autoPushMessage: " + LocalDateTime.now());
        //1.从pushMessage表查询出当前分钟未发送的消息
        PageBean bean=new PageBean();
        bean.setRowStart(0);
        bean.setPageSize(10);
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("available","1");
        map.put("status","0");
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm");
        map.put("pushTime",sdf.format(new Date()));
        List<PushMessageObj> list=pushMessageService.selectPushMessageList(bean,map);
        //2.发送消息
        int sendOkCount=0;
        List<String> idList=new ArrayList<String>();
        //查询出开启推送的用户
        Map<String,Object> para=new HashMap<String,Object>();
        para.put("available","1");
        List<PushMember> userList=pushMemberService.selectPushMembersList(para);

        if(list!=null&&list.size()>0&&userList!=null){
            for(PushMessageObj obj:list){
                String ss= AppPush.pushMessage(obj.getTitle(),obj.getMessage(),userList);
                if(StringUtils.isNotBlank(ss)&&ss.indexOf("result=ok")!=-1){
                    log.info("推送消息成功,消息标题："+obj.getTitle());
                    sendOkCount++;
                    idList.add(obj.getId());
                }else{
                    log.info("推送失败,消息标题："+obj.getTitle()+"----原因："+ss);
                }
            }
        }
        //3.将成功的消息状态更新为已发送
         if(sendOkCount>=0&&!idList.isEmpty()){
                int i=this.pushMessageService.batchUpdateMessageStatus(idList);
                log.info("更新了"+i+"条推送消息的状态");
         }
        log.info("----跑批结束，成功条数为："+sendOkCount+"-----耗时"+(new Date().getTime()-currTime));
    }
}
