package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.*;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * 亲友关系控制层
 * createTime:2018.03.29
 * author:yjx
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/kithAndKinController")
public class KithAndKinController extends BaseController {
    private static final Logger log= LoggerFactory.getLogger(KithAndKinController.class);
    @Resource
    private KithAndKinService kithAndKinService;
    @Resource
    private ContentService contentService;
    @Resource
    private MessageService messageService;
    @Resource
    private MemberExtendService memberExtendService;
    @Resource
    private PushMessageService pushMessageService;
    @Resource
    private MembersService membersService;

    /**
     * 查询亲友列表信息
     * @param memberId
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/queryKithInfo",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String  queryKithInfo(String memberId,HttpServletRequest request) {
         JSONObject json = new JSONObject();
         if(StringUtils.isBlank(memberId)){
             json.put("success",false);
             json.put("message","参数不能为空");
             return json.toJSONString();
         }else{
           try {
               //查询有效的好友列表
               List<KithAndKin> list = this.kithAndKinService.selectUserKithList(memberId);
               JSONObject dataJson = new JSONObject();
               String contentId = "";
               if (!list.isEmpty()) {
                   //循环放置附件id
                   log.info("查询出亲友个数:" + list.size());
                   for (KithAndKin kith : list) {
                       List<Content> cList = this.contentService.selectContentsById(kith.getNickMemberId(), "tbl_members", "1001");
                       if (!cList.isEmpty() && cList.size() > 0) {
                           contentId = cList.get(0).getContentId();
                           kith.setContentId(contentId);
                       }
                   }
               }
               dataJson.put("info", list);
               json.put("data", dataJson);
               json.put("success", true);
               json.put("message", "查询成功");
           }catch(Exception ex){
               json.put("success", false);
               json.put("message", "查询失败");
               throw new ServiceException("查询异常",ex);
           }
         }
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 查询出用户 点击添加按钮触发
     * @param memberId 当前用户id
     * @param nickName   好友姓名
     * @param kithMemberId 添加好友id
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/btnAddKithKin",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String  btnAddKithKin(String memberId,String nickName,String kithMemberId,HttpServletRequest request) {
        JSONObject json = new JSONObject();
        //备注
        String relationRemark=request.getParameter("relationRemark");
        if(StringUtils.isBlank(memberId)||StringUtils.isBlank(kithMemberId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }else{
            //判断是否已经是好友
            List<KithAndKin> list = kithAndKinService.selectKithListByPara(memberId,kithMemberId, null, "1");
            if(list!=null&&list.size()>0){
                json.put("success",false);
                json.put("message","对方已经是你的好友");
                return json.toJSONString();
            }
            //判断是否有正在申请中的信息
            Map<String,String> map=new HashMap<String,String>();
            map.put("sendMemberId",memberId);
            map.put("memberId",kithMemberId);
            map.put("messageType","01");
            map.put("status","01");
            List<Message> messageList=this.messageService.selectMessageList(map);
            if(messageList!=null&&messageList.size()>0){
                json.put("success",false);
                json.put("message","请等待对方通过申请");
                return json.toJSONString();
            }
            //按钮点击时插入一条状态为无效的关系，等对方通过后，状态更新为有效
            KithAndKin kith=new KithAndKin();
            kith.setKinId(UUID.randomUUID().toString());
            kith.setMemberId(memberId);
            kith.setNickMemberId(kithMemberId);
            if(StringUtils.isBlank(nickName)){
                //为空再查询下数据库
                MemberExtend extend =this.memberExtendService.selectByPrimaryKey(kithMemberId);
                if(extend!=null){
                    nickName=extend.getName();
                }
            }
            kith.setNickName(nickName);
            kith.setAvailable(0); //插入无效
            kith.setAllowAccess(0);
            kith.setSpecialConcern(0);
            kith.setAccessNick(0);
            kith.setCreatedDate(new Date());
            kith.setRelationRemark(relationRemark);
            try {
                int i = this.kithAndKinService.insertSelective(kith);
                if (i > 0) {
                    //插入一条消息记录
                    Message message=new Message();
                    message.setMessageId(UUID.randomUUID().toString());
                    message.setMessage("请求加你为好友");
                    message.setMessageType("01");
                    message.setSendDate(new Date());
                    message.setStatus("01");
                    message.setUserId(memberId);
                    message.setReceiveUserId(kithMemberId);
                    message.setAvailable(1);
                    message.setCreatedDate(new Date());
                    message.setCreateBy(memberId);
                    int t= this.messageService.insertSelective(message);
                    //个推送推送消息
                    if(t>0){
                        MemberExtend extend=this.memberExtendService.selectByPrimaryKey(memberId);
                        if(extend!=null){
                            String sender="";
                            if(extend.getName()!=null){
                                sender=extend.getName();
                            }else{
                                Members members=membersService.selectByPrimaryKey(memberId);
                                if(members!=null){
                                    sender=members.getPhone();
                                }
                            }
                            String title="添加好友申请通知";
                            String msg=sender+"申请加你为好友";
                            String res=pushMessageService.pushMessageToOne(kithMemberId,title,msg);
                            log.info("推送返回:"+res);
                        }
                    }
                    json.put("success", true);
                    json.put("message", "操作成功");
                } else {
                    json.put("success", true);
                    json.put("message", "数据插入错误");
                }
            }catch(Exception ex){
                throw new ServiceException("插入异常",ex);
            }
        }

        return json.toJSONString();
    }

    /**
     * 修改亲友备注接口
     * @param kith
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/btnUpdateKithKin",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String  btnUpdateKithKin(KithAndKin kith) {
        JSONObject json = new JSONObject();
        if(kith==null||StringUtils.isBlank(kith.getKinId())){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }else{
            //按钮点击时更新相应亲友信息
            kith.setUpdatedDate(new Date());
            KithAndKin old=this.kithAndKinService.selectByPrimaryKey(kith.getKinId());
            int i=this.kithAndKinService.updateByPrimaryKeySelective(kith);
            if(i>0){
                //若更新允许访问，则反向亲友不需要再申请
                if(old!=null&&old.getAllowAccess()!=null&&old.getAllowAccess()==0&&kith.getAllowAccess()!=null&&kith.getAllowAccess()==1){
                    List<KithAndKin> list = kithAndKinService.selectKithListByPara(old.getNickMemberId(),old.getMemberId(), null, "1");
                    if(list!=null&&list.size()>0){
                        KithAndKin opKin=list.get(0);
                        if(opKin!=null&&opKin.getAllowAccess()!=null&&opKin.getAllowAccess()!=1){
                            KithAndKin upopKin=new KithAndKin();
                            upopKin.setKinId(opKin.getKinId());
                            upopKin.setAccessNick(1);
                            int j=this.kithAndKinService.updateByPrimaryKeySelective(upopKin);
                            if(j>0){
                                log.info("更新反向允许访问成功");
                            }
                        }
                    }
                }
                //若更新为不允许访问，反向更新不能访问 0 不允许 1允许
                if(old!=null&&old.getAllowAccess()!=null&&old.getAllowAccess()==1&&kith.getAllowAccess()!=null&&kith.getAllowAccess()==0){
                    List<KithAndKin> list = kithAndKinService.selectKithListByPara(old.getNickMemberId(),old.getMemberId(), null, "1");
                    if(list!=null&&list.size()>0){
                        KithAndKin opKin=list.get(0);
                        if(opKin!=null&&opKin.getAllowAccess()!=null){
                            opKin.setAccessNick(0); //对方不能再访问你的信息
                            int j=this.kithAndKinService.updateByPrimaryKeySelective(opKin);
                            if(j>0){
                                log.info("更新反向能否访问成功");
                            }
                        }
                    }
                }
                json.put("success",true);
                json.put("message","操作成功");
            }else{
                json.put("success",false);
                json.put("message","数据更新错误");
            }
        }
        return json.toJSONString();
    }
}
