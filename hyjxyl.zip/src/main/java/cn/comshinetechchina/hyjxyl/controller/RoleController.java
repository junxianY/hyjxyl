package cn.comshinetechchina.hyjxyl.controller;
import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.Role;
import cn.comshinetechchina.hyjxyl.domain.RoleFuncKey;
import cn.comshinetechchina.hyjxyl.service.RoleFuncService;
import cn.comshinetechchina.hyjxyl.service.RoleService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/roleController")
public class RoleController extends BaseController {
    @Resource
    private RoleService roleService;
    @Resource
    private RoleFuncService roleFuncService;

    /**
     * 查询角色列表
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryRoleList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryRoleList(){
        JSONObject json=new JSONObject();
        JSONObject dataJson=new JSONObject();
        List<Role> list=new ArrayList<Role>();
        try {
            list = roleService.selectRoleList();
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list",list);
        json.put("success",true);
        json.put("message","查询成功");
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 角色绑定菜单权限
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/roleBindFunction", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String roleBindFunction(Integer roleId, HttpServletRequest request){
        JSONObject json=new JSONObject();
        if(null==roleId||roleId<0){
            json.put("success",false);
            json.put("message","参数错误");
            return json.toJSONString();
        }
        String functionIds=request.getParameter("functionIds");
        String[] functionId1=null;
        if(StringUtils.isNotBlank(functionIds)){
            if(functionIds.indexOf(",")!=-1){
                //多个权限
                functionId1=functionIds.split(",");
            }else{
                //单个权限
                functionId1=new String[1];
                functionId1[0]=functionIds;
            }
            if(functionId1!=null){
                RoleFuncKey rf=null;
                List<RoleFuncKey> list=new ArrayList<RoleFuncKey>();
                for(int i=0;i<functionId1.length;i++){
                    String functionId=functionId1[i];
                    rf= new RoleFuncKey();
                    rf.setFunctionId(Long.parseLong(functionId));
                    rf.setRoleId(roleId);
                    list.add(rf);
                }
                //1.删除关系
                int t=roleFuncService.deleteRoleFunctions(roleId);
                //2.批量插入
                int i=roleFuncService.batchInsertRoleFunc(list);
                if(i>0){
                    json.put("success",true);
                    json.put("message","更新成功");
                }
            }
        }
        return json.toJSONString();
    }

}
