package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.CardTypeService;
import cn.comshinetechchina.hyjxyl.service.CardTypeServiceService;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.junit.platform.commons.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * 卡类型与服务关联控制层
 * Author:yjx
 */
@RestController
@RequestMapping("/cardTypeServiceController")
public class CardTypeServiceController extends BaseController {
    private static final Logger log = LoggerFactory.getLogger(CardTypeServiceController.class);
    @Resource
    private CardTypeServiceService cardTypeServiceService;

    /**
     * 增加单一卡类型服务接口
     * @param info
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addCardTypeService", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addCardTypeService(CardTypeService info,HttpServletRequest request) {
        JSONObject json = new JSONObject();
        if (null == info||null==info.getCardTypeId()) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        info.setCardTypeServiceId(UUID.randomUUID().toString());
        info.setCreateTime(new Date());
        String token = request.getHeader("token");
        try {
            Map<String, Object> map = JwtUtil.parseManagementToken(token);
            String userName = map.get("userName") == null ? "" : map.get("userName").toString();
            log.info("当前后台登录人userName:" + userName);
            //当前用户
            info.setCreateBy(userName);
            int i = this.cardTypeServiceService.insertSelective(info);
            if (i > 0) {
                json.put("success", true);
                json.put("message", "成功");
            } else {
                json.put("success", false);
                json.put("message", "操作失败");
            }
        }catch(Exception ex){
            throw new ServiceException("插入异常",ex);
        }
        return json.toJSONString();
    }
    /**
     * 通过条件查询卡类别服务列表
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryCardsTypeServiceInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryCardsTypeServiceInfo(HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        String cardTypeId = request.getParameter("cardTypeId");
        String serviceId = request.getParameter("serviceId");
        Map<String,String> map = new HashMap<String,String>();
        map.put("cardTypeId", cardTypeId);
        map.put("serviceId", serviceId);
        List<CardTypeService> list = new ArrayList<CardTypeService>();
        try {
            list = this.cardTypeServiceService.selectCardTypeServiceList(map);
            json.put("success", true);
            json.put("message", "成功");
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list", list);
        json.put("data", dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 删除卡类别关联服务
     * @param cardTypeServiceId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/deleteCardsTypeService", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String deleteCardsTypeService(String cardTypeServiceId){
        JSONObject json = new JSONObject();
        if(StringUtils.isBlank(cardTypeServiceId)){
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        try {
            int i = this.cardTypeServiceService.deleteByPrimaryKey(cardTypeServiceId);
            if (i > 0) {
                json.put("success", true);
                json.put("message", "成功");
            } else {
                json.put("success", false);
                json.put("message", "操作失败");
            }
        }catch(Exception ex){
            throw new ServiceException("删除失败",ex);
        }
        return json.toJSONString();
    }
}
