package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.domain.PushMember;
import cn.comshinetechchina.hyjxyl.service.PushMemberService;
import cn.comshinetechchina.hyjxyl.util.UserAgentUtils;
import com.alibaba.fastjson.JSONObject;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.*;

/**
 * 推送用户控制器
 */
@RestController
@RequestMapping("/pushMemberController")
public class PushMemberController extends BaseController {
    private Logger log= LoggerFactory.getLogger(PushMemberController.class);
    @Resource
    private PushMemberService pushMemberService;

    /**
     * 推送个推绑定用户
     * @param memberId 客户id
     * @param clientId 个推id
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addPushMember", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addPushMember(String memberId, String clientId, HttpServletRequest request){
        log.info(memberId+"----"+clientId);
        JSONObject json = new JSONObject();
        if(StringUtils.isBlank(memberId)||StringUtils.isBlank(clientId)){
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        PushMember record = new PushMember();
        //判断memberId是否存在，存在更新，不存在插入
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("memberId",memberId);
        List<PushMember> list=this.pushMemberService.selectPushMembersList(map);
        int i=0;
        //设备类型
        String ua= UserAgentUtils.getUaInfo(request);
        log.info("addPushMember ua"+ua);
        String type=UserAgentUtils.getMobileOS(ua);
        //设备类型 2安卓 1 iphone
        int phoneType=0;
        if(type!=null&&type.equals("Android")){
            phoneType=2;
        }else if(type!=null&&type.equals("iPhone")){
            phoneType=1;
        }
        if(list!=null&&list.size()>0){
            //进行更新
            record=list.get(0);
            record.setClientId(clientId);
            record.setPhoneType(phoneType);
            record.setUpdateTime(new Date());
            i=this.pushMemberService.updateByPrimaryKeySelective(record);
        }else{
            //将旧的clientId清除  保证唯一
            int t=this.pushMemberService.delPushMemberByClientId(clientId);
            log.info("清除绑定客户:"+t+"条");
            //进行插入
            record.setId(UUID.randomUUID().toString());
            record.setAvailable(1);
            record.setClientId(clientId);
            record.setMemberId(memberId);
            record.setCreateTime(new Date());
            record.setPhoneType(phoneType);
            i = this.pushMemberService.insertSelective(record);
        }
        if(i>0){
            json.put("message","绑定成功");
            json.put("success",true);
        }else{
            json.put("message","绑定失败");
            json.put("success",false);
        }
        return json.toJSONString();
   }
}
