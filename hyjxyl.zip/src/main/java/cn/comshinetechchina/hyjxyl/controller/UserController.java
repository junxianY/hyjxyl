package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.Role;
import cn.comshinetechchina.hyjxyl.domain.RoleFunction;
import cn.comshinetechchina.hyjxyl.domain.Tenant;
import cn.comshinetechchina.hyjxyl.domain.User;
import cn.comshinetechchina.hyjxyl.service.RoleService;
import cn.comshinetechchina.hyjxyl.service.TenantService;
import cn.comshinetechchina.hyjxyl.service.UserService;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.junit.platform.commons.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import javax.sql.rowset.serial.SerialException;
import java.util.*;

/**
 * 后台用户控制器
 * Author:yjx
 */
@RestController
@RequestMapping("/userController")
public class UserController extends BaseController {
    private static final Logger log = LoggerFactory.getLogger(UserController.class);
    @Resource
    private UserService userService;
    @Resource
    private RoleService roleService;
    @Resource
    private TenantService tenantService;

    /**
     * 后台用户登陆方法
     *
     * @param userName
     * @param password
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/loginCheck", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String loginCheck(String userName, String password) {
        log.info("loginCheck方法：" + userName + "--" + password);
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if (StringUtils.isBlank(userName)) {
            json.put("success", false);
            json.put("message", "账号不能为空");
            return json.toJSONString();
        }
        if (StringUtils.isBlank(password)) {
            json.put("success", false);
            json.put("message", "密码不能为空");
            return json.toJSONString();
        }
        User u = this.userService.selectUserByPara(userName, null);
        Integer roleId=0;
        String  roleName="";
        String newToken="";
        String tenantName=""; //租户名称
        if (u != null) {
            if (!u.getPassword().equals(password)) {
                json.put("success", false);
                json.put("message", "密码不正确");
                return json.toJSONString();
            }
            //生成新token保存
            Map<String, Object> payload = new HashMap<String, Object>();
            Date date = new Date();
            payload.put("uid", u.getUserId());// 用户id
            payload.put("tenantId", u.getTenantId());//租户id
            payload.put("roleId", u.getRoleId());//角色id
            payload.put("userName", u.getFullName());//用户名
            payload.put("iat", date.getTime());// 生成时间:当前
            payload.put("ext", date.getTime() + 15*24*60*60*1000);// 过期时间半个月
            //payload.put("ext", date.getTime() + 30 * 60 * 1000); //30分钟
            newToken = JwtUtil.createToken(payload);
            u.setToken(newToken);
            u.setLastUpdatedDate(new Date());
            try {
                int i = this.userService.updateByPrimaryKeySelective(u);
                if (i > 0) {
                    log.info("用户：" + u.getUserId() + "新token设置成功" + newToken);
                }
                //获取用户角色名称
                roleId = u.getRoleId();
                if (roleId != 0) {
                    //查询用户角色
                    Role role = roleService.selectByPrimaryKey(roleId);
                    if (role != null) {
                        roleName = role.getRoleName();
                    }
                }
                //查询租户名称
                if (StringUtils.isNotBlank(u.getTenantId())) {
                    Tenant tenant = this.tenantService.selectByPrimaryKey(u.getTenantId());
                    if (tenant != null) {
                        tenantName = tenant.getName();
                    }
                }
            }catch(Exception ex){
                throw new ServiceException("查询异常",ex);
            }
        } else {
            json.put("success", false);
            json.put("message", "账号不存在");
            return json.toJSONString();
        }
        json.put("success", true);
        json.put("message", "登陆成功");
        dataJson.put("token", newToken);
        dataJson.put("userId", u.getUserId());
        dataJson.put("roleName",roleName);
        dataJson.put("roleId", u.getRoleId());
        dataJson.put("tenantName",tenantName);
        json.put("data",dataJson);
        return json.toJSONString();
    }

    /**
     * 查询用户菜单信息
     * @param userId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryUserFunction", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryUserFunction(String userId){
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if (StringUtils.isBlank(userId)) {
            json.put("success", false);
            json.put("message", "用户不能为空");
            return json.toJSONString();
        }
        User user=this.userService.selectByPrimaryKey(userId);
        List<RoleFunction> list=new ArrayList<RoleFunction>();
        if(user!=null&&user.getRoleId()!=null){
            Role role=this.roleService.selectByPrimaryKey(user.getRoleId());
            if(role!=null){
                //通过角色查询其角色菜单权限
                 list= this.roleService.selectRoleFunctionList(role.getRoleId());
            }
        }
        dataJson.put("functionList",list);
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    @ResponseBody
    @RequestMapping(value = "/queryUserList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryUserList(String userId){
        JSONObject json=new JSONObject();
        JSONObject dataJson=new JSONObject();
        User user=this.userService.selectByPrimaryKey(userId);
        List<User> list=new ArrayList<User>();
        if(user!=null){
            Map<String,Object> map=new HashMap<String,Object>();
            map.put("tenantId",user.getTenantId());
            //map.put("available",1)
            list=this.userService.selectUserList(map);
        }
        dataJson.put("list",list);
        json.put("success",true);
        json.put("message","查询成功");
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
