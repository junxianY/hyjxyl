package cn.comshinetechchina.hyjxyl.controller;
import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.domain.HealthInfo;
import cn.comshinetechchina.hyjxyl.domain.MemberHealth;
import cn.comshinetechchina.hyjxyl.domain.MemberHealthObj;
import cn.comshinetechchina.hyjxyl.domain.PointsDetail;
import cn.comshinetechchina.hyjxyl.service.MemberHealthService;
import cn.comshinetechchina.hyjxyl.service.PointService;
import cn.comshinetechchina.hyjxyl.service.PointsDetailService;
import cn.comshinetechchina.hyjxyl.util.ToolUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.*;

/**
 * 客户健康信息控制层
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/healthController")
public class MemberHealthController extends BaseController {
    @Resource
    private MemberHealthService memberHealthService;
    @Resource
    private PointsDetailService pointsDetailService;
    @Resource
    private PointService pointService;

    /**
     * 增加健康信息
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/addMemberHealthInfo",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addMemberHealthInfo(MemberHealth info) {
        JSONObject json = new JSONObject();
        if(null==info|| StringUtils.isBlank(info.getMemberId())){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        String uId="";
        int i=0;
        MemberHealth data=this.memberHealthService.selectMemberHealthInfo(info.getMemberId());
        if(data!=null){
            //存在更新
            uId=info.getHealthId();
            BeanUtils.copyProperties(info,data);
            data.setLastUpdateTime(new Date());
            i=this.memberHealthService.updateByPrimaryKeySelective(data);
        }else{
            //不存在插入
            uId=UUID.randomUUID().toString();
            info.setHealthId(uId);
            info.setLastUpdateTime(new Date());
            i=this.memberHealthService.insertSelective(info);
        }

        if(i>0){
            json.put("success",true);
            json.put("message","操作成功");
            json.put("healthId",uId);
            //操作成功 计入积分 add 20180829
            HealthInfo hInfo=new HealthInfo();
            BeanUtils.copyProperties(info,hInfo);
            if(ToolUtil.checkObjFieldIsNotNull(hInfo)){
                Map<String,Object> map=new HashMap<String,Object>();
                map.put("memberId",info.getMemberId());
                map.put("type",2);
                List<PointsDetail> list=this.pointsDetailService.selectPointsDetailList(map);
                if(list==null||list.size()==0){
                    //代表首次补全资料
                    this.pointService.savePointInfo(info.getMemberId(),2,0,null);
                }
            }

        }else{
            json.put("success",false);
            json.put("message","操作错误");
            json.put("healthId","");
        }
        return json.toJSONString();
    }

    /**
     * 查询某人健康基本信息
     * @param memberId
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/queryhealthInfo",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryhealthInfo(String memberId){
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if(StringUtils.isBlank(memberId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        //查询健康信息
        MemberHealth health=memberHealthService.selectMemberHealthInfo(memberId);
        MemberHealthObj obj=new MemberHealthObj();
        if(health!=null){
            BeanUtils.copyProperties(health,obj);
        }
        dataJson.put("info",obj);
        json.put("success",true);
        json.put("message","查询成功");
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

}
