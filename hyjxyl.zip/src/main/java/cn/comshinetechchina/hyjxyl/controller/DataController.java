package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.*;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

@RestController
@EnableAutoConfiguration
@RequestMapping("/dataController")
public class DataController extends BaseController {
    private Logger log= LoggerFactory.getLogger(DataController.class);
    @Resource
    private UrineDataService urineDataService;
    @Resource
    private DeviceDataService deviceDataService;
    @Resource
    private MembersService membersService;
    @Resource
    private CardService cardService;
    @Resource
    private BloodSugarDataService bloodSugarDataService;
    @Resource
    private BloodPressureDataService bloodPressureDataService;
    @Resource
    private BloodOxygenDataService bloodOxygenDataService;
    @Resource
    private FatERDataService fatERDataService;
    @Resource
    private LocationService locationService;
    @Resource
    private CardUseRecordService cardUseRecordService;
    @Resource
    private WeightDataService weightDataService;
    @Resource
    private FatDataService fatDataService;
    @Resource
    private TestRecordService testRecordService;
    /**
     * 接收json控制层
     * @param dataJson
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/receiveData", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String receiveData(@RequestBody String dataJson) {
        log.info("receiveData:"+dataJson);
        JSONObject json = new JSONObject();
        if (StringUtils.isBlank(dataJson)) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        return deviceDataService.receiveData(dataJson);
    }

    /**
     * 查询尿液数据明细
     * @param request
     * @param type 1、app 2、后台
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryUrineDataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryUrineDataList(HttpServletRequest request,Integer type) {
        log.info("into method queryUrineDataList");
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if (null==type) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //前端拿取当前登录人id 后台接收参数
        String memberId="";
        String cardNo="";
        if(type==1){
            String token = request.getHeader("token");
            try {
                Map<String, Object> map = JwtUtil.parseManagementToken(token);
                memberId = map.get("uid") == null ? "" : map.get("uid").toString();
                log.info("当前后台登录人memberId:" + memberId);
            }catch(Exception ex){
                throw new ServiceException("token解析失败",ex);
            }
        }else if(type==2){
            memberId=request.getParameter("memberId");
        }
        if(StringUtils.isNotBlank(memberId)){
            Members member=this.membersService.selectByPrimaryKey(memberId);
            if(member!=null&&member.getCardId()!=null){
                Card card=this.cardService.selectByPrimaryKey(member.getCardId());
                if(card!=null){
                    cardNo=card.getCardNo();
                }
            }
        }
        //没卡号的不返回数据
        if(StringUtils.isBlank(cardNo)){
            json.put("success", false);
            json.put("message", "尚未有数据");
            return json.toJSONString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardNo",cardNo);
        map.put("available",1);
        map.put("startDate",request.getParameter("startDate"));
        map.put("endDate",request.getParameter("endDate"));
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        List<UrineData> list=new ArrayList<UrineData>();
        int totalCount=0;
        try {
            list = this.urineDataService.selectUrineDataList(bean, map);
            json.put("success",true);
            json.put("message","查询成功");
            totalCount=bean.getTotalRows();
        }catch(Exception ex){
           throw new ServiceException("查询异常",ex);
        }
        dataJson.put("totalCount", totalCount);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        dataJson.put("list",list);
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * 查询血糖数据明细
     * @param request
     * @param type 1、app 2、后台
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryBloodSugarDataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryBloodSugarDataList(HttpServletRequest request,Integer type) {
        log.info("into method queryBloodSugarDataList");
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if (null==type) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //前端拿取当前登录人id 后台接收参数
        String memberId="";
        String cardNo="";
        if(type==1){
            String token = request.getHeader("token");
            try {
                Map<String, Object> map = JwtUtil.parseManagementToken(token);
                memberId = map.get("uid") == null ? "" : map.get("uid").toString();
                log.info("当前后台登录人memberId:" + memberId);
            }catch(Exception ex){
                throw new ServiceException("token解析失败",ex);
            }
        }else if(type==2){
            memberId=request.getParameter("memberId");
        }
        if(StringUtils.isNotBlank(memberId)){
            Members member=this.membersService.selectByPrimaryKey(memberId);
            if(member!=null&&member.getCardId()!=null){
                Card card=this.cardService.selectByPrimaryKey(member.getCardId());
                if(card!=null){
                    cardNo=card.getCardNo();
                }
            }
        }
        //没卡号的不返回数据
        if(StringUtils.isBlank(cardNo)){
            json.put("success", false);
            json.put("message", "尚未有数据");
            return json.toJSONString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardNo",cardNo);
        map.put("available",1);
        map.put("startDate",request.getParameter("startDate"));
        map.put("endDate",request.getParameter("endDate"));
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        List<BloodSugarData> list=new ArrayList<BloodSugarData>();
        int totalCount=0;
        try {
            list = this.bloodSugarDataService.selectBloodSugarDataList(bean,map);
            json.put("success",true);
            json.put("message","查询成功");
            totalCount=bean.getTotalRows();
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        //图表时间从小到大
        if(list!=null&&list.size()>0){
            Collections.reverse(list);
        }
        //组装图表数据
        String eChartsData=this.bloodSugarDataService.packageChartData(list);
        dataJson.put("totalCount", totalCount);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        dataJson.put("list",list);
        dataJson.put("eChartsData",eChartsData);
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * 查询血压数据明细
     * @param request
     * @param type 1、app 2、后台
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryBloodPressureDataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryBloodPressureDataList(HttpServletRequest request,Integer type) {
        log.info("into method queryBloodPressureDataList");
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if (null==type) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //前端拿取当前登录人id 后台接收参数
        String memberId="";
        String cardNo="";
        if(type==1){
            String token = request.getHeader("token");
            try {
                Map<String, Object> map = JwtUtil.parseManagementToken(token);
                memberId = map.get("uid") == null ? "" : map.get("uid").toString();
                log.info("当前后台登录人memberId:" + memberId);
            }catch(Exception ex){
                throw new ServiceException("token解析失败",ex);
            }
        }else if(type==2){
            memberId=request.getParameter("memberId");
        }
        if(StringUtils.isNotBlank(memberId)){
            Members member=this.membersService.selectByPrimaryKey(memberId);
            if(member!=null&&member.getCardId()!=null){
                Card card=this.cardService.selectByPrimaryKey(member.getCardId());
                if(card!=null){
                    cardNo=card.getCardNo();
                }
            }
        }
        //没卡号的不返回数据
        if(StringUtils.isBlank(cardNo)){
            json.put("success", false);
            json.put("message", "尚未有数据");
            return json.toJSONString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardNo",cardNo);
        map.put("available",1);
        map.put("startDate",request.getParameter("startDate"));
        map.put("endDate",request.getParameter("endDate"));
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        List<BloodPressureData> list=new ArrayList<BloodPressureData>();
        int totalCount=0;
        try {
            list = this.bloodPressureDataService.selectBloodPressureDataList(bean,map);
            json.put("success",true);
            json.put("message","查询成功");
            totalCount=bean.getTotalRows();
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        //图表时间从小到大
        if(list!=null&&list.size()>0){
            Collections.reverse(list);
        }
        String eChartsData=this.bloodPressureDataService.packageChartData(list);
        dataJson.put("eChartsData", eChartsData);
        dataJson.put("totalCount", totalCount);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        dataJson.put("list",list);
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * 查询体重数据明细
     * @param request
     * @param type 1、app 2、后台
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryWeightDataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryWeightDataList(HttpServletRequest request,Integer type) {
        log.info("into method queryWeightDataList");
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if (null==type) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //前端拿取当前登录人id 后台接收参数
        String memberId="";
        String cardNo="";
        if(type==1){
            String token = request.getHeader("token");
            try {
                Map<String, Object> map = JwtUtil.parseManagementToken(token);
                memberId = map.get("uid") == null ? "" : map.get("uid").toString();
                log.info("当前后台登录人memberId:" + memberId);
            }catch(Exception ex){
                throw new ServiceException("token解析失败",ex);
            }
        }else if(type==2){
            memberId=request.getParameter("memberId");
        }
        if(StringUtils.isNotBlank(memberId)){
            Members member=this.membersService.selectByPrimaryKey(memberId);
            if(member!=null&&member.getCardId()!=null){
                Card card=this.cardService.selectByPrimaryKey(member.getCardId());
                if(card!=null){
                    cardNo=card.getCardNo();
                }
            }
        }
        //没卡号的不返回数据
        if(StringUtils.isBlank(cardNo)){
            json.put("success", false);
            json.put("message", "尚未有数据");
            return json.toJSONString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardNo",cardNo);
        map.put("available",1);
        map.put("startDate",request.getParameter("startDate"));
        map.put("endDate",request.getParameter("endDate"));
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        List<WeightData> list=new ArrayList<WeightData>();
        int totalCount=0;
        try {
            list = this.weightDataService.selectWeightDataList(bean,map);
            json.put("success",true);
            json.put("message","查询成功");
            totalCount=bean.getTotalRows();
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        //图表时间从小到大
        if(list!=null&&list.size()>0){
            Collections.reverse(list);
        }
        String eChartsData=this.weightDataService.packageChartData(list);
        dataJson.put("totalCount", totalCount);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        dataJson.put("list",list);
        dataJson.put("eChartsData",eChartsData);
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * 查询血氧数据明细
     * @param request
     * @param type 1、app 2、后台
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryBloodOxygenDataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryBloodOxygenDataList(HttpServletRequest request,Integer type) {
        log.info("into method queryBloodOxygenDataList");
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if (null==type) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //前端拿取当前登录人id 后台接收参数
        String memberId="";
        String cardNo="";
        if(type==1){
            String token = request.getHeader("token");
            try {
                Map<String, Object> map = JwtUtil.parseManagementToken(token);
                memberId = map.get("uid") == null ? "" : map.get("uid").toString();
                log.info("当前后台登录人memberId:" + memberId);
            }catch(Exception ex){
                throw new ServiceException("token解析失败",ex);
            }
        }else if(type==2){
            memberId=request.getParameter("memberId");
        }
        if(StringUtils.isNotBlank(memberId)){
            Members member=this.membersService.selectByPrimaryKey(memberId);
            if(member!=null&&member.getCardId()!=null){
                Card card=this.cardService.selectByPrimaryKey(member.getCardId());
                if(card!=null){
                    cardNo=card.getCardNo();
                }
            }
        }
        //没卡号的不返回数据
        if(StringUtils.isBlank(cardNo)){
            json.put("success", false);
            json.put("message", "尚未有数据");
            return json.toJSONString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardNo",cardNo);
        map.put("available",1);
        map.put("startDate",request.getParameter("startDate"));
        map.put("endDate",request.getParameter("endDate"));
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        List<BloodOxygenData> list=new ArrayList<BloodOxygenData>();
        int totalCount=0;
        try {
            list = this.bloodOxygenDataService.selectBloodOxygenDataList(bean,map);
            json.put("success",true);
            json.put("message","查询成功");
            totalCount=bean.getTotalRows();
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        //图表时间从小到大
        if(list!=null&&list.size()>0){
            Collections.reverse(list);
        }
        //组装图表数据
        String eChartsData=this.bloodOxygenDataService.packageChartData(list);
        dataJson.put("eChartsData", eChartsData);
        dataJson.put("totalCount", totalCount);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        dataJson.put("list",list);
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 查询脂肪透传电阻数据明细
     * @param request
     * @param type 1、app 2、后台
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryFatERDataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryFatERDataList(HttpServletRequest request,Integer type) {
        log.info("into method queryFatERDataList");
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if (null==type) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //前端拿取当前登录人id 后台接收参数
        String memberId="";
        String cardNo="";
        if(type==1){
            String token = request.getHeader("token");
            try {
                Map<String, Object> map = JwtUtil.parseManagementToken(token);
                memberId = map.get("uid") == null ? "" : map.get("uid").toString();
                log.info("当前后台登录人memberId:" + memberId);
            }catch(Exception ex){
                throw new ServiceException("token解析失败",ex);
            }
        }else if(type==2){
            memberId=request.getParameter("memberId");
        }
        if(StringUtils.isNotBlank(memberId)){
            Members member=this.membersService.selectByPrimaryKey(memberId);
            if(member!=null&&member.getCardId()!=null){
                Card card=this.cardService.selectByPrimaryKey(member.getCardId());
                if(card!=null){
                    cardNo=card.getCardNo();
                }
            }
        }
        //没卡号的不返回数据
        if(StringUtils.isBlank(cardNo)){
            json.put("success", false);
            json.put("message", "尚未有数据");
            return json.toJSONString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardNo",cardNo);
        map.put("available",1);
        map.put("startDate",request.getParameter("startDate"));
        map.put("endDate",request.getParameter("endDate"));
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        List<FatERData> list=new ArrayList<FatERData>();
        int totalCount=0;
        try {
            list = this.fatERDataService.selectFatERDataList(bean,map);
            json.put("success",true);
            json.put("message","查询成功");
            totalCount=bean.getTotalRows();
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("totalCount", totalCount);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        dataJson.put("list",list);
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * 查询脂肪数据明细
     * @param request
     * @param type 1、app 2、后台
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryFatDataList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryFatDataList(HttpServletRequest request,Integer type) {
        log.info("into method queryFatDataList");
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if (null==type) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //前端拿取当前登录人id 后台接收参数
        String memberId="";
        String cardNo="";
        if(type==1){
            String token = request.getHeader("token");
            try {
                Map<String, Object> map = JwtUtil.parseManagementToken(token);
                memberId = map.get("uid") == null ? "" : map.get("uid").toString();
                log.info("当前后台登录人memberId:" + memberId);
            }catch(Exception ex){
                throw new ServiceException("token解析失败",ex);
            }
        }else if(type==2){
            memberId=request.getParameter("memberId");
        }
        if(StringUtils.isNotBlank(memberId)){
            Members member=this.membersService.selectByPrimaryKey(memberId);
            if(member!=null&&member.getCardId()!=null){
                Card card=this.cardService.selectByPrimaryKey(member.getCardId());
                if(card!=null){
                    cardNo=card.getCardNo();
                }
            }
        }
        //没卡号的不返回数据
        if(StringUtils.isBlank(cardNo)){
            json.put("success", false);
            json.put("message", "尚未有数据");
            return json.toJSONString();
        }
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardNo",cardNo);
        map.put("available",1);
        map.put("startDate",request.getParameter("startDate"));
        map.put("endDate",request.getParameter("endDate"));
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        List<FatData> list=new ArrayList<FatData>();
        int totalCount=0;
        try {
            list = this.fatDataService.selectFatDataList(bean,map);
            json.put("success",true);
            json.put("message","查询成功");
            totalCount=bean.getTotalRows();
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        //图表时间从小到大
        if(list!=null&&list.size()>0){
            Collections.reverse(list);
        }
        //组装图表数据
        String eChartsData=this.fatDataService.packageChartData(list);
        dataJson.put("totalCount", totalCount);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        dataJson.put("list",list);
        dataJson.put("eChartsData",eChartsData);
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * app查询数据中心
     * @param memberId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryDataCenterInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryDataCenterInfo(String memberId){
        log.info("into method queryDataCenterInfo:"+memberId);
        JSONObject json = new JSONObject();
        JSONObject jsonData = new JSONObject();
        JSONObject checkListData = new JSONObject();

        Map<String,Object> map=new HashMap<String,Object>();
        map.put("available",1);
        String cardNo="";
        if(StringUtils.isNotBlank(memberId)){
            Members member=this.membersService.selectByPrimaryKey(memberId);
            if(member!=null&&member.getCardId()!=null){
                Card card=this.cardService.selectByPrimaryKey(member.getCardId());
                if(card!=null){
                    cardNo=card.getCardNo();
                }
            }
        }
        map.put("cardNo",cardNo);
        map.put("memberId",memberId);
        //取三条
        PageBean page = new PageBean();
        page.setRowStart(0);


        List<CardUseRecordObj> useList=new ArrayList<CardUseRecordObj>();
        List<Location> locationList=new ArrayList<Location>();
        List<CheckData> checkList=new ArrayList<CheckData>();
         //健康数据
        try {
            page.setPageSize(20);
            List<TestRecord> list=this.testRecordService.selectTestRecordList(map,page);
            if(list!=null&&list.size()>0){
                for(TestRecord record:list){
                    String text= record.getRecord();
                    if(StringUtils.isNotBlank(text)){
                        CheckData checkData=JSONObject.parseObject(text,CheckData.class);
                        log.info(checkData.getReportNo());
                        checkList.add(checkData);
                    }
                }
            }
            if(checkList!=null&&checkList.size()>0){
                //列表按时间倒序排列
                Collections.sort(checkList, new Comparator<CheckData>() {
                    public int compare(CheckData a, CheckData b) {
                        String time2 = a.getCreateTime();
                        String time1 = b.getCreateTime();
                        return time1.compareTo(time2);
                    }
                });
            }
            //循环过滤各项目 取三条 1:体重 2:血糖 3:血氧 4：血压\脉搏 5：血脂 6：尿酸 7体脂 8心率
            if(checkList.size()>0){
                List<CheckData> list1=new ArrayList<>();
                List<CheckData> list2=new ArrayList<>();
                List<CheckData> list3=new ArrayList<>();
                List<CheckData> list4=new ArrayList<>();
                List<CheckData> list5=new ArrayList<>();
                List<CheckData> list6=new ArrayList<>();
                List<CheckData> list7=new ArrayList<>();
                List<CheckData> list8=new ArrayList<>();
                for(CheckData data:checkList){
                    list1.add(data);
                    list2.add(data);
                    list3.add(data);
                    list4.add(data);
                    list5.add(data);
                    list6.add(data);
                    list7.add(data);
                    list8.add(data);
                }
                list1=RuleUtil.filterData(list1,1);
                list2=RuleUtil.filterData(list2,2);
                list3=RuleUtil.filterData(list3,3);
                list4=RuleUtil.filterData(list4,4);
                list5=RuleUtil.filterData(list5,5);
                list6=RuleUtil.filterData(list6,6);
                list7=RuleUtil.filterData(list7,7);
                list8=RuleUtil.filterData(list8,8);
                if(list1.size()>3){
                    checkListData.put("weightList",list1.subList(0,3));
                }else{
                    checkListData.put("weightList",list1);
                }
                if(list2.size()>3){
                    checkListData.put("bloodSugarList",list2.subList(0,3));
                }else{
                    checkListData.put("bloodSugarList",list2);
                }
                if(list3.size()>3){
                    checkListData.put("bloodOxygenList",list3.subList(0,2));
                }else{
                    checkListData.put("bloodOxygenList",list3);
                }
                if(list4.size()>3){
                    checkListData.put("bloodPressureList",list4.subList(0,3));
                }else{
                    checkListData.put("bloodPressureList",list4);
                }
                if(list5.size()>3){
                    checkListData.put("bloodFatList",list5.subList(0,3));
                }else{
                    checkListData.put("bloodFatList",list5);
                }
                if(list6.size()>3){
                    checkListData.put("uricAcidList",list6.subList(0,3));
                }else{
                    checkListData.put("uricAcidList",list6);
                }
                if(list7.size()>3){
                    checkListData.put("bodyFatList",list7.subList(0,3));
                }else{
                    checkListData.put("bodyFatList",list7);
                }
                if(list8.size()>3){
                    checkListData.put("heartRateList",list8.subList(0,3));
                }else{
                    checkListData.put("heartRateList",list8);
                }
            }else{
                checkListData.put("weightList","");
                checkListData.put("bloodSugarList","");
                checkListData.put("bloodOxygenList","");
                checkListData.put("bloodPressureList","");
                checkListData.put("bloodFatList","");
                checkListData.put("uricAcidList","");
                checkListData.put("bodyFatList","");
                checkListData.put("heartRateList","");
            }

            page.setPageSize(3);
            //行为数据
            useList = this.cardUseRecordService.selectRecordList(page, map);
            //位置数据
            locationList = this.locationService.selectLocationList(page, map);

            json.put("success",true);
            json.put("message","查询成功");
         }catch(Exception ex){
           throw new ServiceException("查询异常",ex);
         }
         jsonData.put("checkList",checkListData);
         jsonData.put("useList",useList);
         jsonData.put("locationList",locationList);
         json.put("data",jsonData);

         return  JSON.toJSONString(json, SerializerFeature.DisableCircularReferenceDetect);
    }

    /**
     * 通过id查询体检结果
     * @param memberId
     * @param type 1:体重 2:血糖 3:血氧 4：血压\脉搏 5：血脂 6：尿酸 7体脂 8心率
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryTestData", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryTestData(String memberId,Integer type,HttpServletRequest request){
        JSONObject json=new JSONObject();
        JSONObject data=new JSONObject();
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("memberId",memberId);
        //需要分页
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
       /* PageBean bean = new PageBean();
        if (StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }*/
        //开始时间
        String startDate=request.getParameter("startDate");
        map.put("startDate",startDate);
        //结束时间
        String endDate=request.getParameter("endDate");
        map.put("endDate",endDate);
        try {
            //查询出所有数据 过滤掉无效数据 此处分页
            List<TestRecord> list= this.testRecordService.selectAllTestRecordList(map);
            //List<TestRecord> list = this.testRecordService.selectTestRecordList(map, bean);
            List<CheckData> checkList = new ArrayList<CheckData>();
            List<CheckData> newList =null;
            String eChartsData="";
            if (list != null && list.size() > 0) {
                for (TestRecord record : list) {
                    String text = record.getRecord();
                    if (StringUtils.isNotBlank(text)) {
                        CheckData checkData = JSONObject.parseObject(text, CheckData.class);
                        log.info(checkData.getReportNo());
                        checkList.add(checkData);
                    }
                }
            //过滤空消息
            checkList=RuleUtil.filterData(checkList,type);
            //分页组装
            if(checkList!=null&&checkList.size()>Integer.parseInt(pageSize)){
                int max=0;
                if(checkList.size()>Integer.parseInt(pageSize) * Integer.parseInt(pageIndex)+Integer.parseInt(pageSize)){
                    max=Integer.parseInt(pageSize) * Integer.parseInt(pageIndex)+Integer.parseInt(pageSize);
                }else{
                    //当前页大于总条数
                    max=checkList.size();
                }
                newList=checkList.subList(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex),max);
            }else{
                newList=checkList;
            }
            eChartsData = this.testRecordService.packageChartData(newList, type);
            if (checkList != null && checkList.size() > 0) {
                //列表按时间倒序排列
                Collections.sort(newList, new Comparator<CheckData>() {
                    public int compare(CheckData a, CheckData b) {
                        String time2 = a.getCreateTime();
                        String time1 = b.getCreateTime();
                        return time1.compareTo(time2);
                    }
                });
            }
            }
            data.put("eChartsData", eChartsData);
            data.put("list", newList);
            data.put("totalCount", list.size());
            data.put("pageIndex", pageIndex);
            data.put("pageSize", pageSize);
            json.put("success", true);
            json.put("message", "查询成功");
            json.put("data", data);
        }catch(Exception ex){
            throw new ServiceException(ex,"查询失败");
        }
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
