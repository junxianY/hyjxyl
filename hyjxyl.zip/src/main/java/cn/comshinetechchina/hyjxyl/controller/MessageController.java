package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.*;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * 消息控制层
 * Author:yjx
 */
@RestController
@RequestMapping("/messageController")
public class MessageController extends BaseController {
    private static final Logger log = LoggerFactory.getLogger(MessageController.class);
    @Resource
    private MessageService messageService;
    @Resource
    private KithAndKinService kithAndKinService;
    @Resource
    private ContentService contentService;
    @Resource
    private MemberExtendService memberExtendService;
    @Resource
    private PushMessageService pushMessageService;
    @Resource
    private MembersService membersService;
    /**
     * 增加发送信息方法
     * @param info
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addMessageInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addMessageInfo(Message info,HttpServletRequest request) {
        log.info("进入addMessageInfo方法");
        JSONObject json = new JSONObject();
        if (null == info||null==info.getMessage()) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        String uId= UUID.randomUUID().toString();
        info.setMessageId(uId);
        info.setAvailable(1);
        //状态 01 新建 02已通过
        info.setStatus("01");
        info.setCreatedDate(new Date());
        String token = request.getHeader("token");
        try {
            Map<String, Object> map = JwtUtil.parseAppToken(token);
            String memberId = map.get("memberId") == null ? "" : map.get("memberId").toString();
            log.info("当前app登录人id:" + memberId);
            //发送人id
            info.setUserId(memberId);
            //如果发送日期为空，默认为当前日期
            if (null == info.getSendDate()) {
                info.setSendDate(new Date());
            }
            //判断是否有正在申请中的信息
            Map<String,String> map1=new HashMap<String,String>();
            map1.put("sendMemberId",memberId);
            //收信息人id
            map1.put("memberId",info.getReceiveUserId());
            map1.put("messageType","02");
            map1.put("status","01");
            List<Message> messageList=this.messageService.selectMessageList(map1);
            if(messageList!=null&&messageList.size()>0){
                json.put("success",false);
                json.put("message","已经在申请中，请等待");
                return json.toJSONString();
            }
            int i = this.messageService.insertSelective(info);
            if (i > 0) {
                if(info.getMessageType().equals("02")){
                    //更新个人申请访问状态
                    List<KithAndKin> list = kithAndKinService.selectKithListByPara(info.getUserId(), info.getReceiveUserId(), null, "1");
                    if (list != null && list.size() > 0) {
                        KithAndKin kin = list.get(0);
                        if (kin != null) {
                            KithAndKin updateKin=new KithAndKin();
                            updateKin.setKinId(kin.getKinId());
                            updateKin.setAccessNick(1); //申请访问
                            int t = this.kithAndKinService.updateByPrimaryKeySelective(updateKin);
                            if(t>0){
                                //申请访问增加消息推送
                                MemberExtend extend=this.memberExtendService.selectByPrimaryKey(memberId);
                                String sender="";
                                if(extend!=null&&extend.getName()!=null){
                                    sender=extend.getName();
                                }else{
                                    Members members=membersService.selectByPrimaryKey(memberId);
                                    if(members!=null){
                                        sender=members.getPhone();
                                    }
                                }
                                String title="申请访问通知";
                                String msg=sender+"申请访问您的信息";
                                String res=pushMessageService.pushMessageToOne(info.getReceiveUserId(),title,msg);
                                log.info("推送返回:"+res);
                            }
                        }
                    }
                }

                json.put("messageId", uId);
                json.put("success", true);
                json.put("message", "增加成功");
            } else {
                json.put("messageId", "");
                json.put("success", false);
                json.put("message", "增加失败");
            }
        }catch(Exception ex){
            throw new ServiceException("增加出现异常",ex);
        }
        return json.toJSONString();
    }

    /**
     * 查询消息方法
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryMessageInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryMessageInfo(HttpServletRequest request) {
        log.info("进入querySelyMessageInfo方法");
        //接收人id
        String memberId = request.getParameter("memberId");
        //消息类型
        String messageType = request.getParameter("messageType");
        //消息状态
        String status = request.getParameter("status");
        //消息开始时间
        String startDate = request.getParameter("startDate");
        //消息结束时间
        String endDate = request.getParameter("endDate");

        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        Map<String, String> map = new HashMap<String, String>();
        map.put("memberId", memberId);
        map.put("messageType", messageType);
        map.put("status", status);
        map.put("startDate", startDate);
        map.put("endDate", endDate);
        List<Message> list = new ArrayList<Message>();
        try {
            list = messageService.selectMessageList(map);
            //循环遍历 增加用户头像id
            if(list!=null&&list.size()>0){
                String contentId="";
                for(Message info:list){
                    //查询个人头像
                    List<Content> contentList=this.contentService.selectContentsById(info.getUserId(),"tbl_members","1001");
                    if(contentList!=null&&contentList.size()>0){
                        contentId=contentList.get(0).getContentId();
                         info.setMemberContentId(contentId);
                    }
                }
            }
        }catch(Exception ex){
            throw new ServiceException("查询异常",ex);
        }
        dataJson.put("list", list);
        json.put("data", dataJson);
        json.put("success", true);
        json.put("message", "查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * 修改消息状态方法
     * @param messageId 消息id
     * @param status  状态 01新建 02通过 03 拒绝
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateMessageInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String updateMessageInfo(String messageId,String status) {
        log.info("进入updateMessageInfo方法"+status+"-----messageId:"+messageId);
        JSONObject json = new JSONObject();
        if (null == messageId || null == status) {
            json.put("success", false);
            json.put("message", "参数不正确");
            return json.toJSONString();
        }
        //判定消息是否存在
        try {
            Message m1 = this.messageService.selectByPrimaryKey(messageId);
            if (m1 == null) {
                json.put("success", false);
                json.put("message", "对应消息不存在");
                return json.toJSONString();
            }
            //进行更新操作
            Message message = new Message();
            message.setMessageId(messageId);
            message.setStatus(status);
            message.setUpdatedDate(new Date());
            int i = this.messageService.updateByPrimaryKeySelective(message);
            if (i > 0) {
                log.info("更新消息状态成功" + status);
                String title="";
                String msg="";
                String recieveId=m1.getUserId(); //推送接收人id
                boolean sendInfo=false; //是否推送消息
                 //若是添加好友消息，更新亲友关系为有效,同时插入一条反向亲友关系
                if ("01".equals(m1.getMessageType())) {
                    List<KithAndKin> list = kithAndKinService.selectKithListByPara(m1.getUserId(), m1.getReceiveUserId(), null, "0");
                    if (list != null && list.size() > 0) {
                        KithAndKin kin = list.get(0);
                        if (kin != null) {
                            //本人信息
                            MemberExtend extend=this.memberExtendService.selectByPrimaryKey(m1.getReceiveUserId());
                            String sender="";
                            if(extend!=null&&extend.getName()!=null){
                                sender=extend.getName();
                            }else{
                                Members members=membersService.selectByPrimaryKey(m1.getReceiveUserId());
                                if(members!=null){
                                    sender=members.getPhone();
                                }
                            }
                            if("02".equals(status)){
                            kin.setAvailable(1);
                            int t = this.kithAndKinService.updateByPrimaryKeySelective(kin);
                            if (t > 0) {
                                log.info(kin.getKinId() + "更新亲友关系为有效成功");
                                //插入反向亲友关系
                                KithAndKin newKin=new KithAndKin();
                                newKin.setKinId(UUID.randomUUID().toString());
                                newKin.setMemberId(kin.getNickMemberId());
                                newKin.setNickMemberId(kin.getMemberId());
                                MemberExtend mm=this.memberExtendService.selectByPrimaryKey(kin.getMemberId());
                                newKin.setNickName(mm.getName());
                                newKin.setAllowAccess(0);//插入默认状态
                                newKin.setSpecialConcern(0);
                                newKin.setAccessNick(0);
                                newKin.setAvailable(1);
                                newKin.setCreatedDate(new Date());
                                int j=this.kithAndKinService.insertSelective(newKin);
                                if(j>0){
                                    log.info("插入反向亲友关系成功");
                                }
                                title="好友申请通过通知";
                                msg=sender+"通过了你的好友申请";
                                sendInfo=true;
                            }
                            }else  if("03".equals(status)){
                               //拒绝
                               title="好友申请拒绝通知";
                               msg=sender+"拒绝了你的好友申请";
                               sendInfo=true;
                           }
                        }
                    }
                }
                //申请访问通过
                if ("02".equals(m1.getMessageType())) {
                    List<KithAndKin> list = kithAndKinService.selectKithListByPara(m1.getReceiveUserId(),m1.getUserId(), null, "1");
                    if (list != null && list.size() > 0) {
                        KithAndKin kin = list.get(0);
                        if (kin != null) {
                         MemberExtend extend=this.memberExtendService.selectByPrimaryKey(m1.getReceiveUserId());
                         String sender="";
                           if(extend!=null&&extend.getName()!=null){
                               sender=extend.getName();
                           }else{
                               Members members=membersService.selectByPrimaryKey(m1.getReceiveUserId());
                               if(members!=null){
                                   sender=members.getPhone();
                               }
                         }
                         if("02".equals(status)){
                                KithAndKin upKin=new KithAndKin();
                                upKin.setKinId(kin.getKinId());
                                upKin.setAllowAccess(1);
                                int t = this.kithAndKinService.updateByPrimaryKeySelective(upKin);
                                if (t > 0) {
                                    log.info(kin.getKinId() + "更新可以申请访问字段有效成功");
                             }
                            title="申请访问通过通知";
                            msg=sender+"通过了你的申请访问";
                            sendInfo=true;
                        }else if("03".equals(status)){
                            title="申请访问拒绝通知";
                            msg=sender+"拒绝了你的申请访问";
                            sendInfo=true;
                        }
                        }
                    }
                }
                if(sendInfo){
                    //推送成功
                    String res=pushMessageService.pushMessageToOne(recieveId,title,msg);
                    log.info("推送返回:"+res);
                }
                json.put("success", true);
                json.put("message", "更新成功");
            } else {
                json.put("success", true);
                json.put("message", "更新失败");
            }
        } catch (Exception ex) {
            throw new ServiceException("更新异常",ex);
        }
        return json.toJSONString();

    }
}
