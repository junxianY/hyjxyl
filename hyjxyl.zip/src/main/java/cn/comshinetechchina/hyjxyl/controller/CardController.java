package cn.comshinetechchina.hyjxyl.controller;

import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.service.*;
import cn.comshinetechchina.hyjxyl.service.CardTypeService;
import cn.comshinetechchina.hyjxyl.util.DateUtil;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import cn.comshinetechchina.hyjxyl.util.RegexUtils;
import cn.comshinetechchina.hyjxyl.util.ToolUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.hibernate.boot.jaxb.SourceType;
import org.junit.platform.commons.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.util.*;

/**
 * 卡控制层
 * Author:yjx
 */
@RestController
@RequestMapping("/cardController")
public class CardController extends BaseController {
    private static final Logger log = LoggerFactory.getLogger(CardController.class);

    @Resource
    private CardService cardService;
    @Resource
    private MembersService membersService;
    @Resource
    private TblLogService logService;
    @Resource
    private CardTypeService cardTypeService;
    @Resource
    private CardLeftNumberService cardLeftNumberService;
    @Resource
    private CardLeftNumberHistoryService cardLeftNumberHistoryService;
    @Resource
    private MemberExtendService memberExtendService;
    @Resource
    private CardChangeRecordService cardChangeRecordService;
    @Resource
    private TblServiceService tblServiceService;
    @Resource
    private SaleAccountService saleAccountService;
    /**
     * 增加卡信息方法（绑卡接口）
     * @param card
     * @param memberId  客户id
     * @param saleAccount 服务专员
     * @param idNo 身份证号
     * @param remark  备注
     * @param cardReference 卡推荐人
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/addCardInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String addCardInfo(Card card,String memberId,String saleAccount,String idNo,String remark,String cardReference,HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject jsonData = new JSONObject();
        if (null==memberId||null == card||null==card.getCardNo()||StringUtils.isBlank(card.getCardTypeId())||StringUtils.isBlank(idNo)) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //校验该卡是否库里存在
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardNo",card.getCardNo());
        List<CardObj> list=this.cardService.selectCardList(map);
        if(list!=null&&list.size()>0){
            json.put("success", false);
            json.put("message", "该卡已被绑定，请选用其他卡");
            return json.toJSONString();
        }
        //校验身份证号
        if(RegexUtils.checkIdCard(idNo)==false){
            json.put("success", false);
            json.put("message", "身份证号格式错误");
            return json.toJSONString();
        }
        try {
        //1.新增卡信息
        String uId=UUID.randomUUID().toString();
        card.setCardId(uId);
        card.setAvailable(1);
        card.setCreatedDate(new Date());
        card.setStatus(1); //卡状态默认0 绑卡之后为1  挂失解绑后 为-1
        StringBuffer content=new StringBuffer("绑定新卡片:"+card.getCardNo()+",卡面卡号:"+card.getFaceNo());
        if(card.getCardTypeId()!=null){
            CardType type=cardTypeService.selectByPrimaryKey(card.getCardTypeId());
            content.append(",卡类型:"+type.getName());
        }
        if(card.getTimeLimit()!=null){
            //计算卡有效期
            card.setFromDate(new Date());
            if(0==card.getTimeLimit()){
                card.setEndDate(DateUtil.getSysDate(0, 6, 0));
                content.append(",有效期：半年");
            }else if(1==card.getTimeLimit()){
                card.setEndDate(DateUtil.getSysDate(1, 0, 0));
                content.append(",有效期：一年");
            }
        }
        int i = this.cardService.insertSelective(card);
        jsonData.put("cardId",uId);
        json.put("data", jsonData);
        if (i > 0) {
            if(card.getCardTypeId()!=null){
                //2.进行绑卡操作，生成卡服务剩余次数信息
                int j=cardService.bindCard(card.getCardNo(),card.getCardTypeId(),card.getTimeLimit(),null,null);
                if(j>0){
                    log.info("卡绑定信息成功");
                }
                //3.客户表绑定卡号和客服专员
                Members members=new Members();
                members.setMemberId(memberId);
                members.setCardId(uId);
                if(StringUtils.isNotBlank(saleAccount)){
                    members.setSaleAccount(saleAccount);
                    SaleAccount saleAccount1=this.saleAccountService.selectByPrimaryKey(saleAccount);
                    if(saleAccount1!=null){
                        content.append(",服务专员："+saleAccount1.getName());
                    }
                }
                if(StringUtils.isNotBlank(cardReference)){
                    members.setCardReference(cardReference);
                    content.append(",办卡推荐人："+cardReference);
                }
                if(StringUtils.isNotBlank(remark)){
                    members.setRemark(remark);
                    content.append(",备注："+remark);
                }
                members.setUpdatedDate(new Date());
                int t=this.membersService.updateByPrimaryKeySelective(members);
                //4.客户扩展表绑定身份证号
                MemberExtend extend=new MemberExtend();
                extend.setMemberId(memberId);
                extend.setIdNo(idNo);
                this.memberExtendService.updateByPrimaryKeySelective(extend);

                //5.插入卡记录表 add 2018.11.27
                CardChangeRecord ccr=new CardChangeRecord();
                ccr.setRecordId(UUID.randomUUID().toString());
                ccr.setCardNo(card.getCardNo());
                ccr.setChangeTime(new Date());
                ccr.setMemberId(memberId);
                int t1=cardChangeRecordService.insertSelective(ccr);
                if(t1>0){
                    log.info("插入个人卡变更记录表成功");
                }
                if(t>0&&j>0){
                    //6.插入日志表
                    TblLog record=new TblLog();
                    record.setLogId(UUID.randomUUID().toString());
                    record.setOperateTime(new Date());
                    record.setOperateContent(content.toString());
                    record.setOperateTableId(uId);
                    record.setOperateTableName("tbl_cards");
                    record.setType(1);
                    String token = request.getHeader("token");
                    Map<String, Object> map1 = JwtUtil.parseManagementToken(token);
                    String userId = map1.get("uid") == null ? "" : map1.get("uid").toString();
                    String userName = map1.get("userName") == null ? "" : map1.get("userName").toString();
                    record.setUserId(userId);
                    record.setUserName(userName);
                    record.setComments(memberId);
                    this.logService.insertSelective(record);

                    json.put("success", true);
                    json.put("message", "操作成功");
                }else{
                    json.put("success", false);
                    json.put("message", "更新关联关系失败");
                }
            }
        } else {
            json.put("success", false);
            json.put("message", "插入数据失败");
        }
        }catch(Exception ex){
          throw new ServiceException(ex,"操作异常");
        }
        return json.toJSONString();
    }

    /**
     * 更新卡信息方法
     * @param card
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateCardInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String updateCardInfo(Card card) {
        JSONObject json = new JSONObject();
        if (null == card || card.getCardId() == null) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        card.setUpdatedDate(new Date());
        try {
            int i = this.cardService.updateByPrimaryKeySelective(card);
            if (i > 0) {
                json.put("success", true);
                json.put("message", "成功");
            } else {
                json.put("success", false);
                json.put("message", "修改失败");
            }
        }catch (Exception ex) {
            throw new ServiceException("查询异常",ex);
        }
        return json.toJSONString();
    }

    /**
     * 删除卡信息方法
     * @param cardId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/delCardById", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String delCardById(String cardId) {
        JSONObject json = new JSONObject();
        if (null == cardId) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        int i = this.cardService.deleteByPrimaryKey(cardId);
        if (i > 0) {
            json.put("success", true);
            json.put("message", "成功");
        } else {
            json.put("success", false);
            json.put("message", "删除失败");
        }
        return json.toJSONString();
    }

    /**
     * 查询一卡通列表(没用)
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryCardsInfo", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public String queryCardsInfo(HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        String cardNo=request.getParameter("cardNo");
        //卡类型id
        String cardTypeId=request.getParameter("cardTypeId");
        //卡有效开始日期
        String startDate=request.getParameter("startDate");
        //卡有效结束日期
        String endDate=request.getParameter("endDate");
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("cardNo",cardNo);
        map.put("cardTypeId",cardTypeId);
        map.put("startDate",startDate);
        map.put("endDate",endDate);
        List<CardObj> list=new ArrayList<CardObj>();
        try {
            list = this.cardService.selectCardList(map);
        }catch(Exception ex){
            throw new ServiceException("查询失败",ex);
        }
        dataJson.put("list", list);
        json.put("data",dataJson);
        json.put("success", true);
        json.put("message", "查询成功");
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
    /**
     * 绑定卡种类接口(暂时没用)
     * @param cardNo    卡编号
     * @param cartTypeId 卡类型id
     * @param timeLimit  期限 0半年 1一年
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/bindCardType", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String bindCardType(String cardNo,String cartTypeId,Integer timeLimit) {
        JSONObject json = new JSONObject();
        if (null == cardNo||null==cartTypeId) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        int i=cardService.bindCard(cardNo,cartTypeId,timeLimit,null,null);
        if(i>0){
            json.put("success", true);
            json.put("message", "绑定成功");
        }else{
            json.put("success", false);
            json.put("message", "绑定失败");
        }
        return json.toJSONString();
    }
    /**
     * 更换卡编号方法
     * @param request
     * @param cardNo
     * @param memberId 客户id
     * @param faceNo 卡面卡号
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/changeCardNO", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String changeCardNO(HttpServletRequest request,String cardNo,String memberId,String faceNo) {
        log.info("进入changeCardNO方法");
        JSONObject json = new JSONObject();
        if (StringUtils.isBlank(memberId)||StringUtils.isBlank(cardNo)) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //校验该卡是否库里存在
        Map<String,Object> map1=new HashMap<String,Object>();
        map1.put("cardNo",cardNo);
        List<CardObj> list=this.cardService.selectCardList(map1);
        if(list!=null&&list.size()>0){
            json.put("success", false);
            json.put("message", "该卡已被绑定，请选用其他卡");
            return json.toJSONString();
        }
        String token = request.getHeader("token");
        String json1="";
        try {
            Map<String, Object> map = JwtUtil.parseManagementToken(token);
            String userId = map.get("uid") == null ? "" : map.get("uid").toString();
            String userName = map.get("userName") == null ? "" : map.get("userName").toString();
            String ip=ToolUtil.getIpAddr(request);
            log.info("当前后台登录人id:" + userId);
            json1 = this.cardService.changeCard(memberId,cardNo,faceNo,userId,userName,ip);
        }catch(Exception ex){
            throw new ServiceException("更新异常",ex);
        }
        return json1;
    }

    /**
     * 解绑卡接口,挂失
     * @param cardNo 卡号
     * @param memberId 客户id
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/removeCardBind", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String removeCardBind(String cardNo,String memberId,HttpServletRequest request){
        log.info("进入removeCardBind方法");
        JSONObject json = new JSONObject();
        if (StringUtils.isBlank(memberId)||StringUtils.isBlank(cardNo)) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        String token = request.getHeader("token");
        String json1="";
        try {
            Map<String, Object> map = JwtUtil.parseManagementToken(token);
            String userId = map.get("uid") == null ? "" : map.get("uid").toString();
            String userName = map.get("userName") == null ? "" : map.get("userName").toString();
            log.info("当前后台登录人id:" + userId);
            json1 = this.cardService.removeCardBind(memberId);
            JSONObject obj = JSONObject.parseObject(json1);
            if (obj.getBoolean("success")) {
                //成功的话插入日志
                TblLog record = new TblLog();
                record.setLogId(UUID.randomUUID().toString());
                record.setUserId(userId);
                record.setUserName(userName);
                record.setUserIp(ToolUtil.getIpAddr(request));
                record.setOperateTableName("tbl_members");
                record.setOperateTableId(memberId);
                record.setOperateContent("解绑卡号:"+cardNo);
                record.setOperateTime(new Date());
                record.setComments(memberId); //备注为客户id
                record.setType(4); //4解绑
                logService.insertSelective(record);
            }
        }catch(Exception ex){
            throw new ServiceException("更新异常",ex);
        }
        return json1;
    }

    /**
     * 查询个人一卡通信息
     * @param memberId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/querySelfCardInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String querySelfCardInfo(String memberId){
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if (StringUtils.isBlank(memberId)) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        //查询个人卡编号
        String cardNo = "";
        String cardTypeName = "";
        String cardTypeId="";
        String formDate="";
        String endDate="";
        String faceNo="";//卡面卡号
        Members member = this.membersService.selectByPrimaryKey(memberId);
        if (member != null && member.getCardId() != null) {
            Card card = this.cardService.selectByPrimaryKey(member.getCardId());
            if (card != null) {
                cardNo = card.getCardNo();
                faceNo=card.getFaceNo();
                try {
                    if(card.getEndDate()!=null){
                        endDate= DateUtil.transferDate2Str(card.getEndDate(), "yyyy-MM-dd");
                    }
                    if(card.getEndDate()!=null){
                        formDate=DateUtil.transferDate2Str(card.getFromDate(), "yyyy-MM-dd");
                    }
                }catch(ParseException ex){
                  throw new ServiceException("强转失败",ex);
                }
                //查询卡种类
                if (card.getCardTypeId() != null) {
                    CardType cardType = cardTypeService.selectByPrimaryKey(card.getCardTypeId());
                    cardTypeName = cardType.getName();
                    cardTypeId=cardType.getCardTypeId();
                }
            }
        }
        dataJson.put("cardNo", cardNo);
        dataJson.put("faceNo", faceNo);
        dataJson.put("cardTypeName", cardTypeName);
        dataJson.put("cardTypeId", cardTypeId);
        dataJson.put("formDate", formDate);
        dataJson.put("endDate", endDate);
        MemberInfo mInfo=this.membersService.selectMemberInfoDetail(memberId);
        dataJson.put("memberInfo",mInfo);
        dataJson.put("saleAccount", member.getSaleAccount());
        dataJson.put("remark", member.getRemark());
        dataJson.put("cardReference", member.getCardReference());
        //查询卡各服务剩余次数
        List<CardLeftNumber> leftList = new ArrayList<CardLeftNumber>();
        if (StringUtils.isNotBlank(cardNo)) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("cardNo", cardNo);
            map.put("available", 1);
            leftList = this.cardLeftNumberService.selectCardLeftNumberList(map);
        }
        dataJson.put("list", leftList);
        json.put("success", true);
        json.put("message", "查询成功");
        json.put("data", dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 变更卡剩余服务次数接口(暂时没用)
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/modifyCardLeftNumber", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String modifyCardLeftNumber(HttpServletRequest request){
        JSONObject json = new JSONObject();
        String cardNo=request.getParameter("cardNo");
        String serviceId=request.getParameter("serviceId");
        String newNum=request.getParameter("newNum");
        if(StringUtils.isBlank(cardNo)||StringUtils.isBlank(serviceId)||StringUtils.isBlank(newNum)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        //备注
        String remark=request.getParameter("remark");
        int newLeftNum=0;
        if(StringUtils.isNotBlank(newNum)){
            newLeftNum=Integer.parseInt(newNum);
        }
        String token = request.getHeader("token");
        Map<String, Object> map = null;
        String userId=null;
        try {
            map = JwtUtil.parseManagementToken(token);
            userId = map.get("uid") == null ? "" : map.get("uid").toString();
            log.info("当前后台登录人userId:" + userId);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        int i=this.cardLeftNumberService.modifyCardLeftNumber(cardNo,serviceId,newLeftNum,userId,remark);
        if(i>0){
            json.put("success", true);
            json.put("message", "修改成功");
        }else{
            json.put("success",false);
            json.put("message","修改失败");
            return json.toJSONString();
        }
      return json.toJSONString();
    }

    /**
     * 批量禁用、启用卡状态接口
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/changeCardState", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String changeCardState(HttpServletRequest request){
        JSONObject json=new JSONObject();
        //所有卡编号
        String cardNos=request.getParameter("cardNos");
        //卡状态 1启用 0禁用
        String available=request.getParameter("available");
        //备注
        String remark=request.getParameter("remark");
        String token = request.getHeader("token");
        log.info("changeCardState方法：cardNos-----"+cardNos+"---available"+available+"--token:"+token);
        if(StringUtils.isBlank(cardNos)||StringUtils.isBlank(available)){
          json.put("success",false);
          json.put("message","参数错误");
          return json.toJSONString();
        }else{
            //available 必须为0 1
            if(!("1".equals(available)||"0".equals(available))){
                json.put("success",false);
                json.put("message","参数错误");
                return json.toJSONString();
            }
        }
        try {
            String[] nos = null;
            if (cardNos.indexOf(",") != -1) {
                nos = cardNos.split(",");
            } else {
                nos = new String[1];
                nos[0] = cardNos;
            }
            if (nos != null) {
                List<String> list = new ArrayList<String>();
                for (String cardNo : nos) {
                    list.add(cardNo);
                }
                if (!list.isEmpty()) {
                    Map<String, Object> map = JwtUtil.parseManagementToken(token);
                    String userId = map.get("uid") == null ? "" : map.get("uid").toString();
                    log.info("当前后台登录人id:" + userId);
                    String userName = map.get("userName") == null ? "" : map.get("userName").toString();
                    log.info("当前后台登录人userName:" + userName);
                    int i = this.cardService.batchUpdateCardStatus(list, Integer.parseInt(available), remark, userId, userName);
                    if (i > 0) {
                        json.put("success", true);
                        json.put("message", "操作成功");
                    } else {
                        json.put("success", false);
                        json.put("message", "操作失败");
                    }
                }
            }
        }catch(Exception ex){
            throw new ServiceException("更新出错",ex);
        }
        return json.toJSONString();
    }

    /**
     * 修改卡信息接口  可以修改卡类型、服务、服务次数、有效期
     * @param bean
     * @param request
     * @return
     * @throws ParseException
     */
    @ResponseBody
    @RequestMapping(value = "/updateMemberCardInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String updateMemberCardInfo(@RequestBody NewCardBean bean, HttpServletRequest request) throws ParseException {
        log.info("进入cardTypeBindService方法"+bean.getMemberId());
        JSONObject json = new JSONObject();
        JSONObject changeDetail=new JSONObject();
        if (null==bean||StringUtils.isBlank(bean.getMemberId())) {
            json.put("success", false);
            json.put("message", "参数不能为空");
            return json.toJSONString();
        }
        if (bean.getServices().size()<=0) {
            json.put("success", false);
            json.put("message", "服务不能为空");
            return json.toJSONString();
        }
        String token = request.getHeader("token");
        Map<String, Object> map = null;
        String userId="";
        String userName ="";
        try {
            map = JwtUtil.parseManagementToken(token);
            userId = map.get("uid") == null ? "" : map.get("uid").toString();
            userName=map.get("userName") == null ? "" : map.get("userName").toString();
            log.info("当前后台登录人userId:" + userId);
        } catch (ParseException e) {
            log.error(e.getMessage());
        }
        //记录操作前信息
        NewCardBean oldCardBean=new NewCardBean();
        oldCardBean.setCardNo(bean.getCardNo());
        oldCardBean.setFaceNo(bean.getFaceNo());
        oldCardBean.setMemberId(bean.getMemberId());
        StringBuffer operateContent=new StringBuffer("编辑操作:");
        String cardId="";
        try {
            if (StringUtils.isNotBlank(bean.getCardTypeId())) {
                //对比卡类型是否改变
                Members member = this.membersService.selectByPrimaryKey(bean.getMemberId());
                if (member != null && member.getCardId() != null) {
                    oldCardBean.setCardReference(member.getCardReference());
                    oldCardBean.setRemark(member.getRemark());
                    oldCardBean.setSaleAccount(member.getSaleAccount());
                    Card card = this.cardService.selectByPrimaryKey(member.getCardId());
                    if (card != null) {
                        cardId=card.getCardId();
                        operateContent.append("变更前卡号:"+card.getCardNo()+",卡面卡号:"+card.getFaceNo());
                        String oldCardTypeId=card.getCardTypeId();
                        CardType oldCardType=this.cardTypeService.selectByPrimaryKey(oldCardTypeId);
                        if(oldCardType!=null){
                            operateContent.append(",卡类别:"+oldCardType.getName());
                        }
                        oldCardBean.setCardTypeId(oldCardTypeId);
                        if(card.getEndDate()!=null){
                           String endDate= DateUtil.transferDate2Str(card.getEndDate(), "yyyy-MM-dd");
                            oldCardBean.setEndDate(endDate);
                        }

                        if(card.getTimeLimit()==1){
                            operateContent.append(",有效期一年");
                        }else if(card.getTimeLimit()==0){
                            operateContent.append(",有效期半年");
                        }
                        if(StringUtils.isNotBlank(member.getSaleAccount())){
                            SaleAccount saleAccount=this.saleAccountService.selectByPrimaryKey(member.getSaleAccount());
                            if(saleAccount!=null){
                                operateContent.append(",服务专员:"+saleAccount.getName());
                            }
                        }
                        if(StringUtils.isNotBlank(member.getCardReference())){
                            operateContent.append(",办卡推荐人:"+member.getCardReference());
                        }
                        if(StringUtils.isNotBlank(member.getRemark())){
                            operateContent.append(",备注:"+member.getRemark());
                        }
                        Map<String,Object> para=new HashMap<>();
                        para.put("cardNo",card.getCardNo());
                        para.put("available","1");
                        List<CardLeftNumber> leftNumberList=this.cardLeftNumberService.selectCardLeftNumberList(para);
                        List<cn.comshinetechchina.hyjxyl.domain.CardTypeService> cardTypeServicesList=new  ArrayList<>();
                        cn.comshinetechchina.hyjxyl.domain.CardTypeService cardTypeService1=null;
                        if(leftNumberList!=null&&leftNumberList.size()>0){
                            for(CardLeftNumber number:leftNumberList){
                                cardTypeService1=new cn.comshinetechchina.hyjxyl.domain.CardTypeService();
                                cardTypeService1.setServiceId(number.getServiceId());
                                cardTypeService1.setServiceName(number.getServiceName());
                                cardTypeService1.setTotalCount(number.getLeftNumber());
                                cardTypeService1.setType(number.getServiceType());
                                cardTypeServicesList.add(cardTypeService1);
                                oldCardBean.setServices(cardTypeServicesList);

                                operateContent.append(",服务名称:"+number.getServiceName());
                                operateContent.append(number.getLeftNumber()+"次");
                            }
                        }

                        //变更后日志
                        operateContent.append(";变更后：卡号："+bean.getCardNo());
                        if(StringUtils.isNotBlank(bean.getFaceNo())){
                            operateContent.append(",卡面卡号："+bean.getFaceNo());
                        }else{
                            operateContent.append(",卡面卡号："+card.getFaceNo());
                        }
                        CardType newCardType=this.cardTypeService.selectByPrimaryKey(bean.getCardTypeId());
                        if(newCardType!=null){
                            operateContent.append(",卡类别:"+newCardType.getName());
                        }
                        if(card.getTimeLimit()==1){
                            operateContent.append(",有效期一年");
                        }else if(card.getTimeLimit()==0){
                            operateContent.append(",有效期半年");
                        }
                        if(StringUtils.isNotBlank(bean.getSaleAccount())){
                            SaleAccount saleAccount=this.saleAccountService.selectByPrimaryKey(bean.getSaleAccount());
                            if(saleAccount!=null){
                                operateContent.append(",服务专员:"+saleAccount.getName());
                            }
                        }
                        if(StringUtils.isNotBlank(bean.getCardReference())){
                            operateContent.append(",办卡推荐人:"+bean.getCardReference());
                        }
                        if(StringUtils.isNotBlank(bean.getRemark())){
                            operateContent.append(",备注:"+bean.getRemark());
                        }
                        if(bean.getServices()!=null&&bean.getServices().size()>0){
                            for(cn.comshinetechchina.hyjxyl.domain.CardTypeService typeService:bean.getServices()){
                                TblService service=this.tblServiceService.selectByPrimaryKey(typeService.getServiceId());
                                operateContent.append(",服务名称:"+service.getName());
                                operateContent.append(typeService.getTotalCount()+"次");
                            }
                        }
                        Date sDate = null;
                        Date eDate = null;
                        //有效期
                        if (bean.getStartDate() != null) {
                            sDate = DateUtil.transferStr2Date(bean.getStartDate(), "yyyy-MM-dd");
                            card.setFromDate(sDate);
                        }
                        if (bean.getEndDate() != null) {
                            eDate = DateUtil.transferStr2Date(bean.getEndDate(), "yyyy-MM-dd");
                            card.setEndDate(eDate);
                        }
                        card.setCardTypeId(bean.getCardTypeId());
                        card.setFaceNo(bean.getFaceNo());//卡面卡号
                        card.setUpdatedDate(new Date());
                        int i = this.cardService.updateByPrimaryKeySelective(card);
                        if (i > 0) {
                            log.info(bean.getCardNo() + "更新卡信息成功");
                            if (oldCardTypeId.equals(bean.getCardTypeId())) {
                                //若是卡类型没改变的情况
                                //判断其下服务
                                List<cn.comshinetechchina.hyjxyl.domain.CardTypeService> list = bean.getServices();
                                //循环更新服务次数
                                if (list != null && list.size() > 0) {
                                    int totalUpdate = 0;
                                    for (cn.comshinetechchina.hyjxyl.domain.CardTypeService obj : list) {
                                        int j = this.cardLeftNumberService.modifyCardLeftNumber(bean.getCardNo(), obj.getServiceId(), obj.getTotalCount(), userId, "");
                                        totalUpdate += j;
                                        TblService service=this.tblServiceService.selectByPrimaryKey(obj.getServiceId());
                                        obj.setType(service.getType());
                                        obj.setServiceName(service.getName());
                                    }
                                    log.info("卡编号：" + bean.getCardNo() + "总更新了" + totalUpdate + "种服务次数");
                                }
                            } else {
                                //卡类型也改变：1.修改旧的卡剩余次数状态置为无效 2.旧的整体移进历史表 3.删除旧的 4插入新的
                                int t = this.cardLeftNumberService.updateLeftNumberAvailable(bean.getCardNo());
                                int t1=cardLeftNumberHistoryService.moveCardLeftNumber(bean.getCardNo(),null);
                                if(t1>0){
                                    int t2=this.cardLeftNumberService.deleteInfoByPara(bean.getCardNo());
                                    if(t2>0){
                                        int j = cardService.bindCard(bean.getCardNo(), bean.getCardTypeId(), 5, sDate, eDate);
                                        if (j > 0) {
                                            log.info(bean.getCardNo()+"卡绑定新服务信息成功");
                                        }else{
                                            log.info(bean.getCardNo()+"绑定新服务失败");
                                        }
                                    }else{
                                        log.info(bean.getCardNo()+"刪除旧的卡剩余次数失败");
                                    }
                                }

                            }
                        }
                    }
                }
                //若客户专员不为空 更新
                if (bean.getSaleAccount() != null) {
                    member.setSaleAccount(bean.getSaleAccount());
                    member.setUpdatedDate(new Date());
                    if(StringUtils.isNotBlank(bean.getRemark())){
                        member.setRemark(bean.getRemark());
                    }
                    if(StringUtils.isNotBlank(bean.getCardReference())){
                        member.setCardReference(bean.getCardReference());
                    }
                    int i = this.membersService.updateByPrimaryKeySelective(member);
                    if(i>0){
                        log.info("更新用户："+bean.getMemberId()+"客户专员为"+bean.getSaleAccount()+"成功");
                    }
                }

                //插入日志表
                TblLog record=new TblLog();
                record.setLogId(UUID.randomUUID().toString());
                record.setOperateTime(new Date());
                record.setOperateContent(operateContent.toString());
                record.setOperateTableId(cardId);
                record.setOperateTableName("tbl_cards");
                record.setUserId(userId);
                record.setUserName(userName);
                record.setComments(bean.getMemberId());
                changeDetail.put("oldInfo",oldCardBean);
                changeDetail.put("newInfo",bean);
                record.setChangeDetail(changeDetail.toJSONString());
                record.setType(2); //变更操作
                int k=this.logService.insertSelective(record);
                if(k>0){
                    System.out.println("编辑卡插入日志成功:"+operateContent.toString());
                }
            }
            json.put("success", true);
            json.put("message", "成功");
        }catch(Exception ex){
            throw new ServiceException("操作失败",ex);
        }
        return json.toJSONString();
    }
    /**
     * 根据条件查询一卡通列表方法
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryCardMemberList", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryCardMemberList(HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        //卡编号或者手机号或者姓名
        String cardNo = request.getParameter("cardNo");
        //省份
        String provinceId = request.getParameter("provinceId");
        //城市id
        String cityId = request.getParameter("cityId");
        //区域id
        String areaId = request.getParameter("areaId");
        //租户id
        String tenantId = request.getParameter("tenantId");
        //注册起始日
        String registerStr = request.getParameter("registerStr");
        //注册结束日
        String registerEnd = request.getParameter("registerEnd");
        //小区名
        String areaName = request.getParameter("areaName");
        //卡类型id
        String cardTypeId = request.getParameter("cardTypeId");
        String pageSize = request.getParameter("pageSize") == null ? "10" : request.getParameter("pageSize");
        String pageIndex = request.getParameter("pageIndex") == null ? "0" : request.getParameter("pageIndex");
        //状态
        String state = request.getParameter("state");
        //服务专员
        String saleAccount = request.getParameter("saleAccount");
        //卡面卡号
        String faceNo = request.getParameter("faceNo");
        Map<String, String> map = new HashMap<String, String>();
        map.put("cardNo", cardNo);
        map.put("provinceId", provinceId);
        map.put("cityId", cityId);
        map.put("areaId", areaId);
        map.put("tenantId", tenantId);
        map.put("registerStr", registerStr);
        map.put("registerEnd", registerEnd);
        map.put("state", state);
        map.put("cardTypeId", cardTypeId);
        map.put("areaName", areaName);
        map.put("saleAccount", saleAccount);
        map.put("faceNo", faceNo);
        List<MemberInfo> list = new ArrayList<>();
        int totalCount = 0;
        //需要分页
        PageBean bean = new PageBean();
        if (org.apache.commons.lang3.StringUtils.isNotBlank(pageSize)) {
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (org.apache.commons.lang3.StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        try {
            list = this.cardService.selectCardMemberList(map, bean);
            totalCount = bean.getTotalRows();
        } catch (Exception ex) {
            throw new ServiceException("查询异常", ex);
        }
        dataJson.put("totalCount", totalCount);
        dataJson.put("list", list);
        dataJson.put("pageIndex", pageIndex);
        dataJson.put("pageSize", pageSize);
        json.put("success", true);
        json.put("message", "成功");
        json.put("data", dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 查询卡记录信息
     * @param memberId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/queryCardLog", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String queryCardLog(String memberId,HttpServletRequest request) {
        JSONObject json = new JSONObject();
        JSONObject dataJson = new JSONObject();
        if(StringUtils.isBlank(memberId)){
            json.put("success",false);
            json.put("msg","参数不能为空");
            return json.toJSONString();
        }
        //当前页码
        String pageIndex=request.getParameter("pageIndex")==null?"0":request.getParameter("pageIndex");
        //每页数量
        String pageSize=request.getParameter("pageSize")==null?"10":request.getParameter("pageSize");

        PageBean bean=new PageBean();
        if(StringUtils.isNotBlank(pageSize)){
            bean.setPageSize(Integer.parseInt(pageSize));
        }
        if (StringUtils.isNotBlank(pageIndex)) {
            bean.setRowStart(Integer.parseInt(pageSize) * Integer.parseInt(pageIndex));
        }
        List<TblLogObj> list=this.logService.selectLogList(memberId,null,bean);
        dataJson.put("list",list);
        dataJson.put("totalCount",bean.getTotalRows());
        dataJson.put("pageIndex",pageIndex);
        json.put("success",true);
        json.put("msg","查询成功");
        json.put("data",dataJson);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }
}
