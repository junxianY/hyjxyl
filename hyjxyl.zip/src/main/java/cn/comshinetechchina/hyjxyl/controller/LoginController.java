package cn.comshinetechchina.hyjxyl.controller;
import cn.comshinetechchina.hyjxyl.base.BaseController;
import cn.comshinetechchina.hyjxyl.base.ServiceException;
import cn.comshinetechchina.hyjxyl.domain.*;
import cn.comshinetechchina.hyjxyl.filter.TokenState;
import cn.comshinetechchina.hyjxyl.service.*;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import cn.comshinetechchina.hyjxyl.util.RegexUtils;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * app登录控制器
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/loginController")
public class LoginController extends BaseController {
    @Resource
    private MembersService membersService;
    @Resource
    private MemberExtendService memberExtendService;
    @Resource
    private SmsService smsService;
    @Resource
    private ConfigService configService;
    @Resource
    private SmsRecordService smsRecordService;
    @Resource
    private PhoneCodeService phoneCodeService;
    @Resource
    private PushMemberService pushMemberService;
    @Resource
    private ContentService contentService;
    @Resource
    private ContentRefService contentRefService;
    private static final Logger log= LoggerFactory.getLogger(LoginController.class);

    /**
     * 登录方法 登录判断 每次登录
     * @param phone 账号
     * @param pwd  密码
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/loginCheck",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String loginCheck(String phone, String pwd, HttpServletRequest request){
        log.info("进入loginCheck方法");
        JSONObject json =new JSONObject();
        if(StringUtils.isBlank(phone)){
            json.put("success",false);
            json.put("message","手机号不能为空");
            return json.toJSONString();
        }else if(RegexUtils.checkMobile(phone)==false){
            //正则校验手机号
            json.put("success",false);
            json.put("message","手机号格式不正确");
            return json.toJSONString();
        }else if(StringUtils.isBlank(pwd)){
            json.put("success",false);
            json.put("message","密码不能为空");
            return json.toJSONString();
        }else{
            try {
                //若token不为空，代表非首次登陆，进行验证比对，为空代表首次登陆，若token为空，生成一个。目前默认都是首次登录
                String token = request.getParameter("token");
                Members member = null;
                if (StringUtils.isNotBlank(token)) {
                    member = membersService.selectOneMembers(null, token);
                    if (member != null) {
                        if (!(member.getPhone().equals(phone) && member.getPassword().equals(pwd))) {
                            json.put("success", false);
                            json.put("message", "账号信息错误，请重新输入");
                            return json.toJSONString();
                        }
                        //被禁用用户不能登录
                        if(member.getAvailable()!=null&&member.getAvailable()==0){
                            json.put("success", false);
                            json.put("message", "用户已经禁用，无法登录");
                            return json.toJSONString();
                        }
                    } else {
                        json.put("success", false);
                        json.put("message", "登录信息超时");
                        return json.toJSONString();
                    }
                    JSONObject data = new JSONObject();
                    data.put("token", token);
                    json.put("data", data);
                } else {
                    //验证手机号库中是否存在
                    member = membersService.selectOneMembers(phone, null);
                    if (member == null) {
                        json.put("success", false);
                        json.put("message", "暂无此用户");
                        return json.toJSONString();
                    } else {
                        //手机号密码是否匹配
                        if (!member.getPassword().equals(pwd)) {
                            json.put("success", false);
                            json.put("message", "密码错误");
                            return json.toJSONString();
                        }else if(member.getAvailable()!=null&&member.getAvailable()==0){
                            //被禁用用户不能登录
                            json.put("success", false);
                            json.put("message", "用户已经禁用，无法登录");
                            return json.toJSONString();
                        }else{
                            //生成新token保存
                            Map<String, Object> payload = new HashMap<String, Object>();
                            Date date = new Date();
                            payload.put("uid", member.getMemberId());// 用户id
                            payload.put("iat", date.getTime());// 生成时间:当前
                            payload.put("ext", date.getTime() + 15*24*60*60*1000);// 过期时间半个月
                            //payload.put("ext", date.getTime() + 30 * 60 * 1000); //测试30分钟
                            String newToken = JwtUtil.createToken(payload);
                            member.setToken(newToken);
                            this.membersService.updateByPrimaryKeySelective(member);
                            JSONObject data = new JSONObject();
                            data.put("memberId", member.getMemberId());
                            data.put("token", newToken);
                            json.put("data", data);
                          /*  if(null!=member.getMemberId()){
                                //将用户id 姓名存入session
                                session.setAttribute("memberId",member.getMemberId());
                                MemberExtend extend=memberExtendService.selectByPrimaryKey(member.getMemberId());
                                if(extend!=null){
                                    session.setAttribute("memberName",extend.getName());
                                }
                            }*/
                        }
                    }
                }
                //登录后开启推送
                PushMember record=new PushMember();
                record.setMemberId(member.getMemberId());
                record.setAvailable(1);
                record.setUpdateTime(new Date());
                int j=this.pushMemberService.updatePushMember(record);
                if(j>0){
                    log.info("开启推送成功"+member.getMemberId());
                }else{
                    log.info("还未绑定推送"+member.getMemberId());
                }
            }catch(Exception ex){
                throw new ServiceException("数据出现异常",ex);
            }
        }
        json.put("success",true);
        json.put("message","成功");
        return json.toJSONString();
    }

    /**
     * 注册方法
     * @param phone 手机号
     * @param identifyCode 验证码
     * @param pwd 密码
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/register",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String  register(String phone,String identifyCode,String pwd){
     log.info("进入loginCheck方法");
     JSONObject json =new JSONObject();
     if(StringUtils.isBlank(phone)){
         json.put("success",false);
         json.put("message","密码不能为空");
         return json.toJSONString();
     }
     if(RegexUtils.checkMobile(phone)==false){
         //正则校验手机号
         json.put("success",false);
         json.put("message","手机号格式不正确");
         return json.toJSONString();
     }
     if(StringUtils.isBlank(identifyCode)){
         json.put("success",false);
         json.put("message","验证码不能为空");
         return json.toJSONString();
     }
     PhoneCode phoneCodeRecord=this.phoneCodeService.selectByPrimaryKey(phone);
     if(phoneCodeRecord!=null){
            if(!identifyCode.equals(phoneCodeRecord.getIdentifyCode())){
                json.put("success",false);
                json.put("message","验证码错误，请使用最新验证码");
                return json.toJSONString();
            }
     }else{
         json.put("success",false);
         json.put("message","请先使用手机获取验证码");
         return json.toJSONString();
     }
     if(StringUtils.isBlank(pwd)){
         json.put("success",false);
         json.put("message","密码不能为空");
         return json.toJSONString();
     }

     if(pwd.length()<6){
         json.put("success",false);
         json.put("message","密码长度不能小于6位");
         return json.toJSONString();
     }
         try{
             //验证库中手机号是否存在，存在提示
            Members member = membersService.selectOneMembers(phone, null);
            if(member!=null){
                json.put("success",false);
                json.put("message","该手机号已经注册");
                return json.toJSONString();
            }else {
                //插入用户信息
                String token = "";
                Members record = new Members();
                String uuId = UUID.randomUUID().toString();
                record.setMemberId(uuId);
                record.setPhone(phone);
                record.setPassword(pwd);
                record.setAvailable(1);
                record.setCreatedDate(new Date());
                record.setCreateBy("system");
                record.setCreateType(1); //创建方式
                Map<String, Object> payload = new HashMap<String, Object>();
                Date date = new Date();
                payload.put("uid", uuId);// 用户id
                payload.put("iat", date.getTime());// 生成时间:当前
                payload.put("ext",date.getTime() + 15*24*60*60*1000);// 过期时间半个月
                token = JwtUtil.createToken(payload);
                record.setToken(token);
                record.setUpdatedDate(new Date());//更新时间
                int i = this.membersService.insertSelective(record);
                if (i <= 0) {
                    json.put("success", false);
                    json.put("message", "程序出现异常");
                    return json.toJSONString();
                }else{
                    //插入从表信息
                    MemberExtend extend=new MemberExtend();
                    extend.setMemberId(uuId);
                    extend.setCreatedDate(new Date());
                    int t=this.memberExtendService.insertSelective(extend);
                    if(t>0){
                        log.info("插入从表信息成功");
                    }
                }
                JSONObject data = new JSONObject();
                data.put("memberId", uuId);
                data.put("token", token);
                json.put("data", data);
            }
         }catch(Exception ex){
             throw new ServiceException("数据出现异常",ex);
         }
      json.put("success",true);
      json.put("message","注册成功");
      return json.toJSONString();
    }

    /**
     * 发送验证码接口
     * @param phone 手机号
     * @param type 类型 1注册 2忘记密码
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/sendIdentifyCode",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String sendIdentifyCode(String phone,int type){
        log.info("sendIdentifyCode");
        JSONObject json =new JSONObject();
        if(StringUtils.isBlank(phone)){
            json.put("success",false);
            json.put("message","手机号码不能为空");
            return json.toJSONString();
        }
        if(RegexUtils.checkMobile(phone)==false){
            //正则校验手机号
            json.put("success",false);
            json.put("message","手机号格式不正确");
            return json.toJSONString();
        }
        if(type!=1&&type!=2){
            json.put("success",false);
            json.put("message","类型值错误");
            return json.toJSONString();
        }
        String verificationCode = (int) ((Math.random() * 9 + 1) * 100000) + "";
        log.info("随机产生的验证码为:"+verificationCode);
        //签名
        String signName="花样金夕";
        //短信模板
        String templeteCode="SMS_135755160";
        String templeteContent="";
        //从数据库拿取配置
        List<Config> configList=this.configService.selectConfigList("sms_signName",1);
        if(configList!=null&&configList.size()>0){
            signName=configList.get(0).getConfigValue();
        }
        String configCode="";
        if(1==type){
            configCode="sms_templet1";
        }else if(2==type){
            configCode="sms_templet2";
        }
        List<Config> configList1=this.configService.selectConfigList(configCode,1);
        if(configList1!=null&&configList1.size()>0){
            templeteCode=configList1.get(0).getConfigValue();
            templeteContent=configList1.get(0).getComments();
        }
        //模板参数
        String paras="{\"code\":\""+verificationCode+"\"}";
        //1.发送短信
        log.info("signName:"+signName+"--templeteCode:"+templeteCode+"---templeteContent："+templeteContent);
        Map<String,Object> map=this.smsService.sendMessage(phone,signName,templeteCode,paras);
        if("true".equals(map.get("success"))){
            //2.插入短信记录表
            SmsRecord record=new SmsRecord();
            record.setId(UUID.randomUUID().toString());
            record.setPhone(phone);
            record.setSignName(signName);
            record.setTempleteCode(templeteCode);
            record.setTempleteContent(templeteContent);
            record.setType(type);
            record.setTempleteParas(paras);
            record.setCreateTime(new Date());
            int i= smsRecordService.insertSelective(record);
            if(i>0){
             log.info("发送验证码插入短信记录成功");
            }
            //3.更新个人验证码
            int t=0;
            PhoneCode phoneCode=this.phoneCodeService.selectByPrimaryKey(phone);
            if(phoneCode==null){
               //插入操作
                phoneCode=new PhoneCode();
                phoneCode.setPhone(phone);
                phoneCode.setIdentifyCode(verificationCode);
                phoneCode.setUpdateTime(new Date());
                t=this.phoneCodeService.insertSelective(phoneCode);
            }else{
               //更新操作
                phoneCode.setIdentifyCode(verificationCode);
                phoneCode.setUpdateTime(new Date());
                t=this.phoneCodeService.updateByPrimaryKeySelective(phoneCode);
            }
            if(t>0){
                log.info(phone+"更新验证码成功");
            }
            json.put("success",true);
            json.put("message","发送成功");
            json.put("identifyCode",verificationCode);
        }else{
            json.put("success",false);
            json.put("message","发送失败，原因："+map.get("message"));
            json.put("identifyCode","");
        }

      return json.toJSONString();
    }

    /**
     * 找回密码接口
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/resetPassword",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String resetPassword(ResetPwdObj info) {
        JSONObject json = new JSONObject();
        if(null==info||StringUtils.isBlank(info.getPhone())){
            json.put("success",false);
            json.put("message","手机号码不能为空");
            return json.toJSONString();
        }
        log.info("resetPassword-----phone:"+info.getPhone()+"--verificationCode:"+info.getVerificationCode()+"---newPassword:"+info.getNewPassword());
        if(RegexUtils.checkMobile(info.getPhone())==false){
            //正则校验手机号
            json.put("success",false);
            json.put("message","手机号格式不正确");
            return json.toJSONString();
        }
        if(StringUtils.isBlank(info.getVerificationCode())){
            json.put("success",false);
            json.put("message","验证码不能为空");
            return json.toJSONString();
        }
        PhoneCode record=this.phoneCodeService.selectByPrimaryKey(info.getPhone());
        if(record!=null){
            if(!info.getVerificationCode().equals(record.getIdentifyCode())){
                json.put("success",false);
                json.put("message","验证码错误，请使用最新验证码");
                return json.toJSONString();
            }
        }
        if(StringUtils.isBlank(info.getNewPassword())){
            json.put("success",false);
            json.put("message","新密码不能为空");
            return json.toJSONString();
        }
        if(info.getNewPassword().length()<6){
            json.put("success",false);
            json.put("message","密码长度不能小于6位");
            return json.toJSONString();
        }
        log.info("通过校验");
        Members members=this.membersService.selectOneMembers(info.getPhone(),null);
        if(members==null){
            json.put("success",false);
            json.put("message","用户不存在，请先注册");
            return json.toJSONString();
        }
        Members newMember=new Members();
        newMember.setPassword(info.getNewPassword());
        newMember.setMemberId(members.getMemberId());
        int i=this.membersService.updateByPrimaryKeySelective(newMember);
        log.info("执行完毕更新"+i);
        if (i>0) {
            json.put("success", true);
            json.put("message","操作成功，新密码为："+info.getNewPassword());
        } else {
            json.put("success", false);
            json.put("message", "操作失败");
        }
        return json.toJSONString();
    }

    /**
     * 校验该openId是否被绑定
     * @param openId
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/checkWeChatOpenId",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String checkWeChatOpenId(String openId) {
        JSONObject json = new JSONObject();
        JSONObject data = new JSONObject();
        if(StringUtils.isBlank(openId)){
            json.put("success",false);
            json.put("message","参数不能为空");
            return json.toJSONString();
        }
        //判断库里是否有对应的openId用户,有的话直接登录,没有的话生成一条新的
        MemberInfoObj info=this.membersService.selectOneMember(openId);
        if(info!=null&&info.getPhone()!=null&&info.getMemberId()!=null){
            //增加判断用户禁用
            if("0".equals(info.getState())){
                data.put("flag",1);
                data.put("memberId","");
                data.put("token","");
                json.put("success",false);
                json.put("message","用户已经被禁用");
            }else{
                //存在 flag=0 不存在flag=1 直接登录即可
                //生成新token保存
                Map<String, Object> payload = new HashMap<String, Object>();
                Date date = new Date();
                payload.put("uid", info.getMemberId());// 用户id
                payload.put("iat", date.getTime());// 生成时间:当前
                payload.put("ext", date.getTime() + 15*24*60*60*1000);// 过期时间半个月
                String newToken = JwtUtil.createToken(payload);
                Members member=new Members();
                member.setMemberId(info.getMemberId());
                member.setToken(newToken);
                member.setUpdatedDate(new Date());//更新时间
                int i=this.membersService.updateByPrimaryKeySelective(member);
                if (i<= 0) {
                    json.put("success", false);
                    json.put("message", "程序出现异常");
                    return json.toJSONString();
                }else{
                    data.put("token",newToken);
                }
                data.put("flag",0);
                data.put("memberId",info.getMemberId());
                json.put("success",true);
                json.put("message","查询成功");
            }
        }else{
            data.put("flag",1);
            data.put("memberId","");
            data.put("token","");
            json.put("success",true);
            json.put("message","查询成功");
        }
        json.put("data",data);
        return JSONObject.toJSONString(json, SerializerFeature.WriteMapNullValue);
    }

    /**
     * 微信登录接口
     * @param openId 微信id
     * @param phone 手机号
     * @param infoJson 微信信息体
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/weChatLogin",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String weChatLogin(String openId,String phone,String infoJson){
        JSONObject json =new JSONObject();
        if(StringUtils.isBlank(openId)){
            json.put("success",false);
            json.put("message","参数openId不能为空");
            return json.toJSONString();
        }
        //判断库里是否有对应的openId用户,有的话直接登录,没有的话生成一条新的
        MemberInfoObj info=this.membersService.selectOneMember(openId);
        if(info!=null){
            if(info.getState()!=null&&"0".equals(info.getState())){
                json.put("success", false);
                json.put("message", "用户已经禁用，无法登录");
                return json.toJSONString();
            }
            //匹配手机号
            if(!phone.equals(info.getPhone())){
                json.put("success",false);
                json.put("message","手机号与微信号不匹配");
                return json.toJSONString();
            }
            //生成新token保存
            Map<String, Object> payload = new HashMap<String, Object>();
            Date date = new Date();
            payload.put("uid", info.getMemberId());// 用户id
            payload.put("iat", date.getTime());// 生成时间:当前
            payload.put("ext", date.getTime() + 15*24*60*60*1000);// 过期时间半个月
            String newToken = JwtUtil.createToken(payload);
            Members member=new Members();
            member.setMemberId(info.getMemberId());
            member.setToken(newToken);
            int i=this.membersService.updateByPrimaryKeySelective(member);
            if (i<= 0) {
                json.put("success", false);
                json.put("message", "程序出现异常");
                return json.toJSONString();
            }
            JSONObject data = new JSONObject();
            data.put("memberId", info.getMemberId());
            data.put("token", newToken);
            json.put("data", data);
        }else{
            //新绑定用户手机号为必输
            if(StringUtils.isBlank(phone)){
                json.put("success",false);
                json.put("message","参数手机号不能为空");
                return json.toJSONString();
            }
            //校验手机号格式
            if(RegexUtils.checkMobile(phone)==false){
                //正则校验手机号
                json.put("success",false);
                json.put("message","手机号格式不正确");
                return json.toJSONString();
            }
            //校验手机号库里是否存在
            boolean flag=false;
            Members member = membersService.selectOneMembers(phone, null);
            if(member!=null&&StringUtils.isNotBlank(member.getOpenid())){
                if(!openId.equals(member.getOpenid())){
                    json.put("success",false);
                    json.put("message","该手机号已经被绑定,请使用未绑定的手机号！");
                    return json.toJSONString();
                }
            }else{
                flag=true;//代表为绑定手机号操作
            }
            Members record = new Members();
            if(flag){
                //单纯进行绑定操作
                record.setMemberId(member.getMemberId());
                record.setOpenid(openId);
                Map<String, Object> payload = new HashMap<String, Object>();
                Date date = new Date();
                payload.put("uid", member.getMemberId());// 用户id
                payload.put("iat", date.getTime());// 生成时间:当前
                payload.put("ext", date.getTime() + 15*24*60*60*1000);// 过期时间半个月
                String token = JwtUtil.createToken(payload);
                record.setToken(token);
                record.setUpdatedDate(new Date());
                int i=this.membersService.updateByPrimaryKeySelective(record);
                if (i <= 0) {
                    json.put("success", false);
                    json.put("message", "程序出现异常");
                    return json.toJSONString();
                }else{
                    JSONObject data = new JSONObject();
                    data.put("memberId", member.getMemberId());
                    data.put("token", token);
                    json.put("data", data);
                }
            }else {
                //登录操作 插入新的记录
                String token = "";
                String uuId = UUID.randomUUID().toString();
                record.setMemberId(uuId);
                record.setPhone(phone);
                record.setPassword("123456");
                record.setAvailable(1);
                record.setCreatedDate(new Date());
                record.setCreateBy("system");
                record.setCreateType(1); //创建方式
                Map<String, Object> payload = new HashMap<String, Object>();
                Date date = new Date();
                payload.put("uid", uuId);// 用户id
                payload.put("iat", date.getTime());// 生成时间:当前
                payload.put("ext", date.getTime() + 15*24*60*60*1000);// 过期时间半个月
                token = JwtUtil.createToken(payload);
                record.setToken(token);
                record.setOpenid(openId);
                record.setUpdatedDate(new Date());//更新时间
                int i = this.membersService.insertSelective(record);
                if (i <= 0) {
                    json.put("success", false);
                    json.put("message", "程序出现异常");
                    return json.toJSONString();
                } else {
                    log.info("微信登录json:" + infoJson);
                    //主表插入成功后 插入附表信息
                    if (StringUtils.isNotBlank(infoJson)) {
                        //微信信息匹配
                        WeChatObject object = JSONObject.parseObject(infoJson, WeChatObject.class);
                        if (object != null) {
                            MemberExtend extend = new MemberExtend();
                            extend.setMemberId(uuId);
                            extend.setName(object.getNickname());
                            //性別
                            if (object.getSex() != null) {
                                extend.setSex(Integer.parseInt(object.getSex()));
                            }
                            extend.setCreatedDate(new Date());
                            extend.setAvailable(1);
                            int t = this.memberExtendService.insertSelective(extend);
                            if (t > 0) {
                                log.info("插入附表信息成功");
                            }
                            if (object.getHeadimgurl() != null) {
                                String remoteImgUrl = object.getHeadimgurl();
                                log.info("头像地址为:" + remoteImgUrl);
                                //保存头像到本服务器
                                String ss = this.contentService.saveRemoteImg(remoteImgUrl);
                                if (StringUtils.isNotBlank(ss) && ((Boolean) JSONObject.parseObject(ss).get("success"))) {
                                    //图片保存成功后 进行头像绑定
                                    String contentId = (String) JSONObject.parseObject(ss).get("contentId");
                                    log.info("保存附件成功，附件id:" + contentId);
                                    ContentRef ref = new ContentRef();
                                    ref.setContentRefId(UUID.randomUUID().toString());
                                    ref.setContentId(contentId);
                                    ref.setContentRefType("tbl_members");
                                    ref.setContentRefCode("member_id");
                                    ref.setExternalId(uuId);
                                    ref.setCreateTime(new Date());
                                    int j = this.contentRefService.insertSelective(ref);
                                    if (j > 0) {
                                        log.info("关联头像操作成功");
                                    } else {
                                        log.info("关联头像操作失败");
                                    }
                                } else {
                                    log.info("微信头像保存失败，原因:" + JSONObject.parseObject(ss).get("message"));
                                }
                            }
                        }
                    }
                }
            JSONObject data = new JSONObject();
            data.put("memberId", uuId);
            data.put("token", token);
            json.put("data", data);
            }
        }
        json.put("success",true);
        json.put("message","操作成功");
        return json.toJSONString();
    }

    /**
     * 登出接口
     * @param memberId
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/loginOut",method= RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT,timeout=36000,rollbackFor=Exception.class)
    public String loginOut(String memberId){
     JSONObject json=new JSONObject();
     if(StringUtils.isBlank(memberId)){
         json.put("success",false);
         json.put("message","参数不能为空");
         return json.toJSONString();
     }
     //登出清空该用户token,同时解绑个推用户
      Members member=this.membersService.selectByPrimaryKey(memberId);
      if(member!=null){
          int i=this.membersService.updateMembersToken(memberId);
          if(i>0){
              log.info("清空用户token值成功");
              PushMember record=new PushMember();
              record.setMemberId(memberId);
              record.setAvailable(0);
              int j=this.pushMemberService.updatePushMember(record);
              if(j>0){
                log.info("更新个推用户有效性为无效成功"+memberId);
              }
              json.put("success",true);
              json.put("message","操作成功");
          }
      }else{
          json.put("success",false);
          json.put("message","对应客户不存在");
      }
      return json.toJSONString();
    }

    /**
     * 校验token有效期
     * @param token
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/checkTokenActive", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String  checkTokenActive(String token){
        JSONObject json = new JSONObject();
        System.out.println("开始校验token"+token);
        //校验账号是否被禁用
        Map<String, Object> resultMap= JwtUtil.validToken(token);
        TokenState state=TokenState.getTokenState((String)resultMap.get("state"));
        log.info("-----------token状态state:"+state);
        String memberId="";
        switch (state) {
            case VALID:
                try {
                    //如果token有效 查询出其对应的memberId返回
                    Map<String, Object> map = JwtUtil.parseManagementToken(token);
                    memberId = map.get("uid") == null ? "" : map.get("uid").toString();
                    log.info("当前后台登录人memberId:" + memberId);
                    //判断该对象数据库中是否还存在
                    Members  m=this.membersService.selectByPrimaryKey(memberId);
                    if(m!=null&&m.getAvailable()==0){
                        json.put("success",false);
                        json.put("message","账号已经被禁用，请联系客服");
                        return json.toJSONString();
                    }
                    if(m!=null&&m.getToken()!=null&&token.equals(m.getToken())){
                        json.put("success",true);
                        json.put("message","校验通过");
                    }else{
                        json.put("success",false);
                        json.put("message","不存在相应匹配用户");
                    }
                }catch(Exception ex){
                    throw new ServiceException("token解析失败",ex);
                }
                break;
            case EXPIRED:
            case INVALID:
                json.put("success", false);
                json.put("message", "您的token不合法或者过期了，请重新登陆");
                break;
        }
        json.put("memberId",memberId);
        return json.toJSONString();
    }
}
