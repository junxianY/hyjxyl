package cn.comshinetechchina.hyjxyl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableTransactionManagement
@ServletComponentScan
public class HyjxylApplication{
	public static void main(String[] args) {
	    SpringApplication.run(HyjxylApplication.class, args);
	}

    @Bean
    public Object testBean(PlatformTransactionManager platformTransactionManager){
        System.out.println("jpa>>>>>>>>>>" + platformTransactionManager.getClass().getName());
        return new Object();
    }
}
