package cn.comshinetechchina.hyjxyl.base;

/**
 * 公用参数类
 */
public class Constant {
    public static String JWT_SECRET="3d990d2276917dfac04467df11fff26d";
    /**
     * 节假日
     */
    public static final long CONFIG_HOLIDAY = 1003001;

    /**
     * 周末工作日
     */
    public static final long CONFIG_WEEKEND_WORKDAY = 1003002;
    /**
     * 时间日期格式yyyy-MM-dd
     */
    public static final String DATETYPEYMD="yyyy-MM-dd";
    /**
     * 时间日期格式yyyy-MM
     */
    public static final String DATETYPEYM="yyyy-MM";
    /**
     * 时间日期格式yyyy/MM/dd
     */
    public static final String DATETYPEYMDN="yyyy/MM/dd";
    /**
     * 时间日期格式HH:mm:ss
     */
    public static final String DATETYPEHMS="HH:mm:ss";
    /**
     * 时间日期格式yyyy-MM-dd HH:mm:ss
     */
    public static final String DATETYPEYMDHMS="yyyy-MM-dd HH:mm:ss";
    /**
     * 时间日期格式YYYYMMDD:HHmmss
     */
    public static final String DATETYPEYMDHMSONE="yyyyMMdd:HHmmss";
    /**
     * 时间日期格式HH:mm
     */
    public static final String DATETYPEHM="HH:mm";

    //发送短信 产品名称:云通信短信API产品,开发者无需替换
    public static final String product = "Dysmsapi";
    //发送短信 产品域名,开发者无需替换
    public static final String domain = "dysmsapi.aliyuncs.com";

    //发送短信 TODO 此处需要替换成开发者自己的AK(在阿里云访问控制台寻找)
    public static final String accessKeyId = "LTAIo7fUJrNL30ri";
    public static final String accessKeySecret = "YRQFPzWltwvIBI00aOT7OkqzDML1vh";
}
