package cn.comshinetechchina.hyjxyl.base;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import javax.persistence.Entity;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 封装分页查询方法
 * @param <T>
 * @param <PK>
 */
public class AbstractBaseDao<T extends Entity, PK extends Serializable> extends SqlSessionDaoSupport {
    @Autowired
    public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory){
        super.setSqlSessionFactory(sqlSessionFactory);
    }
    /**
     *
     * @param page page对象
     * @param statementCountName 命名空间.查询总数ID
     * @param statementName  命名空间.查询List的Id
     * @param map  传入的参数（条件查询）
     * @return
     */
    protected List<T> queryForPaginatedList(PageBean page,final String statementCountName, final String statementName, Map<String,Object> map) {
        List<T> list = null;// 结果集
        int totalRows = 0;// 总记录数
        map.put("pageSize", page.getPageSize());
        map.put("rowStart", page.getRowStart());
        map.put("orderfield", page.getOrderfield());
        map.put("order", page.getOrder());
        Object o = this.getSqlSession().selectOne(statementCountName, map);
        if (null != o) {
            totalRows = Integer.parseInt(o.toString());
        }
        page.setTotalRows(totalRows);
        if (totalRows > 0) {
            list = this.getSqlSession().selectList(statementName,map);
        }
        return list;
    }
}
