package cn.comshinetechchina.hyjxyl.base;
/**
 * 分页辅助类
 */
public class PageBean {
    private static final long serialVersionUID = 1L;

    private int totalRows = 0;// 总记录数

    private int rowStart=0;// 起始位置

    private int pageSize = 10;// 每页面大小

    private String orderfield=null;//排序字段
    private String order="desc";  //升序还是降序 默认降序

    public String getOrderfield() {
        return orderfield;
    }

    public void setOrderfield(String orderfield) {
        this.orderfield = orderfield;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    private String sortOrder;//排序标识


    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalRows() {
        return totalRows;
    }

    public void setTotalRows(int totalRows) {
        this.totalRows = totalRows;
    }

    public int getRowStart() {
        return rowStart;
    }

    public void setRowStart(int rowStart) {
        this.rowStart = rowStart;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }
}
