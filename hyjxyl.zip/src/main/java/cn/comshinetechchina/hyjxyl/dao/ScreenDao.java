package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.domain.ServiceStatistics;
import cn.comshinetechchina.hyjxyl.domain.StatisticsArticle;

import java.util.List;
import java.util.Map;

public interface ScreenDao {
    /**
     * 统计用户接口
     * @param type 默认、总人数 1、当天 2、当月 3.近30天
     * @return
     */
    public int countMembers(int type);

    /**
     * 统计各年龄阶段人数
     * @param ageStr
     * @param ageEnd
     * @return
     */
    public int statisticsMembersByAge(Integer ageStr,Integer ageEnd,int sex);

    /**
     * 统计各个教育程度人数
     * @param educationId
     * @return
     */
    public int statisticsMembersByEducation(String educationId);


    public List<Map<String,Object>> statisticsMembersEducation(Map<String,Object> map);

    /**
     * 统计近六个月各项服务使用总次数
     * @return
     */
    public List<ServiceStatistics> selectServiceStatistics(Map<String,Object> map);

    /**
     * 根据居住类型分组统计人数
     * @return
     */
    public List<Map<String,Object>> queryMembersByLiveCategory(Map<String,Object> map);

    /**
     * 统计某段时间内各项服务总次数
     * @param map  type=1 近30天
     * @return
     */
    public List<ServiceStatistics> statisticsMembersByServiceName(Map<String,Object> map);

    /**
     * 统计仪器使用记录
     * @param map  type=1 今天
     * @return
     */
    public List<ServiceStatistics> statisticsCardUseRecord(Map<String,Object> map);
    /**
     * 统计活动资讯浏览量、点赞数等
     * @param map
     * @return
     */
    public List<StatisticsArticle> statisticsArticles(Map<String,Object> map);

    public int countOneDisease(String diseaseName,int sex);

    /**
     * 统计服务总次数
     * @param map
     * @return
     */
    public List<Map<String,Object>> statisticsCardUse(Map<String,Object> map);

    /**
     * 根据条件统计类型总数
     * @param map
     * @return
     */
    public int totalCount(Map<String,Object> map);

    /**
     * 查询统计后列表数据
     * @param map
     * @return
     */
    public List<Map<String,Object>> selectResultByCheck(Map<String,Object> map);
}
