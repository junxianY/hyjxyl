package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.TblServiceMapper;
import cn.comshinetechchina.hyjxyl.domain.TblService;

import java.util.List;
import java.util.Map;

public interface TblServiceDao extends TblServiceMapper {
    /**
     * 查询服务列表
     * @param map
     * @return
     */
    public List<TblService> queryServiceList(Map<String,String> map);
}
