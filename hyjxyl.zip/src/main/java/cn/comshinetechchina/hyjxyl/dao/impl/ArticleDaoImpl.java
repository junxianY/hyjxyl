package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.ArticleDao;
import cn.comshinetechchina.hyjxyl.domain.Article;
import cn.comshinetechchina.hyjxyl.domain.ArticleObj;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("articleDao")
@SuppressWarnings("unchecked")
public class ArticleDaoImpl extends AbstractBaseDao implements ArticleDao {
    @Override
    public int deleteByPrimaryKey(String articleId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.ArticleMapper.deleteByPrimaryKey",articleId);
    }

    @Override
    public int insert(Article record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.ArticleMapper.insert",record);
    }

    @Override
    public int insertSelective(Article record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.ArticleMapper.insertSelective",record);
    }

    @Override
    public Article selectByPrimaryKey(String articleId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.ArticleMapper.selectByPrimaryKey",articleId);
    }

    @Override
    public int updateByPrimaryKeySelective(Article record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ArticleMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKeyWithBLOBs(Article record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ArticleMapper.updateByPrimaryKeyWithBLOBs",record);
    }

    @Override
    public int updateByPrimaryKey(Article record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ArticleMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<ArticleObj> selectArticleList(Map<String, Object> map, PageBean bean) {
        return this.queryForPaginatedList(bean,"cn.comshinetechchina.hyjxyl.dao.ArticleDao.selectArticleListCount","cn.comshinetechchina.hyjxyl.dao.ArticleDao.selectArticleList",map);
    }

    @Override
    public int updateArticleArticleScol(List<String> list) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.ArticleDao.updateArticleArticleScol",list);
    }

    @Override
    public List<ArticleObj> selectRandom5Articles() {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ArticleDao.selectRandom5Articles",null);
    }

    @Override
    public Map selectOneByOrderNo(Article article) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.ArticleDao.selectOneByOrderNo",article);
    }
}
