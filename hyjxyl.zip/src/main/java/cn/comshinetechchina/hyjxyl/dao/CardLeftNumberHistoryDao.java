package cn.comshinetechchina.hyjxyl.dao;
import cn.comshinetechchina.hyjxyl.dao.mapper.CardLeftNumberHistoryMapper;

import java.util.Date;

public interface CardLeftNumberHistoryDao  extends CardLeftNumberHistoryMapper{
    /**
     * 转移卡剩余次数记录接口
     * @param cardNo
     * @param serviceId
     * @return
     */
    public int moveCardLeftNumber(String cardNo,String serviceId);

    /**
     * 跑批批量插入数据
     * @return
     */
    public int batchInsertRecordByTask(Date endDate);

}
