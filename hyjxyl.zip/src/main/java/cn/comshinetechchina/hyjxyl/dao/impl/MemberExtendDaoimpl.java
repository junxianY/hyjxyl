package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.MemberExtendDao;
import cn.comshinetechchina.hyjxyl.domain.MemberExtend;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("memberExtendDao")
public class MemberExtendDaoimpl extends AbstractBaseDao implements MemberExtendDao {
    @Override
    public int deleteByPrimaryKey(String memberId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.MemberExtendMapper.deleteByPrimaryKey",memberId);
    }

    @Override
    public int insert(MemberExtend record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.MemberExtendMapper.insert",record);
    }

    @Override
    public int insertSelective(MemberExtend record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.MemberExtendMapper.insertSelective",record);
    }

    @Override
    public MemberExtend selectByPrimaryKey(String memberId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.MemberExtendMapper.selectByPrimaryKey",memberId);
    }

    @Override
    public int updateByPrimaryKeySelective(MemberExtend record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.MemberExtendMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(MemberExtend record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.MemberExtendMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<MemberExtend> selectMemberExtendList(MemberExtend record) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.MemberExtendDao.selectMemberExtendList",record);
    }
}
