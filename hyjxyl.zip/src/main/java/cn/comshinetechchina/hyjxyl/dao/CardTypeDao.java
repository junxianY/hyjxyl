package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeMapper;
import cn.comshinetechchina.hyjxyl.domain.CardType;

import java.util.List;
import java.util.Map;

public interface CardTypeDao extends CardTypeMapper {
    List<CardType> selectAllCardTypes(Map<String,Object> map);
}
