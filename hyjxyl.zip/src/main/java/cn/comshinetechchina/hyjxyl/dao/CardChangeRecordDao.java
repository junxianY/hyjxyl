package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.CardChangeRecordMapper;

public interface CardChangeRecordDao extends CardChangeRecordMapper {

}
