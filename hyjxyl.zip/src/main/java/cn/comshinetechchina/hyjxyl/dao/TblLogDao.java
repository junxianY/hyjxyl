package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.TblLogMapper;
import cn.comshinetechchina.hyjxyl.domain.TblLogObj;

import java.util.List;

public interface TblLogDao extends TblLogMapper {
    List<TblLogObj> selectLogList(String memberId, Integer type,PageBean page);
}
