package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.PushMessageMapper;
import cn.comshinetechchina.hyjxyl.domain.PushMessageObj;

import java.util.List;
import java.util.Map;

public interface PushMessageDao extends PushMessageMapper {
 public List<PushMessageObj> selectPushMessageList(PageBean page, Map<String,Object> map);
 /**
  * 批量更新状态接口
  * @param list
  * @return
  */
 public int batchUpdateMessageStatus(List<String> list);
}
