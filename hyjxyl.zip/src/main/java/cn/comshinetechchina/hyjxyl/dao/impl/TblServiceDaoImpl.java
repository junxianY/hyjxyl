package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.TblServiceDao;
import cn.comshinetechchina.hyjxyl.domain.TblService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("tblServiceDao")
public class TblServiceDaoImpl extends AbstractBaseDao implements TblServiceDao {
    @Override
    public int deleteByPrimaryKey(String serviceId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.TblServiceMapper.deleteByPrimaryKey",serviceId);
    }

    @Override
    public int insert(TblService record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.TblServiceMapper.insert",record);
    }

    @Override
    public int insertSelective(TblService record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.TblServiceMapper.insertSelective",record);
    }

    @Override
    public TblService selectByPrimaryKey(String serviceId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.TblServiceMapper.selectByPrimaryKey",serviceId);
    }

    @Override
    public int updateByPrimaryKeySelective(TblService record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.TblServiceMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(TblService record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.TblServiceMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<TblService> queryServiceList(Map<String, String> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.TblServiceDao.queryServiceList",map);
    }
}
