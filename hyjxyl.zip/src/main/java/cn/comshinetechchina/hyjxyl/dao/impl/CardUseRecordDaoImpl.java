package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.CardUseRecordDao;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecord;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecordCountObj;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecordObj;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("cardUseRecordDao")
public class CardUseRecordDaoImpl extends AbstractBaseDao implements CardUseRecordDao {
    @Override
    public int deleteByPrimaryKey(String recordId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.CardUseRecordMapper.deleteByPrimaryKey",recordId);
    }

    @Override
    public int insert(CardUseRecord record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardUseRecordMapper.insert",record);
    }

    @Override
    public int insertSelective(CardUseRecord record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardUseRecordMapper.insertSelective",record);
    }

    @Override
    public CardUseRecord selectByPrimaryKey(String recordId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.CardUseRecordMapper.selectByPrimaryKey",recordId);
    }

    @Override
    public int updateByPrimaryKeySelective(CardUseRecord record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardUseRecordMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(CardUseRecord record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardUseRecordMapper.updateByPrimaryKeySelective.updateByPrimaryKey",record);
    }

    @Override
    public List<CardUseRecordObj> selectRecordList(PageBean page, Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.CardUseRecordDao.selectRecordListCount","cn.comshinetechchina.hyjxyl.dao.CardUseRecordDao.selectRecordList",map);
    }

    @Override
    public List<CardUseRecordCountObj> countCardUseRecord(String memberId,String startDate, String endDate) {
        Map<String,String> map=new HashMap<String,String>();
        map.put("startDate",startDate);
        map.put("endDate",endDate);
        map.put("memberId",memberId);
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.CardUseRecordDao.countCardUseRecord",map);
    }
}
