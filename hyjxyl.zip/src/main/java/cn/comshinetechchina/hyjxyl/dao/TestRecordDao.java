package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.TestRecordMapper;
import cn.comshinetechchina.hyjxyl.domain.TestRecord;

import java.util.List;
import java.util.Map;

public interface TestRecordDao extends TestRecordMapper {
    /**
     * 通过条件查询客户体检信息
     * @param map
     * @param bean
     * @return
     */
    List<TestRecord> selectTestRecordList(Map<String,Object> map,PageBean bean);
    /**
     * 通过条件查询客户所有体检信息
     * @param map
     * @return
     */
    List<TestRecord> selectAllTestRecordList(Map<String,Object> map);
}
