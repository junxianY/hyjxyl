package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.MessageMapper;
import cn.comshinetechchina.hyjxyl.domain.Message;

import java.util.List;
import java.util.Map;

/**
 * 消息服务接口
 */
public interface MessageDao extends MessageMapper {
    /**
     * 通过条件查询消息列表
     * @param map
     * @return
     */
    public List<Message> selectMessageList(Map<String,String> map);
}
