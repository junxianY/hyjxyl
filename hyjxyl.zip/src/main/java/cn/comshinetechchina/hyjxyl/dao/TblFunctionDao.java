package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.TblFunctionMapper;
import cn.comshinetechchina.hyjxyl.domain.TblFunction;

import java.util.List;
import java.util.Map;

/**
 * 功能数据层
 */
public interface TblFunctionDao extends TblFunctionMapper{
  public List<TblFunction> selectFunctionList(Map<String,Object> map);
}
