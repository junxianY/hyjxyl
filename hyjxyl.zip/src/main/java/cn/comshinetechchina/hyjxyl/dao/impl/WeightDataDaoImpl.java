package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.WeightDataDao;
import cn.comshinetechchina.hyjxyl.domain.WeightData;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("weightDataDao")
public class WeightDataDaoImpl extends AbstractBaseDao implements WeightDataDao {
    @Override
    public int deleteByPrimaryKey(String id) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.WeightDataMapper.deleteByPrimaryKey",id);
    }

    @Override
    public int insert(WeightData record) {
        return 0;
    }

    @Override
    public int insertSelective(WeightData record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.WeightDataMapper.insertSelective",record);
    }

    @Override
    public WeightData selectByPrimaryKey(String id) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(WeightData record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(WeightData record) {
        return 0;
    }

    @Override
    public List<WeightData> selectWeightDataList(PageBean page, Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.WeightDataDao.selectWeightDataListCount","cn.comshinetechchina.hyjxyl.dao.WeightDataDao.selectWeightDataList",map);
    }

    @Override
    public List<WeightData> selectMemberWeightDataList(String memberId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.WeightDataDao.selectMemberWeightDataList",memberId);
    }

}
