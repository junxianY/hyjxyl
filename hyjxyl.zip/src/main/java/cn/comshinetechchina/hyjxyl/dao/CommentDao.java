package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.CommentMapper;
import cn.comshinetechchina.hyjxyl.domain.Comment;

import java.util.List;
import java.util.Map;

public interface CommentDao extends CommentMapper {
    /**
     * 通过条件查询评论列表
     * @return
     */
   public List<Comment> selectCommentList(Map<String,Object> map);
}
