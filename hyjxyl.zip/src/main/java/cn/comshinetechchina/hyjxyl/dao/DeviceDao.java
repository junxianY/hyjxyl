package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.DeviceMapper;
import cn.comshinetechchina.hyjxyl.domain.Device;

import java.util.List;
import java.util.Map;

public interface DeviceDao extends DeviceMapper{
    public List<Device> selectDeviceList(String deviceNO, String tenantId, String serviceId, int available);
    /**
     * 分页查询设备列表
     * @param map
     * @param bean
     * @return
     */
    public List<Device> selectPageDeviceList(Map<String,Object> map, PageBean bean);
}
