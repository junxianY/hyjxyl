package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.ConfigDao;
import cn.comshinetechchina.hyjxyl.domain.Config;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service("configDao")
public class ConfigDaoImpl extends AbstractBaseDao implements ConfigDao {
    @Override
    public int deleteByPrimaryKey(String configId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.ConfigMapper.deleteByPrimaryKey",configId);
    }

    @Override
    public int insert(Config record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.ConfigMapper.insert",record);
    }

    @Override
    public int insertSelective(Config record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.ConfigMapper.insertSelective",record);
    }

    @Override
    public Config selectByPrimaryKey(String configId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.ConfigMapper.selectByPrimaryKey",configId);
    }

    @Override
    public int updateByPrimaryKeySelective(Config record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ConfigMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Config record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ConfigMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<Config> selectConfigList(String code, int isActive) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("code",code);
        map.put("isActive",isActive);
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ConfigDao.selectConfigList",map);
    }

    @Override
    public List<Config> selectConfigByPara(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ConfigDao.selectConfigList",map);
    }
}
