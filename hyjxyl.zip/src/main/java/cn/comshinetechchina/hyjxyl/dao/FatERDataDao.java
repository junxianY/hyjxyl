package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.FatERDataMapper;
import cn.comshinetechchina.hyjxyl.domain.FatERData;

import java.util.List;
import java.util.Map;

/**
 * 数据中心-脂肪透传电阻
 */
public interface FatERDataDao extends FatERDataMapper {
    public List<FatERData> selectFatERDataList(PageBean page, Map<String, Object> map);
}
