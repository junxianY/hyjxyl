package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.PushMemberMapper;
import cn.comshinetechchina.hyjxyl.domain.PushMember;

import java.util.List;
import java.util.Map;

public interface PushMemberDao extends PushMemberMapper{
    /**
     * 查詢推送用戶列表
     * @param map
     * @return
     */
    List<PushMember> selectPushMembersList(Map<String,Object> map);
    int updatePushMember(PushMember record);

    /**
     * 清除clientId
     * @param clientId
     * @return
     */
    int delPushMemberByClientId(String clientId);
}
