package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.FatERDataDao;
import cn.comshinetechchina.hyjxyl.domain.FatERData;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("fatERDataDao")
public class FatERDataDaoImpl extends AbstractBaseDao implements FatERDataDao {
    @Override
    public int deleteByPrimaryKey(String id) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.FatERDataMapper.deleteByPrimaryKey",id);
    }

    @Override
    public int insert(FatERData record) {
        return 0;
    }

    @Override
    public int insertSelective(FatERData record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.FatERDataMapper.insertSelective",record);
    }

    @Override
    public FatERData selectByPrimaryKey(String id) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(FatERData record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(FatERData record) {
        return 0;
    }

    @Override
    public List<FatERData> selectFatERDataList(PageBean page, Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.FatERDataDao.selectFatERDataListCount","cn.comshinetechchina.hyjxyl.dao.FatERDataDao.selectFatERDataList",map);
    }
}
