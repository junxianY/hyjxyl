package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.SaleAccountMapper;
import cn.comshinetechchina.hyjxyl.domain.SaleAccount;

import java.util.List;
import java.util.Map;

public interface SaleAccountDao extends SaleAccountMapper {
    /**
     * 分页查询服务专员信息
     * @param map
     * @param page
     * @return
     */
    List<SaleAccount> querySaleAccountList(Map<String, Object> map,PageBean page);
}
