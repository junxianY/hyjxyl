package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeServiceMapper;
import cn.comshinetechchina.hyjxyl.domain.CardTypeService;

import java.util.List;
import java.util.Map;

public interface CardTypeServiceDao extends CardTypeServiceMapper {
    /**
     * 通过条件查询卡服务关联列表
     * @param map
     * @return
     */
    public List<CardTypeService> selectCardTypeServiceList(Map<String,String> map);
    /**
     * 批量插入
     * @param list
     * @return
     */
    int batchInsertSelective(List<CardTypeService> list);
    /**
     * 删除某卡类型绑定服务
     * @param cardTypeId
     * @return
     */
    public int deleteRecordByPara(String cardTypeId);
}
