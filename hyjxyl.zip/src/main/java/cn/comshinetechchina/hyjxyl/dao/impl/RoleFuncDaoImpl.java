package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.RoleFuncDao;
import cn.comshinetechchina.hyjxyl.domain.RoleFuncKey;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("roleFuncDao")
public class RoleFuncDaoImpl extends AbstractBaseDao implements RoleFuncDao {
    @Override
    public int deleteByPrimaryKey(RoleFuncKey key) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.RoleFuncMapper.deleteByPrimaryKey",key);
    }

    @Override
    public int insert(RoleFuncKey record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.RoleFuncMapper.insert",record);
    }

    @Override
    public int insertSelective(RoleFuncKey record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.RoleFuncMapper.insertSelective",record);
    }

    @Override
    public int deleteRoleFunctions(Integer roleId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.RoleFuncDao.deleteRoleFunctions",roleId);
    }

    @Override
    public int batchInsertRoleFunc(List<RoleFuncKey> list) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.RoleFuncDao.batchInsertRoleFunc",list);
    }

    @Override
    public List<RoleFuncKey> selectRoleFuncList(Integer roleId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.RoleFuncDao.selectRoleFuncList",roleId);
    }
}
