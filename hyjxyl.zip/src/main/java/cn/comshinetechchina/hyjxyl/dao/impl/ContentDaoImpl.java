package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.ContentDao;
import cn.comshinetechchina.hyjxyl.domain.Content;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service("contentDao")
public class ContentDaoImpl extends AbstractBaseDao implements ContentDao {
    @Override
    public int deleteByPrimaryKey(String contentId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.ContentMapper.deleteByPrimaryKey",contentId);
    }

    @Override
    public int insert(Content record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.ContentMapper.insert",record);
    }

    @Override
    public int insertSelective(Content record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.ContentMapper.insertSelective",record);
    }

    @Override
    public Content selectByPrimaryKey(String contentId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.ContentMapper.selectByPrimaryKey",contentId);
    }

    @Override
    public int updateByPrimaryKeySelective(Content record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ContentMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Content record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ContentMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<Content> selectContentsById(String busiId, String tableName,String contentTypeId) {
        Map<String,String> map=new HashMap<String,String>();
        map.put("busiId",busiId);
        map.put("tableName",tableName);
        map.put("contentTypeId",contentTypeId);
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ContentDao.selectContentsById",map);
    }
}
