package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.FatDataMapper;
import cn.comshinetechchina.hyjxyl.domain.FatData;

import java.util.List;
import java.util.Map;

/**
 * 脂肪接口
 */
public interface FatDataDao extends FatDataMapper {
    /**
     * 查询数据列表
     * @param page
     * @param map
     * @return
     */
    public List<FatData> selectFatDataList(PageBean page, Map<String, Object> map);
    /**
     * 查询脂肪信息
     * @param memberId
     * @return
     */
    List<FatData> selectFatDataList(String memberId);

}
