package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.SaleAccountDao;
import cn.comshinetechchina.hyjxyl.domain.SaleAccount;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("saleAccountDao")
public class SaleAccountDaoImpl extends AbstractBaseDao implements SaleAccountDao {
    @Override
    public int deleteByPrimaryKey(String code) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.SaleAccountMapper.deleteByPrimaryKey",code);
    }

    @Override
    public int insert(SaleAccount record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.SaleAccountMapper.insert",record);
    }

    @Override
    public int insertSelective(SaleAccount record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.SaleAccountMapper.insertSelective",record);
    }

    @Override
    public SaleAccount selectByPrimaryKey(String code) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.SaleAccountMapper.selectByPrimaryKey",code);
    }

    @Override
    public int updateByPrimaryKeySelective(SaleAccount record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.SaleAccountMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(SaleAccount record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.SaleAccountMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<SaleAccount> querySaleAccountList(Map<String, Object> map,PageBean page) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.SaleAccountDao.querySaleAccountListCount","cn.comshinetechchina.hyjxyl.dao.SaleAccountDao.querySaleAccountList",map);
    }
}
