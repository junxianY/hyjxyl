package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.CardTypeDao;
import cn.comshinetechchina.hyjxyl.domain.CardType;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("cardTypeDao")
public class CardTypeDaoImpl extends AbstractBaseDao implements CardTypeDao {
    @Override
    public int deleteByPrimaryKey(String cardTypeId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeMapper.deleteByPrimaryKey",cardTypeId);
    }

    @Override
    public int insert(CardType record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeMapper.insert",record);
    }

    @Override
    public int insertSelective(CardType record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeMapper.insertSelective",record);
    }

    @Override
    public CardType selectByPrimaryKey(String cardTypeId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeMapper.selectByPrimaryKey",cardTypeId);
    }

    @Override
    public int updateByPrimaryKeySelective(CardType record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(CardType record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<CardType> selectAllCardTypes(Map<String,Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.CardTypeDao.selectAllCardTypes",map);
    }
}
