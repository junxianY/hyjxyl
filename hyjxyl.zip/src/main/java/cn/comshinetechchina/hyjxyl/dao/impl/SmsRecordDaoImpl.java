package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.SmsRecordDao;
import cn.comshinetechchina.hyjxyl.domain.SmsRecord;
import org.springframework.stereotype.Service;

@Service("smsRecordDao")
public class SmsRecordDaoImpl extends AbstractBaseDao implements SmsRecordDao {
    @Override
    public int deleteByPrimaryKey(String id) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.SmsRecordMapper.deleteByPrimaryKey",id);
    }

    @Override
    public int insert(SmsRecord record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.SmsRecordMapper.insert",record);
    }

    @Override
    public int insertSelective(SmsRecord record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.SmsRecordMapper.insertSelective",record);
    }

    @Override
    public SmsRecord selectByPrimaryKey(String id) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.SmsRecordMapper.selectByPrimaryKey",id);
    }

    @Override
    public int updateByPrimaryKeySelective(SmsRecord record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.SmsRecordMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(SmsRecord record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.SmsRecordMapper.updateByPrimaryKey",record);
    }
}
