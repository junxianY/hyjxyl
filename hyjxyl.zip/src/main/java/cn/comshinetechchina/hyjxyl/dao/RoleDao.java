package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.RoleMapper;
import cn.comshinetechchina.hyjxyl.domain.Role;
import cn.comshinetechchina.hyjxyl.domain.RoleFunction;

import java.util.List;

public interface RoleDao extends RoleMapper {
    /**
     * 通过角色id查询其菜单权限
     * @param roleId
     * @return
     */
    public List<RoleFunction> selectRoleFunctionList(Integer roleId);

    /**
     * 查询角色列表
     * @return
     */
    public List<Role> selectRoleList();
}
