package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.AreaDao;
import cn.comshinetechchina.hyjxyl.domain.Area;
import cn.comshinetechchina.hyjxyl.domain.PcaObj2;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("areaDao")
public class AreaDaoImpl extends AbstractBaseDao implements AreaDao {
    @Override
    public int deleteByPrimaryKey(Integer areaId) {
        return 0;
    }

    @Override
    public int insert(Area record) {
        return 0;
    }

    @Override
    public int insertSelective(Area record) {
        return 0;
    }

    @Override
    public Area selectByPrimaryKey(Integer areaId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.AreaMapper.selectByPrimaryKey",areaId);
    }

    @Override
    public int updateByPrimaryKeySelective(Area record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(Area record) {
        return 0;
    }

    @Override
    public List<Area> selectAreaList(String cityId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.AreaDao.selectAreaList",cityId);
    }

    @Override
    public List<PcaObj2> selectPcaObj2List(String cityId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.AreaDao.selectPcaObj2List",cityId);
    }
}
