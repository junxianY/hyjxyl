package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.LocationMapper;
import cn.comshinetechchina.hyjxyl.domain.Location;

import java.util.List;
import java.util.Map;

public interface LocationDao extends LocationMapper {
    /**
     * 查询地图位置信息
     * @param page
     * @param map
     * @return
     */
   public List<Location> selectLocationList(PageBean page, Map<String,Object> map);
}
