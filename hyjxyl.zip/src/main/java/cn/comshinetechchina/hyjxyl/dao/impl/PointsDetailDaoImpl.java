package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.PointsDetailDao;
import cn.comshinetechchina.hyjxyl.domain.PointsDetail;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service("pointsDetailDao")
public class PointsDetailDaoImpl extends AbstractBaseDao implements PointsDetailDao {

    @Override
    public List<PointsDetail> selectPointsDetailList(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.PointsDetailDao.selectPointsDetailList",map);
    }

    @Override
    public int deleteByPrimaryKey(String pointsDetailId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.PointsDetailMapper.deleteByPrimaryKey",pointsDetailId);
    }

    @Override
    public int insert(PointsDetail record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.PointsDetailMapper.insert",record);
    }

    @Override
    public int insertSelective(PointsDetail record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.PointsDetailMapper.insertSelective",record);
    }

    @Override
    public PointsDetail selectByPrimaryKey(String pointsDetailId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.PointsDetailMapper.selectByPrimaryKey",pointsDetailId);
    }

    @Override
    public int updateByPrimaryKeySelective(PointsDetail record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.PointsDetailMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(PointsDetail record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.PointsDetailMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<PointsDetail> selectPointsDetailListByPage(Map<String, Object> map, PageBean bean) {
        return this.queryForPaginatedList(bean,"cn.comshinetechchina.hyjxyl.dao.PointsDetailDao.selectPointsDetailListCount","cn.comshinetechchina.hyjxyl.dao.PointsDetailDao.selectPointsDetailList",map);
    }
}
