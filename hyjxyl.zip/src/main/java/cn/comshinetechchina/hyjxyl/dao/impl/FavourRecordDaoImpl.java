package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.FavourRecordDao;
import cn.comshinetechchina.hyjxyl.domain.FavourRecord;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service("favourRecordDao")
public class FavourRecordDaoImpl extends AbstractBaseDao implements FavourRecordDao {
    @Override
    public int deleteByPrimaryKey(String favourId) {
        return 0;
    }

    @Override
    public int insert(FavourRecord record) {
        return 0;
    }

    @Override
    public int insertSelective(FavourRecord record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.FavourRecordMapper.insertSelective",record);
    }

    @Override
    public FavourRecord selectByPrimaryKey(String favourId) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(FavourRecord record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(FavourRecord record) {
        return 0;
    }

    @Override
    public FavourRecord selectOneFavourRecord(String refId, String refType, String memberId) {
        Map<String,String> map=new HashMap<String,String>();
        map.put("refId",refId);
        map.put("refType",refType);
        map.put("memberId",memberId);
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.FavourRecordDao.selectOneFavourRecord",map);
    }
}
