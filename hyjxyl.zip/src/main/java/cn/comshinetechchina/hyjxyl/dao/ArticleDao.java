package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.ArticleMapper;
import cn.comshinetechchina.hyjxyl.domain.Article;
import cn.comshinetechchina.hyjxyl.domain.ArticleObj;

import java.util.List;
import java.util.Map;

public interface ArticleDao extends ArticleMapper{
    public List<ArticleObj> selectArticleList(Map<String,Object> map, PageBean bean);
    /**
     * 批量更新活动资讯浏览量接口
     * @param list
     * @return
     */
    public int updateArticleArticleScol(List<String> list);
    /**
     * banner 获取随机五条活动资讯
     * @return
     */
    public List<ArticleObj> selectRandom5Articles();
    /**
     * 查询某类型的编号是否存在
     * @param article
     * @return
     */
    Map  selectOneByOrderNo(Article article);
}
