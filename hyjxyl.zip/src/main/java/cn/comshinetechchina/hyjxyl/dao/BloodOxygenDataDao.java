package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.BloodOxygenDataMapper;
import cn.comshinetechchina.hyjxyl.domain.BloodOxygenData;

import java.util.List;
import java.util.Map;

/**
 * 数据中心-血氧
 */
public interface BloodOxygenDataDao extends BloodOxygenDataMapper{
    /**
     * 分页查询血氧数据
     * @param page
     * @param map
     * @return
     */
    public List<BloodOxygenData> selectBloodOxygenDataList(PageBean page, Map<String, Object> map);
    /**
     * 查询某客户血氧数据
     * @param memberId
     * @return
     */
    List<BloodOxygenData> selectMemberBloodOxygenDataList(String memberId);
}
