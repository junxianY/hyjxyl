package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.MessageDao;
import cn.comshinetechchina.hyjxyl.domain.Message;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("messageDao")
public class MessageDaoImpl  extends AbstractBaseDao implements MessageDao {
    @Override
    public int deleteByPrimaryKey(String messageId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.MessageMapper.deleteByPrimaryKey",messageId);
    }

    @Override
    public int insert(Message record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.MessageMapper.insert",record);
    }

    @Override
    public int insertSelective(Message record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.MessageMapper.insertSelective",record);
    }

    @Override
    public Message selectByPrimaryKey(String messageId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.MessageMapper.selectByPrimaryKey",messageId);
    }

    @Override
    public int updateByPrimaryKeySelective(Message record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.MessageMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Message record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.MessageMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<Message> selectMessageList(Map<String, String> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.MessageDao.selectMessageList",map);
    }
}
