package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.RoleDao;
import cn.comshinetechchina.hyjxyl.domain.Role;
import cn.comshinetechchina.hyjxyl.domain.RoleFunction;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("roleDao")
public class RoleDaoImpl extends AbstractBaseDao implements RoleDao {

    @Override
    public int deleteByPrimaryKey(Integer roleId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.RoleMapper.deleteByPrimaryKey",roleId);
    }

    @Override
    public int insert(Role record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.RoleMapper.insert",record);
    }

    @Override
    public int insertSelective(Role record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.RoleMapper.insertSelective",record);
    }

    @Override
    public Role selectByPrimaryKey(Integer roleId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.RoleMapper.selectByPrimaryKey",roleId);
    }

    @Override
    public int updateByPrimaryKeySelective(Role record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.RoleMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Role record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.RoleMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<RoleFunction> selectRoleFunctionList(Integer roleId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.RoleDao.selectRoleFunctionList",roleId);
    }

    @Override
    public List<Role> selectRoleList() {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.RoleDao.selectRoleList",null);
    }
}
