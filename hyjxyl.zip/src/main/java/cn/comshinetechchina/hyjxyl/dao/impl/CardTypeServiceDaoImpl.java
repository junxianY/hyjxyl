package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.CardTypeServiceDao;
import cn.comshinetechchina.hyjxyl.domain.CardTypeService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service("cardTypeServiceDao")
public class CardTypeServiceDaoImpl extends AbstractBaseDao implements CardTypeServiceDao {
    @Override
    public int deleteByPrimaryKey(String cardTypeServiceId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeServiceMapper.deleteByPrimaryKey",cardTypeServiceId);
    }

    @Override
    public int insert(CardTypeService record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeServiceMapper.insert",record);
    }

    @Override
    public int insertSelective(CardTypeService record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeServiceMapper.insertSelective",record);
    }

    @Override
    public CardTypeService selectByPrimaryKey(String cardTypeServiceId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeServiceMapper.selectByPrimaryKey",cardTypeServiceId);
    }

    @Override
    public int updateByPrimaryKeySelective(CardTypeService record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeServiceMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(CardTypeService record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardTypeServiceMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<CardTypeService> selectCardTypeServiceList(Map<String, String> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.CardTypeServiceDao.selectCardTypeServiceList",map);
    }

    @Override
    public int batchInsertSelective(List<CardTypeService> list) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.CardTypeServiceDao.batchInsertCardTypeService",list);
    }

    @Override
    public int deleteRecordByPara(String cardTypeId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.CardTypeServiceDao.deleteRecordByPara",cardTypeId);
    }
}
