package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.PhoneCodeDao;
import cn.comshinetechchina.hyjxyl.domain.PhoneCode;
import org.springframework.stereotype.Service;

@Service("phoneCodeDao")
public class PhoneCodeDaoImpl extends AbstractBaseDao implements PhoneCodeDao {
    @Override
    public int deleteByPrimaryKey(String phone) {
        return 0;
    }

    @Override
    public int insert(PhoneCode record) {
        return 0;
    }

    @Override
    public int insertSelective(PhoneCode record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.PhoneCodeMapper.insertSelective",record);
    }

    @Override
    public PhoneCode selectByPrimaryKey(String phone) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.PhoneCodeMapper.selectByPrimaryKey",phone);
    }

    @Override
    public int updateByPrimaryKeySelective(PhoneCode record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.PhoneCodeMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(PhoneCode record) {
        return 0;
    }
}
