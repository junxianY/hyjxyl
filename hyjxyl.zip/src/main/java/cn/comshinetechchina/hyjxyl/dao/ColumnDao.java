package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.ColumnMapper;
import cn.comshinetechchina.hyjxyl.domain.Column;

import java.util.List;
import java.util.Map;

public interface ColumnDao extends ColumnMapper {
    public List<Column> queryColumnList(Map<String,String> map);
}
