package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.UserMapper;
import cn.comshinetechchina.hyjxyl.domain.User;

import java.util.List;
import java.util.Map;

public interface UserDao extends UserMapper{
    /**
     * 查询用户信息
     * @param userName
     * @param password
     * @return
     */
    public User selectUserByPara(String userName, String password);
    /**
     * 根据条件查询用户列表
     * @param map
     * @return
     */
    public List<User> selectUserList(Map<String,Object> map);
}
