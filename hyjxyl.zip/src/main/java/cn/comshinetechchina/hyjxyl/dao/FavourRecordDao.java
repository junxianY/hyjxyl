package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.FavourRecordMapper;
import cn.comshinetechchina.hyjxyl.domain.FavourRecord;

public interface FavourRecordDao extends FavourRecordMapper {
    /**
     * 查询某客户对某篇活动的最后点赞信息
     * @param refId
     * @param refType
     * @param memberId
     * @return
     */
    public FavourRecord selectOneFavourRecord(String refId, String refType, String memberId);
}
