package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.CardLeftNumberDao;
import cn.comshinetechchina.hyjxyl.domain.CardLeftNumber;
import cn.comshinetechchina.hyjxyl.domain.CardLeftNumberKey;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("cardLeftNumberDao")
public class CardLeftNumberDaoImpl extends AbstractBaseDao implements CardLeftNumberDao {
    @Override
    public int deleteByPrimaryKey(CardLeftNumberKey key) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.CardLeftNumberMapper.deleteByPrimaryKey",key);
    }

    @Override
    public int insert(CardLeftNumber record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardLeftNumberMapper.insert",record);
    }

    @Override
    public int insertSelective(CardLeftNumber record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardLeftNumberMapper.insertSelective",record);
    }

    @Override
    public CardLeftNumber selectByPrimaryKey(CardLeftNumberKey key) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.CardLeftNumberMapper.selectByPrimaryKey",key);
    }

    @Override
    public int updateByPrimaryKeySelective(CardLeftNumber record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardLeftNumberMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(CardLeftNumber record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardLeftNumberMapper.updateByPrimaryKey",record);
    }
    @Override
    public int batchInsertRecord(List<CardLeftNumber> list) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.CardLeftNumberDao.batchInsertRecord",list);
    }

    @Override
    public List<CardLeftNumber> selectCardLeftNumberList(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.CardLeftNumberDao.selectCardLeftNumberList",map);
    }

    @Override
    public int changeCardNo(String oldCardNo, String newCardNo) {
        Map<String,String> map=new HashMap<String,String>();
        map.put("oldCardNo",oldCardNo);
        map.put("newCardNo",newCardNo);
        if(StringUtils.isNotBlank(oldCardNo)&&StringUtils.isNotBlank(newCardNo)){
            return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.CardLeftNumberDao.updateCardNo",map);
        }else{
            return 0;
        }

    }

    @Override
    public int updateLeftNumberAvailable(String cardNo) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.CardLeftNumberDao.updateLeftNumberAvailable",cardNo);
    }

    @Override
    public int deleteInfoByPara(String cardNo) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.CardLeftNumberDao.deleteInfoByPara",cardNo);
    }

    @Override
    public int delRecordByTask(Date endDate) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("endDate",endDate);
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.CardLeftNumberDao.delRecordByTask",map);
    }
}
