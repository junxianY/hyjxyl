package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.CardNumberChangeRecordDao;
import cn.comshinetechchina.hyjxyl.domain.CardNumberChangeRecord;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("cardNumberChangeRecordDao")
public class CardNumberChangeRecordDaoImpl extends AbstractBaseDao implements CardNumberChangeRecordDao {
    @Override
    public int deleteByPrimaryKey(String recordId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.CardNumberChangeRecordMapper.deleteByPrimaryKey",recordId);
    }

    @Override
    public int insert(CardNumberChangeRecord record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardNumberChangeRecordMapper.insert",record);
    }

    @Override
    public int insertSelective(CardNumberChangeRecord record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardNumberChangeRecordMapper.insertSelective",record);
    }

    @Override
    public CardNumberChangeRecord selectByPrimaryKey(String recordId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.CardNumberChangeRecordMapper.selectByPrimaryKey",recordId);
    }

    @Override
    public int updateByPrimaryKeySelective(CardNumberChangeRecord record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardNumberChangeRecordMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(CardNumberChangeRecord record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardNumberChangeRecordMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<CardNumberChangeRecord> selectChangeRecordList(String cardNo, String serviceId) {
        Map<String,String> map=new HashMap<String,String>();
        map.put("cardNo",cardNo);
        map.put("serviceId",serviceId);
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.CardNumberChangeRecordDao.selectChangeRecordList",map);
    }
}
