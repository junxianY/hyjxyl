package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.RoleFuncMapper;
import cn.comshinetechchina.hyjxyl.domain.RoleFuncKey;

import java.util.List;

/**
 * 角色功能
 */
public interface RoleFuncDao extends RoleFuncMapper{
    /**
     * 删除某角色所有权限
     * @param roleId
     * @return
     */
    public int deleteRoleFunctions(Integer roleId);

    /**
     * 批量给角色授权
     * @param list
     * @return
     */
    public int batchInsertRoleFunc(List<RoleFuncKey> list);

    /**
     * 查询某角色功能权限
     * @param roleId
     * @return
     */
    public List<RoleFuncKey> selectRoleFuncList(Integer roleId);
}
