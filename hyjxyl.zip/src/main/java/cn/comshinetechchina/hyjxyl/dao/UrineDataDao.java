package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.UrineDataMapper;
import cn.comshinetechchina.hyjxyl.domain.UrineData;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 尿液分析持久层
 */
public interface UrineDataDao extends UrineDataMapper {
    /**
     * 倒序查询列表
     * @param map
     * @param page
     * @return
     */
    public List<UrineData> selectUrineDataList(PageBean page, Map<String,Object> map);
    /**
     * 查询用户尿液信息
     * @param memberId
     * @return
     */
    List<UrineData> selectMemberUrineDataList(String memberId);

    /**
     * 根据检测时间判断表中是否存在
     * @param testTime
     * @param tableName
     * @return
     */
    Map<String,Object> selectOneData(Date testTime,String tableName);
}
