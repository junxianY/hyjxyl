package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.AdviceDao;
import cn.comshinetechchina.hyjxyl.domain.Advice;
import cn.comshinetechchina.hyjxyl.domain.AdviceObj;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("adviceDao")
public class AdviceDaoImpl extends AbstractBaseDao implements AdviceDao {
    @Override
    public int deleteByPrimaryKey(String adviceId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.AdviceMapper.deleteByPrimaryKey",adviceId);
    }

    @Override
    public int insert(Advice record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.AdviceMapper.insert",record);
    }

    @Override
    public int insertSelective(Advice record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.AdviceMapper.insertSelective",record);
    }

    @Override
    public Advice selectByPrimaryKey(String adviceId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.AdviceMapper.selectByPrimaryKey",adviceId);
    }

    @Override
    public int updateByPrimaryKeySelective(Advice record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.AdviceMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Advice record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.AdviceMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<AdviceObj> selectAdviceList(PageBean page, Map<String, String> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.AdviceDao.selectAdviceListCount","cn.comshinetechchina.hyjxyl.dao.AdviceDao.selectAdviceList",map);
    }
}
