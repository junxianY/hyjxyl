package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.LocationDao;
import cn.comshinetechchina.hyjxyl.domain.Location;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("locationDao")
public class LocationDaoImpl extends AbstractBaseDao implements LocationDao {
    @Override
    public int deleteByPrimaryKey(String locationId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.LocationMapper.deleteByPrimaryKey",locationId);
    }

    @Override
    public int insert(Location record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.LocationMapper.insert",record);
    }

    @Override
    public int insertSelective(Location record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.LocationMapper.insertSelective",record);
    }

    @Override
    public Location selectByPrimaryKey(String locationId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.LocationMapper.selectByPrimaryKey",locationId);
    }

    @Override
    public int updateByPrimaryKeySelective(Location record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.LocationMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Location record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.LocationMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<Location> selectLocationList(PageBean page, Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.LocationDao.selectLocationListCount","cn.comshinetechchina.hyjxyl.dao.LocationDao.selectLocationList",map);
    }
}
