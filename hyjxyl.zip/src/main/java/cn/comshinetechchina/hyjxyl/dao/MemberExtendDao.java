package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.MemberExtendMapper;
import cn.comshinetechchina.hyjxyl.domain.MemberExtend;

import java.util.List;

public interface MemberExtendDao extends MemberExtendMapper{
    /**
     * 通过参数查询用户信息
     * @param record
     * @return
     */
    public List<MemberExtend> selectMemberExtendList(MemberExtend record);
}
