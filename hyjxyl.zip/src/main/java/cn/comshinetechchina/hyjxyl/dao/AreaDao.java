package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.AreaMapper;
import cn.comshinetechchina.hyjxyl.domain.Area;
import cn.comshinetechchina.hyjxyl.domain.PcaObj2;

import java.util.List;

public interface AreaDao extends AreaMapper{
    /**
     * 通过城市查询下属区域列表
     * @param cityId
     * @return
     */
    public List<Area> selectAreaList(String cityId);
    /**
     * 查询tree
     * @param cityId
     * @return
     */
    public List<PcaObj2> selectPcaObj2List(String cityId);
}
