package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.CityMapper;
import cn.comshinetechchina.hyjxyl.domain.City;

import java.util.List;

public interface CityDao extends CityMapper{
    /**
     * 查询城市列表
     * @param provinceId
     * @return
     */
  public List<City> selectCityList(String provinceId);
}
