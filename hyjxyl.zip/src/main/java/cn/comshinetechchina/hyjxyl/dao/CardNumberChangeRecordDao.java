package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.CardNumberChangeRecordMapper;
import cn.comshinetechchina.hyjxyl.domain.CardNumberChangeRecord;

import java.util.List;

public interface CardNumberChangeRecordDao extends CardNumberChangeRecordMapper {
    public List<CardNumberChangeRecord> selectChangeRecordList(String cardNo, String serviceId);
}
