package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.PushMemberDao;
import cn.comshinetechchina.hyjxyl.domain.PushMember;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("pushMemberDao")
public class PushMemberDaoImpl extends AbstractBaseDao implements PushMemberDao {
    @Override
    public int deleteByPrimaryKey(String id) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.PushMemberMapper.deleteByPrimaryKey",id);
    }

    @Override
    public int insert(PushMember record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.PushMemberMapper.insert",record);
    }

    @Override
    public int insertSelective(PushMember record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.PushMemberMapper.insertSelective",record);
    }

    @Override
    public PushMember selectByPrimaryKey(String id) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.PushMemberMapper.selectByPrimaryKey",id);
    }

    @Override
    public int updateByPrimaryKeySelective(PushMember record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.PushMemberMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(PushMember record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.PushMemberMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<PushMember> selectPushMembersList(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.PushMemberDao.selectPushMembersList",map);
    }

    @Override
    public int updatePushMember(PushMember record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.PushMemberDao.updatePushMember",record);
    }

    @Override
    public int delPushMemberByClientId(String clientId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.PushMemberDao.delPushMemberByClientId",clientId);
    }
}
