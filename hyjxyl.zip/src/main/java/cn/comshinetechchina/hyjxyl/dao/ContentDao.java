package cn.comshinetechchina.hyjxyl.dao;
import cn.comshinetechchina.hyjxyl.dao.mapper.ContentMapper;
import cn.comshinetechchina.hyjxyl.domain.Content;

import java.util.List;

public interface ContentDao extends ContentMapper{
    /**
     * 通过业务id查询其附近信息(倒序排列)
     * @param busiId  业务id
     * @param tableName 业务表名
     * @param contentTypeId 附件类型
     * @return
     */
    public List<Content> selectContentsById(String busiId, String tableName,String contentTypeId);
}
