package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.KithAndKinMapper;
import cn.comshinetechchina.hyjxyl.domain.KithAndKin;

import java.util.List;
import java.util.Map;

public interface KithAndKinDao extends KithAndKinMapper {
    /**
     * 查询某用户亲属列表
     * @param memberId
     * @return
     */
    public List<KithAndKin> selectUserKithList(String memberId);
    /**
     *
     * 通过条件查询亲友信息
     * @param memberId
     * @param nickMemberId
     * @param nickName
     * @param available
     * @return
     */
    public List<KithAndKin> selectKithListByPara(String memberId,String nickMemberId,String nickName,String available);

    /**
     * 通过条件查询某用户特别关心的有效亲属列表
     * @param memberId
     * @param concern
     * @return
     */
    public List<KithAndKin> selectUserKithList(String memberId,int concern);

    /**
     *
     * 通过条件查询亲友信息
     * @param map
     * @return
     */
    List<KithAndKin> selectKithListByPara(Map<String,Object> map);
}
