package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.PointDao;
import cn.comshinetechchina.hyjxyl.domain.Point;
import org.springframework.stereotype.Service;

@Service("pointDao")
public class PointDaoImpl extends AbstractBaseDao implements PointDao {

    @Override
    public int deleteByPrimaryKey(String memberId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.PointMapper.deleteByPrimaryKey",memberId);
    }

    @Override
    public int insert(Point record) {
        return 0;
    }

    @Override
    public int insertSelective(Point record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.PointMapper.insertSelective",record);
    }

    @Override
    public Point selectByPrimaryKey(String memberId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.PointMapper.selectByPrimaryKey",memberId);
    }

    @Override
    public int updateByPrimaryKeySelective(Point record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.PointMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Point record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.PointMapper.updateByPrimaryKey",record);
    }
}
