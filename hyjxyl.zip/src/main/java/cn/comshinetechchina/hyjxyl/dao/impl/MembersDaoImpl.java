package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.MembersDao;
import cn.comshinetechchina.hyjxyl.domain.MemberInfo;
import cn.comshinetechchina.hyjxyl.domain.MemberInfoObj;
import cn.comshinetechchina.hyjxyl.domain.MemberObj;
import cn.comshinetechchina.hyjxyl.domain.Members;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("membersDao")
public class MembersDaoImpl extends AbstractBaseDao implements MembersDao {
    private static final Logger log= LoggerFactory.getLogger(MembersDaoImpl.class);
    @Override
    public Members selectOneMembers(String phoneNo,String token) {
        Map<String,String> map=new HashMap<String,String>();
        map.put("phoneNo",phoneNo);
        map.put("token",token);
        log.info("Terry ->token " + token);
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.MembersDao.selectOneMembers",map);
    }

    @Override
    public int deleteByPrimaryKey(String memberId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.MembersMapper.deleteByPrimaryKey",memberId);
    }

    @Override
    public int insert(Members record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.MembersMapper.insert",record);
    }

    @Override
    public int insertSelective(Members record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.MembersMapper.insertSelective",record);
    }

    @Override
    public Members selectByPrimaryKey(String memberId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.MembersMapper.selectByPrimaryKey",memberId);
    }

    @Override
    public int updateByPrimaryKeySelective(Members record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.MembersMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Members record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.MembersMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<MemberInfo> selectMemberInfoList(Map<String, String> map,PageBean bean) {
       return this.queryForPaginatedList(bean,"cn.comshinetechchina.hyjxyl.dao.MembersDao.selectMemberInfoListCount","cn.comshinetechchina.hyjxyl.dao.MembersDao.selectMemberInfoList",map);
    }

    @Override
    public MemberInfo selectMemberInfoDetail(String memberId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.MembersDao.selectMemberInfoDetail",memberId);
    }

    @Override
    public int batchUpdateMemberStatus(List<String> list, int available) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("list",list);
        map.put("available",available);
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.MembersDao.batchUpdateMemberStatus",map);
    }

    @Override
    public MemberInfoObj selectMemberInfoObjDetail(String memberId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.MembersDao.selectMemberInfoObjDetail",memberId);
    }

    @Override
    public MemberInfoObj selectOneMember(String openId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.MembersDao.selectOneMemberByOpenId",openId);
    }

    @Override
    public int updateMembersToken(String memberId) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.MembersDao.updateMembersToken",memberId);
    }

    @Override
    public MemberObj getMemberByPara(Map<String,Object> map) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.MembersDao.getMemberByPara",map);
    }
}
