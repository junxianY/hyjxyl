package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.UserDao;
import cn.comshinetechchina.hyjxyl.domain.User;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("userDao")
public class UserDaoImpl extends AbstractBaseDao implements UserDao {
    @Override
    public int deleteByPrimaryKey(String userId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.UserMapper.deleteByPrimaryKey",userId);
    }

    @Override
    public int insert(User record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.UserMapper.insert",record);
    }

    @Override
    public int insertSelective(User record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.UserMapper.insertSelective",record);
    }

    @Override
    public User selectByPrimaryKey(String userId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.UserMapper.selectByPrimaryKey",userId);
    }

    @Override
    public int updateByPrimaryKeySelective(User record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.UserMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(User record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.UserMapper.updateByPrimaryKey",record);
    }

    @Override
    public User selectUserByPara(String userName, String password) {
        Map<String,String> map=new HashMap<String,String>();
        map.put("userName",userName);
        map.put("password",password);
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.UserDao.selectUserByPara",map);
    }

    @Override
    public List<User> selectUserList(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.UserDao.selectUserList",map);
    }
}
