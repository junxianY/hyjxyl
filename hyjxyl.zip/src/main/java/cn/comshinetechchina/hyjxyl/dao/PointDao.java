package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.PointMapper;

/**
 * 积分数据层
 */
public interface PointDao extends PointMapper{

}
