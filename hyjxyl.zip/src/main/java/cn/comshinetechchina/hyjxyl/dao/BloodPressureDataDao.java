package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.BloodPressureDataMapper;
import cn.comshinetechchina.hyjxyl.domain.BloodPressureData;

import java.util.List;
import java.util.Map;

/**
 * 数据中心-血压
 */
public interface BloodPressureDataDao extends BloodPressureDataMapper {
    /**
     * 查询血压列表
     * @param page
     * @param map
     * @return
     */
    public List<BloodPressureData> selectBloodPressureDataList(PageBean page, Map<String,Object> map);
    /**
     * 通过个人id查询体检信息
     * @param memberId
     * @return
     */
    public List<BloodPressureData> selectMemberBloodPressureDataList(String memberId);
}
