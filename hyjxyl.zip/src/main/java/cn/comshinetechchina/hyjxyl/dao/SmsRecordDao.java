package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.SmsRecordMapper;

public interface SmsRecordDao extends SmsRecordMapper {

}
