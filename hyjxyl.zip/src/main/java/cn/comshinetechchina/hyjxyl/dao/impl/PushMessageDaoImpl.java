package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.PushMessageDao;
import cn.comshinetechchina.hyjxyl.domain.PushMessage;
import cn.comshinetechchina.hyjxyl.domain.PushMessageObj;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("pushMessageDao")
public class PushMessageDaoImpl extends AbstractBaseDao implements PushMessageDao {
    @Override
    public int deleteByPrimaryKey(String id) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.PushMessageMapper.deleteByPrimaryKey",id);
    }

    @Override
    public int insert(PushMessage record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.PushMessageMapper.insert",record);
    }

    @Override
    public int insertSelective(PushMessage record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.PushMessageMapper.insertSelective",record);
    }

    @Override
    public PushMessage selectByPrimaryKey(String id) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.PushMessageMapper.selectByPrimaryKey",id);
    }

    @Override
    public int updateByPrimaryKeySelective(PushMessage record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.PushMessageMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(PushMessage record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.PushMessageMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<PushMessageObj> selectPushMessageList(PageBean page, Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.PushMessageDao.selectPushMessageListCount","cn.comshinetechchina.hyjxyl.dao.PushMessageDao.selectPushMessageList",map);
    }

    @Override
    public int batchUpdateMessageStatus(List<String> list) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.PushMessageDao.batchUpdateMessageState",list);
    }
}
