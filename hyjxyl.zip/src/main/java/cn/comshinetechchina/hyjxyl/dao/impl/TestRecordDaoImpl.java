package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.TestRecordDao;
import cn.comshinetechchina.hyjxyl.domain.TestRecord;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("testRecordDao")
public class TestRecordDaoImpl extends AbstractBaseDao implements TestRecordDao {
    @Override
    public int deleteByPrimaryKey(String id) {
        return 0;
    }

    @Override
    public int insert(TestRecord record) {
        return 0;
    }

    @Override
    public int insertSelective(TestRecord record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.TestRecordMapper.insertSelective",record);
    }

    @Override
    public TestRecord selectByPrimaryKey(String id) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.TestRecordMapper.selectByPrimaryKey",id);
    }

    @Override
    public int updateByPrimaryKeySelective(TestRecord record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKeyWithBLOBs(TestRecord record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.TestRecordMapper.updateByPrimaryKeyWithBLOBs",record);
    }

    @Override
    public int updateByPrimaryKey(TestRecord record) {
        return 0;
    }

    @Override
    public List<TestRecord> selectTestRecordList(Map<String, Object> map,PageBean bean) {
        return this.queryForPaginatedList(bean,"cn.comshinetechchina.hyjxyl.dao.TestRecordDao.selectTestRecordListCount","cn.comshinetechchina.hyjxyl.dao.TestRecordDao.selectTestRecordList",map);
    }

    @Override
    public List<TestRecord> selectAllTestRecordList(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.TestRecordDao.selectAllTestRecordList",map);
    }
}
