package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.TenantDao;
import cn.comshinetechchina.hyjxyl.domain.Tenant;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("tenantDao")
public class TenantDaoImpl extends AbstractBaseDao implements TenantDao {
    @Override
    public int deleteByPrimaryKey(String tenantId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.TenantMapperdeleteByPrimaryKey",tenantId);
    }

    @Override
    public int insert(Tenant record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.TenantMapperinsert",record);
    }

    @Override
    public int insertSelective(Tenant record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.TenantMapper.insertSelective",record);
    }

    @Override
    public Tenant selectByPrimaryKey(String tenantId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.TenantMapper.selectByPrimaryKey",tenantId);
    }

    @Override
    public int updateByPrimaryKeySelective(Tenant record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.TenantMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Tenant record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.TenantMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<Tenant> selectTenantList(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.TenantDao.selectTenantList",map);
    }
}
