package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.CommentDao;
import cn.comshinetechchina.hyjxyl.domain.Comment;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service("commentDao")
public class CommentDaoImpl extends AbstractBaseDao implements CommentDao {
    @Override
    public int deleteByPrimaryKey(String commentId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.CommentMapper.deleteByPrimaryKey",commentId);
    }

    @Override
    public int insert(Comment record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CommentMapper.insert",record);
    }

    @Override
    public int insertSelective(Comment record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CommentMapper.insertSelective",record);
    }

    @Override
    public Comment selectByPrimaryKey(String commentId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.CommentMapper.selectByPrimaryKey",commentId);
    }

    @Override
    public int updateByPrimaryKeySelective(Comment record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CommentMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Comment record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CommentMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<Comment> selectCommentList(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.CommentDao.selectCommentList",map);
    }
}
