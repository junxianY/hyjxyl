package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.ContentTypeMapper;
import cn.comshinetechchina.hyjxyl.domain.ContentType;

public interface ContentTypeDao extends ContentTypeMapper {
    /**
     * 查询附件类型
     * @param typeCode
     * @param isActive
     * @return
     */
  public ContentType selectOneContentType(String typeCode,int isActive);
}
