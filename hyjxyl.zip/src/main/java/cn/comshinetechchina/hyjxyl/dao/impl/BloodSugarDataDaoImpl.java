package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.BloodSugarDataDao;
import cn.comshinetechchina.hyjxyl.domain.BloodSugarData;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("bloodSugarDataDao")
public class BloodSugarDataDaoImpl extends AbstractBaseDao implements BloodSugarDataDao {
    @Override
    public int deleteByPrimaryKey(String id) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.BloodSugarDataMapper.deleteByPrimaryKey",id);
    }

    @Override
    public int insert(BloodSugarData record) {
        return 0;
    }

    @Override
    public int insertSelective(BloodSugarData record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.BloodSugarDataMapper.insertSelective",record);
    }

    @Override
    public BloodSugarData selectByPrimaryKey(String id) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(BloodSugarData record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(BloodSugarData record) {
        return 0;
    }

    @Override
    public List<BloodSugarData> selectBloodSugarDataList(PageBean page, Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.BloodSugarDataDao.selectBloodSugarDataListCount","cn.comshinetechchina.hyjxyl.dao.BloodSugarDataDao.selectBloodSugarDataList",map);
    }

    @Override
    public List<BloodSugarData> selectMemberBloodSugarDataList(String memberId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.BloodSugarDataDao.selectMemberBloodSugarDataList",memberId);
    }
}
