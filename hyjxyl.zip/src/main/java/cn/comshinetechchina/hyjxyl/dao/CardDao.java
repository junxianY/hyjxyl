package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.CardMapper;
import cn.comshinetechchina.hyjxyl.domain.Card;
import cn.comshinetechchina.hyjxyl.domain.CardObj;
import cn.comshinetechchina.hyjxyl.domain.MemberInfo;

import java.util.List;
import java.util.Map;

public interface CardDao extends CardMapper {
    /**
     * 查询一卡通列表
     * @param map
     * @return
     */
    public List<CardObj> selectCardList(Map<String,Object> map);

    /**
     * 批量更新卡状态接口
     * @param list  卡编号列表
     * @param available 状态 1启用 0停用
     * @return
     */
    public int batchUpdateCardStatus(List<String> list,int available);

    /**
     * 分页查询一卡通列表
     * @param map
     * @param bean
     * @return
     */
    public List<MemberInfo> selectCardMemberList(Map<String,String> map, PageBean bean);
}
