package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.UrineDataDao;
import cn.comshinetechchina.hyjxyl.domain.UrineData;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("urineDataDao")
public class UrineDataDaoImpl extends AbstractBaseDao implements UrineDataDao {
    @Override
    public int deleteByPrimaryKey(String id) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.UrineDataMapper.deleteByPrimaryKey",id);
    }

    @Override
    public int insert(UrineData record) {
        return 0;
    }

    @Override
    public int insertSelective(UrineData record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.UrineDataMapper.insertSelective",record);
    }

    @Override
    public UrineData selectByPrimaryKey(String id) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(UrineData record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(UrineData record) {
        return 0;
    }

    @Override
    public List<UrineData> selectUrineDataList(PageBean page, Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.UrineDataDao.selectUrineDataListCount","cn.comshinetechchina.hyjxyl.dao.UrineDataDao.selectUrineDataList",map);
    }

    @Override
    public List<UrineData> selectMemberUrineDataList(String memberId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.UrineDataDao.selectMemberUrineDataList",memberId);
    }

    @Override
    public Map<String, Object> selectOneData(Date testTime, String tableName) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("testTime",testTime);
        map.put("tableName",tableName);
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.UrineDataDao.selectOneData",map);
    }
}
