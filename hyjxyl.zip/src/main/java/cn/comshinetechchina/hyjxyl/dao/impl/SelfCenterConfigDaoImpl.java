package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.SelfCenterConfigDao;
import cn.comshinetechchina.hyjxyl.domain.SelfCenterConfig;
import org.springframework.stereotype.Service;

@Service("selfCenterConfigDao")
public class SelfCenterConfigDaoImpl extends AbstractBaseDao implements SelfCenterConfigDao {

    @Override
    public int deleteByPrimaryKey(String memberId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.SelfCenterConfigMapper.deleteByPrimaryKey",memberId);
    }

    @Override
    public int insert(SelfCenterConfig record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.SelfCenterConfigMapper.insert",record);
    }

    @Override
    public int insertSelective(SelfCenterConfig record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.SelfCenterConfigMapper.insertSelective",record);
    }

    @Override
    public SelfCenterConfig selectByPrimaryKey(String memberId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.SelfCenterConfigMapper.selectByPrimaryKey",memberId);
    }

    @Override
    public int updateByPrimaryKeySelective(SelfCenterConfig record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.SelfCenterConfigMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(SelfCenterConfig record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.SelfCenterConfigMapper.updateByPrimaryKey",record);
    }
}
