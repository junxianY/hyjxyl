package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.BloodSugarDataMapper;
import cn.comshinetechchina.hyjxyl.domain.BloodSugarData;

import java.util.List;
import java.util.Map;

/**
 * 血糖持久层
 */
public interface BloodSugarDataDao  extends BloodSugarDataMapper{
    /**
     * 查询血糖列表
     * @param page
     * @param map
     * @return
     */
    public List<BloodSugarData> selectBloodSugarDataList(PageBean page, Map<String,Object> map);
    /**
     * 通过个人id查询其体检信息
     * @param memberId
     * @return
     */
    public List<BloodSugarData> selectMemberBloodSugarDataList(String memberId);
}
