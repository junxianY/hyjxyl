package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.MembersMapper;
import cn.comshinetechchina.hyjxyl.domain.MemberInfo;
import cn.comshinetechchina.hyjxyl.domain.MemberInfoObj;
import cn.comshinetechchina.hyjxyl.domain.MemberObj;
import cn.comshinetechchina.hyjxyl.domain.Members;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

public interface MembersDao extends MembersMapper{
  public Members selectOneMembers(String phoneNo,String token);
  /**
   * 检索用户信息
   * @param map
   * @return
   */
  public List<MemberInfo> selectMemberInfoList(Map<String,String> map,PageBean bean);
  /**
   * 查询个人明细信息
   * @param memberId
   * @return
   */
  public MemberInfo selectMemberInfoDetail(String memberId);
  /**
   * 批量更新客户状态接口
   * @param list  客户id列表
   * @param available 状态 1启用 0停用
   * @return
   */
  public int batchUpdateMemberStatus(List<String> list,int available);
  /**
   * 查询个人明细信息(扩展方法，查询所有属性)
   * @param memberId
   * @return
   */
  public MemberInfoObj selectMemberInfoObjDetail(String memberId);

  /**
   * 通过openId查询用户
   * @param openId
   * @return
   */
  public MemberInfoObj selectOneMember(String openId);

  /**
   * 置空token值
   * @param memberId
   * @return
   */
  public int updateMembersToken(String memberId);

  /**
   * 通过身份证号查询信息
   * @param map
   * @return
   */
  MemberObj getMemberByPara(Map<String,Object> map);


}
