package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.ContentTypeDao;
import cn.comshinetechchina.hyjxyl.domain.ContentType;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service("contentTypeDao")
public class ContentTypeDaoImpl extends AbstractBaseDao implements ContentTypeDao {
    @Override
    public int deleteByPrimaryKey(Long contentTypeId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.ContentTypeMapper.deleteByPrimaryKey",contentTypeId);
    }

    @Override
    public int insert(ContentType record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.ContentTypeMapper.insert",record);
    }

    @Override
    public int insertSelective(ContentType record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.ContentTypeMapper.insertSelective",record);
    }

    @Override
    public ContentType selectByPrimaryKey(Long contentTypeId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.ContentTypeMapper.selectByPrimaryKey",contentTypeId);
    }

    @Override
    public int updateByPrimaryKeySelective(ContentType record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ContentTypeMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(ContentType record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ContentTypeMapper.updateByPrimaryKey",record);
    }

    @Override
    public ContentType selectOneContentType(String typeCode, int isActive) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("typeCode",typeCode);
        map.put("isActive",isActive);
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.ContentTypeDao.selectOneContentType",map);
    }
}
