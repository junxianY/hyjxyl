package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.ColumnDao;
import cn.comshinetechchina.hyjxyl.domain.Column;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("columnDao")
public class ColumnDaoImpl extends AbstractBaseDao implements ColumnDao {
    @Override
    public int deleteByPrimaryKey(Integer columnId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.ColumnMapper.deleteByPrimaryKey",columnId);
    }

    @Override
    public int insert(Column record) {
        return 0;
    }

    @Override
    public int insertSelective(Column record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.ColumnMapper.insertSelective",record);
    }

    @Override
    public Column selectByPrimaryKey(Integer columnId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.ColumnMapper.selectByPrimaryKey",columnId);
    }

    @Override
    public int updateByPrimaryKeySelective(Column record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ColumnMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Column record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ColumnMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<Column> queryColumnList(Map<String, String> map)
    {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ColumnDao.queryColumnList",map);
    }
}
