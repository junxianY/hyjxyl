package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.ConfigMapper;
import cn.comshinetechchina.hyjxyl.domain.Config;

import java.util.List;
import java.util.Map;

public interface ConfigDao extends ConfigMapper{
    /**
     * 查询配置参数列表
     * @param code 参数code
     * @param isActive 是否有效 1有效 0无效
     * @return
     */
    public List<Config> selectConfigList(String code,int isActive);

    /**
     * 根据参数查询配置信息
     * @param map
     * @return
     */
    public List<Config> selectConfigByPara(Map<String,Object> map);

}
