package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.WeightDataMapper;
import cn.comshinetechchina.hyjxyl.domain.WeightData;

import java.util.List;
import java.util.Map;

/**
 * 数据中心-体重值
 */
public interface WeightDataDao extends WeightDataMapper {
    public List<WeightData> selectWeightDataList(PageBean page, Map<String,Object> map);
    /**
     * 查询个人体重信息
     * @param memberId
     * @return
     */
    List<WeightData> selectMemberWeightDataList(String memberId);
}
