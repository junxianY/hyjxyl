package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.ScreenDao;
import cn.comshinetechchina.hyjxyl.domain.ServiceStatistics;
import cn.comshinetechchina.hyjxyl.domain.StatisticsArticle;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("screenDao")
public class ScreenDaoImpl  extends AbstractBaseDao implements ScreenDao {
    @Override
    public int countMembers(int type) {
        Map<String,String> map=new HashMap<String,String>();
        map.put("type",String.valueOf(type));
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.ScreenDao.countMembers",map);
    }

    @Override
    public int statisticsMembersByAge(Integer ageStr, Integer ageEnd,int sex) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("ageStr",ageStr);
        map.put("ageEnd",ageEnd);
        map.put("sex",sex);
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.ScreenDao.statisticsMembersByAge",map);
    }

    @Override
    public int statisticsMembersByEducation(String educationId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.ScreenDao.statisticsMembersByEducation",educationId);
    }

    @Override
    public List<ServiceStatistics> selectServiceStatistics(Map<String,Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ScreenDao.selectServiceStatistics",map);
    }

    @Override
    public List<Map<String, Object>> queryMembersByLiveCategory(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ScreenDao.queryMembersByLiveCategory",map);
    }

    @Override
    public List<ServiceStatistics> statisticsMembersByServiceName(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ScreenDao.statisticsMembersByServiceName",map);
    }

    @Override
    public List<ServiceStatistics> statisticsCardUseRecord(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ScreenDao.statisticsCardUseRecord",map);
    }

    @Override
    public List<StatisticsArticle> statisticsArticles(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ScreenDao.statisticsArticles",map);
    }

    @Override
    public int countOneDisease(String diseaseName,int sex) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("diseaseName",diseaseName);
        map.put("sex",sex);
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.ScreenDao.countOneDisease",map);
    }

    @Override
    public List<Map<String, Object>> statisticsMembersEducation(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ScreenDao.statisticsMembersEducation",map);
    }

    @Override
    public List<Map<String, Object>> statisticsCardUse(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ScreenDao.statisticsCardUse",map);
    }

    @Override
    public int totalCount(Map<String, Object> map) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.ScreenDao.totalCount",map);
    }

    @Override
    public List<Map<String, Object>> selectResultByCheck(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ScreenDao.selectResultByCheck",map);
    }
}
