package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.TblLogDao;
import cn.comshinetechchina.hyjxyl.domain.TblLog;
import cn.comshinetechchina.hyjxyl.domain.TblLogObj;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("tblLogDao")
public class TblLogDaoImpl extends AbstractBaseDao implements TblLogDao {
    @Override
    public int deleteByPrimaryKey(String logId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.TblLogMapper.deleteByPrimaryKey",logId);
    }

    @Override
    public int insert(TblLog record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.TblLogMapper.insert",record);
    }

    @Override
    public int insertSelective(TblLog record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.TblLogMapper.insertSelective",record);
    }

    @Override
    public TblLog selectByPrimaryKey(String logId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.TblLogMapper.selectByPrimaryKey",logId);
    }

    @Override
    public int updateByPrimaryKeySelective(TblLog record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.TblLogMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKeyWithBLOBs(TblLog record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(TblLog record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.TblLogMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<TblLogObj> selectLogList(String memberId, Integer type,PageBean page) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("memberId",memberId);
        map.put("type",type);
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.TblLogDao.selectLogListCount","cn.comshinetechchina.hyjxyl.dao.TblLogDao.selectLogList",map);
    }
}
