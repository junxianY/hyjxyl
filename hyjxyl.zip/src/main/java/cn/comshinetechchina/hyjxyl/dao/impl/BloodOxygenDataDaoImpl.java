package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.BloodOxygenDataDao;
import cn.comshinetechchina.hyjxyl.domain.BloodOxygenData;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("bloodOxygenDataDao")
public class BloodOxygenDataDaoImpl extends AbstractBaseDao implements BloodOxygenDataDao {
    @Override
    public int deleteByPrimaryKey(String id) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.BloodOxygenDataMapper.deleteByPrimaryKey",id);
    }

    @Override
    public int insert(BloodOxygenData record) {
        return 0;
    }

    @Override
    public int insertSelective(BloodOxygenData record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.BloodOxygenDataMapper.insertSelective",record);
    }

    @Override
    public BloodOxygenData selectByPrimaryKey(String id) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(BloodOxygenData record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(BloodOxygenData record) {
        return 0;
    }

    @Override
    public List<BloodOxygenData> selectBloodOxygenDataList(PageBean page, Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.BloodOxygenDataDao.selectBloodOxygenDataListCount","cn.comshinetechchina.hyjxyl.dao.BloodOxygenDataDao.selectBloodOxygenDataList",map);
    }

    @Override
    public List<BloodOxygenData> selectMemberBloodOxygenDataList(String memberId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.BloodOxygenDataDao.selectMemberBloodOxygenDataList",memberId);
    }

}
