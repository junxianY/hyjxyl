package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.ContentRefMapper;
import cn.comshinetechchina.hyjxyl.domain.ContentRef;

import java.util.List;

public interface ContentRefDao extends ContentRefMapper{
    /**
     * 批量插入关键信息
     * @param list
     * @return
     */
    public int batchInsertContentRef(List<ContentRef> list);
    /**
     * 解除绑定附件
     *  @param externalId 业务id
     * @return
     */
    public int delContentRefById(String externalId);
}
