package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.MemberHealthMapper;
import cn.comshinetechchina.hyjxyl.domain.MemberHealth;

/**
 * 健康信息
 */
public interface MemberHealthDao extends MemberHealthMapper {
    //通过客户id查询客户健康信息
    MemberHealth selectMemberHealthInfo(String memberId);
}
