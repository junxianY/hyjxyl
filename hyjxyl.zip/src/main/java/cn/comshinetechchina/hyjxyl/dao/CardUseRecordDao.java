package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.CardUseRecordMapper;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecord;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecordCountObj;
import cn.comshinetechchina.hyjxyl.domain.CardUseRecordObj;

import java.util.List;
import java.util.Map;

/**
 *
 * 卡使用记录dao层
 */
public interface CardUseRecordDao extends CardUseRecordMapper{
    public List<CardUseRecordObj> selectRecordList(PageBean page,Map<String, Object> map);
    /**
     * 统计各种服务使用次数
     * @param memberId
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @return
     */
    public List<CardUseRecordCountObj> countCardUseRecord(String memberId,String startDate, String endDate);
}
