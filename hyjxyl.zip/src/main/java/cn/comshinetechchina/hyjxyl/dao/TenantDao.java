package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.TenantMapper;
import cn.comshinetechchina.hyjxyl.domain.Tenant;

import java.util.List;
import java.util.Map;

public interface TenantDao extends TenantMapper{
    /**
     * 通过条件查询租户列表
     * @param map
     * @return
     */
    public List<Tenant> selectTenantList(Map<String,Object> map);
}
