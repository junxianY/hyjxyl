package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.CardChangeRecordDao;
import cn.comshinetechchina.hyjxyl.domain.CardChangeRecord;
import org.springframework.stereotype.Service;

@Service("cardChangeRecordDao")
public class CardChangeRecordDaoImpl extends AbstractBaseDao implements CardChangeRecordDao {
    @Override
    public int deleteByPrimaryKey(String recordId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.CardChangeRecordMapper.deleteByPrimaryKey",recordId);
    }

    @Override
    public int insert(CardChangeRecord record) {
        return 0;
    }

    @Override
    public int insertSelective(CardChangeRecord record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardChangeRecordMapper.insertSelective",record);
    }

    @Override
    public CardChangeRecord selectByPrimaryKey(String recordId) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(CardChangeRecord record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(CardChangeRecord record) {
        return 0;
    }
}
