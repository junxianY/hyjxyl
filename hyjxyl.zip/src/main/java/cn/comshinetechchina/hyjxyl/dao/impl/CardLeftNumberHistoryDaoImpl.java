package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.CardLeftNumberHistoryDao;
import cn.comshinetechchina.hyjxyl.domain.CardLeftNumberHistory;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service("cardLeftNumberHistoryDao")
public class CardLeftNumberHistoryDaoImpl extends AbstractBaseDao implements CardLeftNumberHistoryDao {
    @Override
    public int insert(CardLeftNumberHistory record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardLeftNumberHistoryMapper.insert",record);
    }

    @Override
    public int insertSelective(CardLeftNumberHistory record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardLeftNumberHistoryMapper.insertSelective",record);
    }

    @Override
    public int moveCardLeftNumber(String cardNo, String serviceId) {
        Map<String,String> map=new HashMap<String,String>();
        map.put("cardNo",cardNo);
        map.put("serviceId",serviceId);
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.CardLeftNumberHistoryDao.batchMoveInsert",map);
    }

    @Override
    public int batchInsertRecordByTask(Date endDate) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("endDate",endDate);
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.CardLeftNumberHistoryDao.batchMoveRecordByTask",map);
    }
}
