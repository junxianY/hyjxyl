package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.ProvinceDao;
import cn.comshinetechchina.hyjxyl.domain.Province;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("provinceDao")
public class ProvinceDaoImpl extends AbstractBaseDao implements ProvinceDao {
    @Override
    public int deleteByPrimaryKey(Integer provinceId) {
        return 0;
    }

    @Override
    public int insert(Province record) {
        return 0;
    }

    @Override
    public int insertSelective(Province record) {
        return 0;
    }

    @Override
    public Province selectByPrimaryKey(Integer provinceId) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(Province record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(Province record) {
        return 0;
    }

    @Override
    public List<Province> selectProvinceList() {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.ProvinceDao.selectProvinceList",null);
    }
}
