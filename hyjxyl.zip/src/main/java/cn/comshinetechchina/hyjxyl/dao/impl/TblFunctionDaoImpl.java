package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.TblFunctionDao;
import cn.comshinetechchina.hyjxyl.domain.TblFunction;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("tblFunctionDao")
public class TblFunctionDaoImpl extends AbstractBaseDao implements TblFunctionDao {
    @Override
    public int deleteByPrimaryKey(Long functionId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.TblFunctionMapper.deleteByPrimaryKey",functionId);
    }

    @Override
    public int insert(TblFunction record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.TblFunctionMapper.insert",record);
    }

    @Override
    public int insertSelective(TblFunction record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.TblFunctionMapper.insertSelective",record);
    }

    @Override
    public TblFunction selectByPrimaryKey(Long functionId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.TblFunctionMapper.selectByPrimaryKey",functionId);
    }

    @Override
    public int updateByPrimaryKeySelective(TblFunction record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.TblFunctionMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(TblFunction record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.TblFunctionMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<TblFunction> selectFunctionList(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.TblFunctionDao.selectFunctionList",map);
    }
}
