package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.CarouselFigureDao;
import cn.comshinetechchina.hyjxyl.domain.ArticleObj;
import cn.comshinetechchina.hyjxyl.domain.CarouselFigure;
import cn.comshinetechchina.hyjxyl.domain.CarouselFigureObj;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("carouselFigureDao")
public class CarouselFigureDaoImpl extends AbstractBaseDao implements CarouselFigureDao {
    @Override
    public int deleteByPrimaryKey(String id) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.CarouselFigureMapper.deleteByPrimaryKey",id);
    }

    @Override
    public int insert(CarouselFigure record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CarouselFigureMapper.insert",record);
    }

    @Override
    public int insertSelective(CarouselFigure record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CarouselFigureMapper.insertSelective",record);
    }

    @Override
    public CarouselFigure selectByPrimaryKey(String id) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.CarouselFigureMapper.selectByPrimaryKey",id);
    }

    @Override
    public int updateByPrimaryKeySelective(CarouselFigure record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CarouselFigureMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(CarouselFigure record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CarouselFigureMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<CarouselFigureObj> selectCarouselFigureList(PageBean page, Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.CarouselFigureDao.selectCarouselFigureListCount","cn.comshinetechchina.hyjxyl.dao.CarouselFigureDao.selectCarouselFigureList",map);
    }

    @Override
    public List<CarouselFigureObj> selectRandom5Articles() {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.CarouselFigureDao.selectRandom5Articles");
    }

    @Override
    public List<ArticleObj> queryAvailableArticles(PageBean page,Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.CarouselFigureDao.queryAvailableArticlesCount","cn.comshinetechchina.hyjxyl.dao.CarouselFigureDao.queryAvailableArticles",map);
    }

    @Override
    public CarouselFigure selectOneCarouselFigure(String articleId, int available) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("articleId",articleId);
        map.put("available",available);
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.CarouselFigureDao.selectOneCarouselFigure",map);
    }

    @Override
    public CarouselFigure selectOneCarouselFigureByOrder(Integer orderNo) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.CarouselFigureDao.selectOneCarouselFigureByOrder",orderNo);
    }
}
