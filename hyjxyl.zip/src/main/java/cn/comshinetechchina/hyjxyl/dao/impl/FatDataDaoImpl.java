package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.FatDataDao;
import cn.comshinetechchina.hyjxyl.domain.FatData;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("fatDataDao")
public class FatDataDaoImpl extends AbstractBaseDao implements FatDataDao {
    @Override
    public List<FatData> selectFatDataList(PageBean page, Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.FatDataDao.selectFatDataListCount","cn.comshinetechchina.hyjxyl.dao.FatDataDao.selectFatDataList",map);
    }

    @Override
    public List<FatData> selectFatDataList(String memberId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.FatDataDao.selectMemberFatDataList",memberId);
    }

    @Override
    public int deleteByPrimaryKey(String id) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.FatDataMapper.deleteByPrimaryKey",id);
    }

    @Override
    public int insert(FatData record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.FatDataMapper.insert",record);
    }

    @Override
    public int insertSelective(FatData record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.FatDataMapper.insertSelective",record);
    }

    @Override
    public FatData selectByPrimaryKey(String id) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.FatDataMapper.selectByPrimaryKey",id);
    }

    @Override
    public int updateByPrimaryKeySelective(FatData record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.FatDataMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(FatData record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.FatDataMapper.updateByPrimaryKey",record);
    }
}
