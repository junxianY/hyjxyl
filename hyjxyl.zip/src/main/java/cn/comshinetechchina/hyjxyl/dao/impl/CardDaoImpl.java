package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.CardDao;
import cn.comshinetechchina.hyjxyl.domain.Card;
import cn.comshinetechchina.hyjxyl.domain.CardObj;
import cn.comshinetechchina.hyjxyl.domain.MemberInfo;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("cardDao")
public class CardDaoImpl extends AbstractBaseDao implements CardDao {
    @Override
    public int deleteByPrimaryKey(String cardId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.CardMapper.deleteByPrimaryKey",cardId);
    }

    @Override
    public int insert(Card record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardMapper.insert",record);
    }

    @Override
    public int insertSelective(Card record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.CardMapper.insertSelective",record);
    }

    @Override
    public Card selectByPrimaryKey(String cardId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.CardMapper.selectByPrimaryKey",cardId);
    }

    @Override
    public int updateByPrimaryKeySelective(Card record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Card record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.CardMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<CardObj> selectCardList(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.CardDao.selectCardList",map);
    }

    @Override
    public int batchUpdateCardStatus(List<String> list, int available) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("list",list);
        map.put("available",available);
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.CardDao.batchUpdateCardStatus",map);
    }

    @Override
    public List<MemberInfo> selectCardMemberList(Map<String, String> map, PageBean bean) {
        return this.queryForPaginatedList(bean,"cn.comshinetechchina.hyjxyl.dao.CardDao.selectCardMemberListCount","cn.comshinetechchina.hyjxyl.dao.CardDao.selectCardMemberList",map);

    }
}
