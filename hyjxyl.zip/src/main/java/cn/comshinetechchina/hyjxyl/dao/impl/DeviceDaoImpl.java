package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.DeviceDao;
import cn.comshinetechchina.hyjxyl.domain.Device;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("deviceDao")
public class DeviceDaoImpl extends AbstractBaseDao implements DeviceDao {
    @Override
    public int deleteByPrimaryKey(String deviceId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.DeviceMapper.deleteByPrimaryKey",deviceId);
    }

    @Override
    public int insert(Device record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.DeviceMapper.insert",record);
    }

    @Override
    public int insertSelective(Device record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.DeviceMapper.insertSelective",record);
    }

    @Override
    public Device selectByPrimaryKey(String deviceId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.DeviceMapper.selectByPrimaryKey",deviceId);
    }

    @Override
    public int updateByPrimaryKeySelective(Device record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.DeviceMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Device record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.DeviceMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<Device> selectDeviceList(String deviceNO, String tenantId, String serviceId, int available) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("deviceNO",deviceNO);
        map.put("tenantId",tenantId);
        map.put("serviceId",serviceId);
        map.put("available",available);
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.DeviceDao.selectDeviceList",map);
    }

    @Override
    public List<Device> selectPageDeviceList(Map<String, Object> map, PageBean bean) {
        return this.queryForPaginatedList(bean,"cn.comshinetechchina.hyjxyl.dao.DeviceDao.selectPageDeviceListCount","cn.comshinetechchina.hyjxyl.dao.DeviceDao.selectPageDeviceList",map);
    }
}
