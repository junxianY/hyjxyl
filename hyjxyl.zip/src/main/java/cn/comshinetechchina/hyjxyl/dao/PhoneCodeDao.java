package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.PhoneCodeMapper;

public interface PhoneCodeDao extends PhoneCodeMapper {

}
