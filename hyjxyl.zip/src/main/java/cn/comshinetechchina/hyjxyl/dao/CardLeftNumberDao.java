package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.CardLeftNumberMapper;
import cn.comshinetechchina.hyjxyl.domain.CardLeftNumber;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface CardLeftNumberDao extends CardLeftNumberMapper {
    /**
     * 批量插入记录
     * @param list
     * @return
     */
    public int batchInsertRecord(List<CardLeftNumber> list);

    /**
     * 根据条件查询卡剩余次数
     * @param map
     * @return
     */
    public List<CardLeftNumber> selectCardLeftNumberList(Map<String,Object> map);

    /**
     * 更新卡编号方法
     * @param oldCardNo 旧卡编号
     * @param newCardNo 新卡编号
     * @return
     */
    public int changeCardNo(String oldCardNo,String newCardNo);

    /**
     * 批量更新卡剩余次数记录状态
     * @param cardNo
     * @return
     */
    public int updateLeftNumberAvailable(String cardNo);
    /**
     * 删除接口
     * @param cardNo
     * @return
     */
    public int deleteInfoByPara(String cardNo);
    /**
     * 删除某时间之前的过期记录
     * @param endDate
     * @return
     */
    public int delRecordByTask(Date endDate);
}
