package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.CityDao;
import cn.comshinetechchina.hyjxyl.domain.City;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("cityDao")
public class CityDaoImpl extends AbstractBaseDao implements CityDao {
    @Override
    public int deleteByPrimaryKey(Integer cityId) {
        return 0;
    }

    @Override
    public int insert(City record) {
        return 0;
    }

    @Override
    public int insertSelective(City record) {
        return 0;
    }

    @Override
    public City selectByPrimaryKey(Integer cityId) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(City record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(City record) {
        return 0;
    }

    @Override
    public List<City> selectCityList(String provinceId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.CityDao.selectCityList",provinceId);
    }
}
