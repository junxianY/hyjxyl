package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.AdviceMapper;
import cn.comshinetechchina.hyjxyl.domain.AdviceObj;

import java.util.List;
import java.util.Map;

public interface AdviceDao extends AdviceMapper{
    /**
     * 查询意见建议列表
     * @param page
     * @param map
     * @return
     */
    public List<AdviceObj> selectAdviceList(PageBean page, Map<String,String> map);
}
