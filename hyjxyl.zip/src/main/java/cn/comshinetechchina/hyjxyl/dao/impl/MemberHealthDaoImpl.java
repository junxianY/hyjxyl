package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.MemberHealthDao;
import cn.comshinetechchina.hyjxyl.domain.MemberHealth;
import org.springframework.stereotype.Service;

@Service("memberHealthDao")
public class MemberHealthDaoImpl extends AbstractBaseDao implements MemberHealthDao{

    @Override
    public int deleteByPrimaryKey(String healthId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.MemberHealthMapper.deleteByPrimaryKey",healthId);
    }

    @Override
    public int insert(MemberHealth record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.MemberHealthMapper.insert",record);
    }

    @Override
    public int insertSelective(MemberHealth record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.MemberHealthMapper.insertSelective",record);
    }

    @Override
    public MemberHealth selectByPrimaryKey(String healthId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.MemberHealthMapper.selectByPrimaryKey",healthId);
    }

    @Override
    public int updateByPrimaryKeySelective(MemberHealth record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.MemberHealthMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(MemberHealth record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.MemberHealthMapper.updateByPrimaryKey",record);
    }

    @Override
    public MemberHealth selectMemberHealthInfo(String memberId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.MemberHealthDao.selectMemberHealthInfo",memberId);
    }
}
