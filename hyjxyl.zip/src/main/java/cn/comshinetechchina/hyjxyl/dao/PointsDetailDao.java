package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.PointsDetailMapper;
import cn.comshinetechchina.hyjxyl.domain.PointsDetail;

import java.util.List;
import java.util.Map;

public interface PointsDetailDao extends PointsDetailMapper {
    /**
     * 查询积分明细信息接口
     * @param map
     * @return
     */
    List<PointsDetail> selectPointsDetailList(Map<String,Object> map);
    /**
     * 分页查询
     * @param map
     * @param bean
     * @return
     */
    List<PointsDetail> selectPointsDetailListByPage(Map<String,Object> map,PageBean bean);
}
