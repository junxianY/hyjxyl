package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.mapper.CarouselFigureMapper;
import cn.comshinetechchina.hyjxyl.domain.ArticleObj;
import cn.comshinetechchina.hyjxyl.domain.CarouselFigure;
import cn.comshinetechchina.hyjxyl.domain.CarouselFigureObj;

import java.util.List;
import java.util.Map;

/**
 * 轮播图接口
 */
public interface CarouselFigureDao extends CarouselFigureMapper {
  public List<CarouselFigureObj> selectCarouselFigureList(PageBean page, Map<String,Object> map);
  public List<CarouselFigureObj> selectRandom5Articles();
  /**
   * 查询可以添加的活动列表
   * @param page
   * @param map
   * @return
   */
  public List<ArticleObj> queryAvailableArticles(PageBean page,Map<String,Object> map);
  /**
   * 通过articleId查询对应轮播图信息
   * @param articleId
   * @return
   */
  CarouselFigure selectOneCarouselFigure(String articleId, int available);
  /**
   * 通过序号查询信息
   * @param orderNo
   * @return
   */
  CarouselFigure selectOneCarouselFigureByOrder(Integer orderNo);
}
