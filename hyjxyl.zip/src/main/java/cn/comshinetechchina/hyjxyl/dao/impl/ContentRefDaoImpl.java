package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.ContentRefDao;
import cn.comshinetechchina.hyjxyl.domain.ContentRef;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("contentRefDao")
public class ContentRefDaoImpl extends AbstractBaseDao implements ContentRefDao {
    @Override
    public int deleteByPrimaryKey(String contentRefId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.ContentRefMapper.deleteByPrimaryKey",contentRefId);
    }

    @Override
    public int insert(ContentRef record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.ContentRefMapper.insert",record);
    }

    @Override
    public int insertSelective(ContentRef record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.ContentRefMapper.insertSelective",record);
    }

    @Override
    public ContentRef selectByPrimaryKey(String contentRefId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.ContentRefMapper.selectByPrimaryKey",contentRefId);
    }

    @Override
    public int updateByPrimaryKeySelective(ContentRef record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ContentRefMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(ContentRef record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.ContentRefMapper.updateByPrimaryKey",record);
    }

    @Override
    public int batchInsertContentRef(List<ContentRef> list) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.ContentRefDao.batchInsertContentRef",list);
    }

    @Override
    public int delContentRefById(String externalId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.ContentRefDao.delContentRefById",externalId);
    }

}
