package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.IllnessDao;
import cn.comshinetechchina.hyjxyl.domain.Illness;
import cn.comshinetechchina.hyjxyl.domain.IllnessObj;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("illnessDao")
public class IllnessDaoImpl extends AbstractBaseDao implements IllnessDao {
    @Override
    public int deleteByPrimaryKey(String illnessId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.IllnessMapper.deleteByPrimaryKey",illnessId);
    }

    @Override
    public int insert(Illness record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.IllnessMapper.insert",record);
    }

    @Override
    public int insertSelective(Illness record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.IllnessMapper.insertSelective",record);
    }

    @Override
    public Illness selectByPrimaryKey(String illnessId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.IllnessMapper.selectByPrimaryKey",illnessId);
    }

    @Override
    public int updateByPrimaryKeySelective(Illness record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.IllnessMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(Illness record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.IllnessMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<IllnessObj> getIllnessList(Map<String, Object> map, PageBean bean) {
        return this.queryForPaginatedList(bean,"cn.comshinetechchina.hyjxyl.dao.IllnessDao.getIllnessListCount","cn.comshinetechchina.hyjxyl.dao.IllnessDao.getIllnessList",map);
    }

    @Override
    public IllnessObj selectOneIllness(String illnessId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.IllnessDao.selectOneIllness",illnessId);
    }
}
