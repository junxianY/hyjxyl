package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.SelfCenterConfigMapper;

public interface SelfCenterConfigDao extends SelfCenterConfigMapper {

}
