package cn.comshinetechchina.hyjxyl.dao;

import cn.comshinetechchina.hyjxyl.dao.mapper.ProvinceMapper;
import cn.comshinetechchina.hyjxyl.domain.Province;

import java.util.List;

public interface ProvinceDao extends ProvinceMapper {
    public List<Province> selectProvinceList();
}
