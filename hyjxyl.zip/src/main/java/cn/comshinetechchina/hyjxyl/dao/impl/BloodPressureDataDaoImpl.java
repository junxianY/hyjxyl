package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.base.PageBean;
import cn.comshinetechchina.hyjxyl.dao.BloodPressureDataDao;
import cn.comshinetechchina.hyjxyl.domain.BloodPressureData;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("bloodPressureDataDao")
public class BloodPressureDataDaoImpl extends AbstractBaseDao implements BloodPressureDataDao {
    @Override
    public int deleteByPrimaryKey(String id) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.BloodPressureDataMapper.deleteByPrimaryKey",id);
    }

    @Override
    public int insert(BloodPressureData record) {
        return 0;
    }

    @Override
    public int insertSelective(BloodPressureData record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.BloodPressureDataMapper.insertSelective",record);
    }

    @Override
    public BloodPressureData selectByPrimaryKey(String id) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(BloodPressureData record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(BloodPressureData record) {
        return 0;
    }

    @Override
    public List<BloodPressureData> selectBloodPressureDataList(PageBean page, Map<String, Object> map) {
        return this.queryForPaginatedList(page,"cn.comshinetechchina.hyjxyl.dao.BloodPressureDataDao.selectBloodPressureDataListCount","cn.comshinetechchina.hyjxyl.dao.BloodPressureDataDao.selectBloodPressureDataList",map);
    }

    @Override
    public List<BloodPressureData> selectMemberBloodPressureDataList(String memberId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.BloodPressureDataDao.selectMemberBloodPressureDataList",memberId);
    }
}
