package cn.comshinetechchina.hyjxyl.dao.impl;

import cn.comshinetechchina.hyjxyl.base.AbstractBaseDao;
import cn.comshinetechchina.hyjxyl.dao.KithAndKinDao;
import cn.comshinetechchina.hyjxyl.domain.KithAndKin;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("kithAndKinDao")
public class KithAndKinDaoImpl extends AbstractBaseDao implements KithAndKinDao {

    @Override
    public int deleteByPrimaryKey(String kinId) {
        return this.getSqlSession().delete("cn.comshinetechchina.hyjxyl.dao.mapper.KithAndKinMapper.deleteByPrimaryKey",kinId);
    }

    @Override
    public int insert(KithAndKin record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.KithAndKinMapper.insert",record);
    }

    @Override
    public int insertSelective(KithAndKin record) {
        return this.getSqlSession().insert("cn.comshinetechchina.hyjxyl.dao.mapper.KithAndKinMapper.insertSelective",record);
    }

    @Override
    public KithAndKin selectByPrimaryKey(String kinId) {
        return this.getSqlSession().selectOne("cn.comshinetechchina.hyjxyl.dao.mapper.KithAndKinMapper.selectByPrimaryKey",kinId);
    }

    @Override
    public int updateByPrimaryKeySelective(KithAndKin record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.KithAndKinMapper.updateByPrimaryKeySelective",record);
    }

    @Override
    public int updateByPrimaryKey(KithAndKin record) {
        return this.getSqlSession().update("cn.comshinetechchina.hyjxyl.dao.mapper.KithAndKinMapper.updateByPrimaryKey",record);
    }

    @Override
    public List<KithAndKin> selectUserKithList(String memberId) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.KithAndKinDao.selectUserKithList",memberId);
    }

    @Override
    public List<KithAndKin> selectKithListByPara(String memberId, String nickMemberId, String nickName, String available) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("memberId",memberId);
        map.put("nickMemberId",nickMemberId);
        map.put("nickName",nickName);
        map.put("available",available);
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.KithAndKinDao.selectKithListByPara",map);
    }

    @Override
    public List<KithAndKin> selectUserKithList(String memberId, int concern) {
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("memberId",memberId);
        map.put("concern",concern);
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.KithAndKinDao.selectUserKithListByConcern",map);

    }

    @Override
    public List<KithAndKin> selectKithListByPara(Map<String, Object> map) {
        return this.getSqlSession().selectList("cn.comshinetechchina.hyjxyl.dao.KithAndKinDao.selectKithListByPara",map);
    }
}
