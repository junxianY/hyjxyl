package cn.comshinetechchina.hyjxyl.filter;
import cn.comshinetechchina.hyjxyl.util.JwtUtil;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * token过滤器
 */
@WebFilter(urlPatterns="/*")
public class CheckTokenFilter implements Filter {
    private static final Logger log= LoggerFactory.getLogger(CheckTokenFilter.class);
    @Override
    public void doFilter(ServletRequest argo, ServletResponse arg1,
                         FilterChain chain ) throws IOException, ServletException {
        HttpServletRequest request=(HttpServletRequest) argo;
        HttpServletResponse response=(HttpServletResponse) arg1;
        //response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Origin","*");
        response.setHeader("Access-Control-Allow-Methods", "POST,GET, OPTIONS, DELETE");
        response.setHeader("Access-Control-Max-Age","3600");
        response.setHeader("Access-Control-Allow-Headers","x-requested-with,Cache-Control,Pragma,Content-Type,Token");
        response.setHeader("Access-Control-Allow-Credentials","true");
        System.out.println("跨域设置完毕");
        //前后端登录、前端注册、下载附件不拦截、发送验证码、找回密码不校验token，直接放行  数据中心和中控刷卡不拦截  、校验token过期、校验微信id 、大屏统计、体检信息 不拦截
        if(request.getRequestURI().endsWith("/loginController/loginCheck")||request.getRequestURI().endsWith("/loginController/register")||request.getRequestURI().endsWith("/loginController/weChatLogin")||request.getRequestURI().endsWith("/contentController/fileDownloadForFrontPlatForm")||request.getRequestURI().endsWith("/userController/loginCheck")||request.getRequestURI().indexOf("/fileDownloadForRich/")!=-1||request.getRequestURI().endsWith("/loginController/sendIdentifyCode")||request.getRequestURI().endsWith("/loginController/resetPassword")||request.getRequestURI().endsWith("/dataController/receiveData")||request.getRequestURI().endsWith("/cardUseRecordController/useCardInfo")||request.getRequestURI().endsWith("/loginController/checkTokenActive")||request.getRequestURI().endsWith("/loginController/checkWeChatOpenId")||(request.getRequestURI().indexOf("/screenController/")!=-1)||request.getRequestURI().endsWith("/sh05/getUserByIdcard")||request.getRequestURI().endsWith("/dataController/recieveData")||request.getRequestURI().endsWith("/sh05/uploadData")||request.getRequestURI().endsWith("/articleController/queryArticleDetail")){
            chain.doFilter(request, response);
            return;
        }
        //其他API接口一律校验token
        System.out.println("开始校验token");
        //从请求头中获取token
        String token=request.getHeader("token");
        log.info("-----------请求头中token:"+token);
        Map<String, Object> resultMap= JwtUtil.validToken(token);
        TokenState state=TokenState.getTokenState((String)resultMap.get("state"));
        log.info("-----------token状态state:"+state);
        switch (state) {
            case VALID:
                //取出payload中数据,放入到request作用域中
                request.setAttribute("data", resultMap.get("data"));
                //放行
                chain.doFilter(request, response);
                break;
            case EXPIRED:
            case INVALID:
                System.out.println("无效token");
                //token过期或者无效，则输出错误信息返回给ajax
                JSONObject outputMSg=new JSONObject();
                outputMSg.put("success", false);
                outputMSg.put("msgType", 1);
                outputMSg.put("message", "您的token不合法或者过期了，请重新登陆");
                output(outputMSg.toJSONString(), response);
                break;
        }


    }


    public void output(String jsonStr,HttpServletResponse response) throws IOException{
        response.setContentType("text/html;charset=UTF-8;");
        PrintWriter out = response.getWriter();
//		out.println();
        out.write(jsonStr);
        out.flush();
        out.close();

    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
        System.out.println("token过滤器初始化了");
    }

    @Override
    public void destroy() {

    }
}
