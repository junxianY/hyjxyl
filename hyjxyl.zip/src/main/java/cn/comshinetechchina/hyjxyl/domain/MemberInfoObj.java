package cn.comshinetechchina.hyjxyl.domain;

/**
 * 个人明细信息辅助类
 */
public class MemberInfoObj {
    //主键id
    private String memberId;
    //用户姓名
    private String name;
    //手机号
    private String phone;
    //卡编号
    private String cardNo;
    //卡种类名称
    private String cardTypeName;
    //性别
    private String sex;
    //年龄
    private Integer age;
    //民族
    private String nationName;
    //家庭住址
    private String houseAddress;
    //状态
    private String state;
    //注册日期
    private String registerDate;
    //身份证号
    private String idNo;
    //最后更新日期
    private String lastUpdateDate;
    //出生日期
    private String birthday;
    //省份id
    private String provinceId;
    //城市id
    private String cityId;
    //区域id
    private String areaId;
    //小区名
    private String areaName;

    //工作单位
    private String workUnit;
    //教育程度
    private String education;
    //经济来源
    private String economicSources;
    //医保类别
    private String healthCategory;
    //居住类别
    private String liveType;
    private int sonNumber; //儿子个数
    private int daughterNumber; //女儿个数
    private String liveCategory; //居住情况
    private String liveCategoryId;//非自居下分类
    private String hasNanny; //照护人员有无
    private String nannyCategoryId; //照护人员分类
    private String contentId; //头像id
    private String remark; //备注

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardTypeName() {
        return cardTypeName;
    }

    public void setCardTypeName(String cardTypeName) {
        this.cardTypeName = cardTypeName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getNationName() {
        return nationName;
    }

    public void setNationName(String nationName) {
        this.nationName = nationName;
    }

    public String getHouseAddress() {
        return houseAddress;
    }

    public void setHouseAddress(String houseAddress) {
        this.houseAddress = houseAddress;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(String registerDate) {
        this.registerDate = registerDate;
    }

    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(String provinceId) {
        this.provinceId = provinceId;
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getWorkUnit() {
        return workUnit;
    }

    public void setWorkUnit(String workUnit) {
        this.workUnit = workUnit;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getEconomicSources() {
        return economicSources;
    }

    public void setEconomicSources(String economicSources) {
        this.economicSources = economicSources;
    }

    public String getHealthCategory() {
        return healthCategory;
    }

    public void setHealthCategory(String healthCategory) {
        this.healthCategory = healthCategory;
    }

    public String getLiveType() {
        return liveType;
    }

    public void setLiveType(String liveType) {
        this.liveType = liveType;
    }

    public int getSonNumber() {
        return sonNumber;
    }

    public void setSonNumber(int sonNumber) {
        this.sonNumber = sonNumber;
    }

    public int getDaughterNumber() {
        return daughterNumber;
    }

    public void setDaughterNumber(int daughterNumber) {
        this.daughterNumber = daughterNumber;
    }

    public String getLiveCategory() {
        return liveCategory;
    }

    public void setLiveCategory(String liveCategory) {
        this.liveCategory = liveCategory;
    }

    public String getLiveCategoryId() {
        return liveCategoryId;
    }

    public void setLiveCategoryId(String liveCategoryId) {
        this.liveCategoryId = liveCategoryId;
    }

    public String getHasNanny() {
        return hasNanny;
    }

    public void setHasNanny(String hasNanny) {
        this.hasNanny = hasNanny;
    }

    public String getNannyCategoryId() {
        return nannyCategoryId;
    }

    public void setNannyCategoryId(String nannyCategoryId) {
        this.nannyCategoryId = nannyCategoryId;
    }

    public String getContentId() {
        return contentId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }
}
