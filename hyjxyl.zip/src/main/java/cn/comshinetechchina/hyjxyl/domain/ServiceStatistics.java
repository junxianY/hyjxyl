package cn.comshinetechchina.hyjxyl.domain;

/**
 * 根据服务统计对象
 */
public class ServiceStatistics implements Comparable<ServiceStatistics>{
    //刷卡日期
    private String useDate;
    //服务名称
    private String serviceName;
    //使用次数
    private String count;
    //用户名称
    private String userName;

    public String getUseDate() {
        return useDate;
    }

    public void setUseDate(String useDate) {
        this.useDate = useDate;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public int compareTo(ServiceStatistics o) {
        //按照日期排序 升序
        Integer useDate1=Integer.parseInt(this.getUseDate().replaceAll("-",""));
        Integer useDate2=Integer.parseInt(o.getUseDate().replaceAll("-",""));
        return  useDate1-useDate2;
    }
}
