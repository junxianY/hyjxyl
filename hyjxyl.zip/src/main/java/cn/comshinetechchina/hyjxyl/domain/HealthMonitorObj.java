package cn.comshinetechchina.hyjxyl.domain;

/**
 * 大屏 健康预警对象
 */
public class HealthMonitorObj {
    //项目
    private String name;
    //检测人数
    private int totalCount;
    //预警人数
    private int alarmCount;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getAlarmCount() {
        return alarmCount;
    }

    public void setAlarmCount(int alarmCount) {
        this.alarmCount = alarmCount;
    }
}
