package cn.comshinetechchina.hyjxyl.domain;
/**
 * 查询省市区tree辅助类 承载区域参数
 */
public class PcaObj2 {
    //区域id
    private String value;
    //区域名称
    private String label;
    //是否叶子节点
    private boolean isLeaf;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public boolean isIsLeaf() {
        return true;
    }

    public void setIsLeaf(boolean leaf) {
        isLeaf = leaf;
    }
}
