package cn.comshinetechchina.hyjxyl.domain;

import java.util.List;

/**
 * 个人修改卡信息封装类
 */
public class NewCardBean {
    //客户id
    private String memberId;
    //卡编号
    private String cardNo;
    private String cardTypeId;
    //销售专员
    private String saleAccount;
    //相关服务列表
    private List<CardTypeService> services;
    //有效起止日
    private String startDate;
    //有效结束日
    private String endDate;
    //备注
    private String remark;
    //卡推荐人
    private String cardReference;
    //卡面卡号
    private String faceNo;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardTypeId() {
        return cardTypeId;
    }

    public void setCardTypeId(String cardTypeId) {
        this.cardTypeId = cardTypeId;
    }

    public String getSaleAccount() {
        return saleAccount;
    }

    public void setSaleAccount(String saleAccount) {
        this.saleAccount = saleAccount;
    }

    public List<CardTypeService> getServices() {
        return services;
    }

    public void setServices(List<CardTypeService> services) {
        this.services = services;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getCardReference() {
        return cardReference;
    }

    public void setCardReference(String cardReference) {
        this.cardReference = cardReference;
    }

    public String getFaceNo() {
        return faceNo;
    }

    public void setFaceNo(String faceNo) {
        this.faceNo = faceNo;
    }
}
