package cn.comshinetechchina.hyjxyl.domain;

import java.util.List;

/**
 * 新检测数据封装
 */
public class ReqData {
    private String mac;
    private List<CheckData> data;

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public List<CheckData> getData() {
        return data;
    }

    public void setData(List<CheckData> data) {
        this.data = data;
    }
}
