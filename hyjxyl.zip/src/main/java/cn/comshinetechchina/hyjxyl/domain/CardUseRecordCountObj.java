package cn.comshinetechchina.hyjxyl.domain;

/**
 * 卡使用次数统计
 */
public class CardUseRecordCountObj {
    //服务id
    private String serviceId;
    //服务名称
    private String serviceName;
    //总数
    private Integer count;
    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
