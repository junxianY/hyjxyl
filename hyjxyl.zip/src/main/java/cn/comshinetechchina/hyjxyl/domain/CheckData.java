package cn.comshinetechchina.hyjxyl.domain;
/**
 * 检测数据封装
 */
public class CheckData {
    private String sequences; //微信体检(必填)
    private Integer healthType; //体检方式(1.刷卡,2.微信,3. 身份证号)
    private String photoPath; //头像base64
    private String userId;  //用户id
    private String hospitalName; //单位名称
    private String hospitalAddress; //单位地址
    private String reportId; //报告id
    private String reportNo;//报告编号
    private String userName; //用户名
    private Integer sex; //性别(1=男  2=女  0=未知)
    private String birthday; //出生日期 (yyyy-MM-dd)
    private String idCard; //身份证号
    private Integer age; //年龄
    private String phone; //手机号
    private String createTime;  //体检时间(yyyy-MM-dd HH:mm:ss)
    private float height; //身高(cm)
    private float weight; //体重(kg)
    private Integer weightState;
    private float hwBmi; //身体质量指数BMI
    private Integer hwBmiState; //hwBmi状态(1=偏高 2=偏低 3=正常)
    private float waistCircumference; //腰围(cm)
    private float hipCircumference; //臀围(cm)
    private float ytBmi; //腰臀BMI
    private Integer ytBmiState; // ytBmi状态 (1=偏高 2=偏低 3=正常)
    private float leftEyesight; //左眼视力
    private Integer leftEyesightState; //左眼视力状态(1=偏高 2=偏低 3=正常)
    private float rightEyesight; //右眼视力
    private Integer rightEyesightState; //右眼视力状态  (1=偏高 2=偏低 3=正常)
    private Integer heightPressure;//收缩压(mmHg)
    private Integer heightPressureState; //收缩压状态1 = 低压(value < 90)|| 2 = 轻度高血压(139 <=value< 160)|| 3 = 中度高血压(160  <= value < 180)||4 = 重度高血压(value >= 180)||5 = 正常(90  <= value < 139)
    private Integer lowPressure; //舒张压(mmHg)
    private Integer lowPressureState; //舒张压状态  1 = 低压(value < 60)||2 = 轻度高血压(89 <= value < 100)||3 = 中度高血压(100  <= value < 110)||4 = 重度高血压(value >= 110)||5 = 正常(60  <= value < 89)
    private Integer pulse; //脉搏(分/次)
    private Integer pulseState; //脉搏状态(1=偏高 2=偏低 3=正常)
    private float oxygenSaturation;  // 血氧(%)
    private Integer oxygenSaturationState; //血氧状态 (1=偏高 2=偏低 3=正常)
    private float bloodSugar; //血糖(mmol/L)
    private Integer bloodSugarState; //血糖状态 (1=偏高 2=偏低 3=正常)
    private Integer bloodSugarType; //血糖类型 (1=空腹2=饭后3=随机 )
    private Integer ecgRate; //心率(分/次)
    private Integer ecgRateState; //心率状态 (1=偏高 2=偏低 3=正常)
    private float templature; //体温(℃)
    private Integer templatureState; //体温状态  (1=偏高 2=偏低 3=正常);
    private float fatRate; //体脂肪率(%)
    private Integer fatRateState; //体脂肪率状态 (1=偏高 2=偏低 3=正常)
    private float fat; //体脂肪量(Kg)
    private float waterRate; //体水分率(%)
    private Integer waterRateState; //体水分率状态 (1=偏高 2=偏低 3=正常)
    private float water; //体水分量(Kg)
    private Integer basalMetabolism;  //基础代谢(Kcal)
    private Integer basalMetabolismState; //基础代谢状态 (1=偏高 2=偏低 3=正常)
    private float uricAcid; //尿酸(mmol/L)
    private Integer uricAcidState; //尿酸状态 (1=偏高 2=偏低 3=正常)
    private float totalCholesterol; //总胆固醇(mmol/L)
    private Integer totalCholesterolState; //总胆固醇状态 (1=偏高 2=偏低 3=正常)
    private float triglycerides; //甘油三脂(mmol/L)
    private Integer triglyceridesState; //甘油三脂状态 (1=偏高 2=偏低 3=正常)
    private float heightLipoprotein; //高密度蛋白(mmol/L)
    private Integer heightLipoproteinState; //高密度蛋白状态 (1=偏高 2=偏低 3=正常)
    private float lowLipoprotein; //低密度蛋白
    private Integer lowLipoproteinState;  //低密度蛋白状态 (1=偏高 2=偏低 3=正常)
    private String build; //体型评估
    private String[]  fatRateLines; //体脂肪率曲线图
    private String[] heightPressureLines; //收缩压曲线图
    private String[] lowPressureLines; //舒张压曲线图
    private String ecgs; //心电图 url
    private String ecgRateResult; //心率检测结论
    private String[] physical; //中医体质分析
    private String physicalResult; //中医体质分析结果
    private String[] advice; //医疗建议
    private float tclHdl; //TC/HDL
    private Integer tclHdlState; //TC/HDL 状态 1=偏高，3=正常
    private float cholesterol; //胆固醇
    private Integer cholesterolState; //胆固醇状态1=偏高 2=偏低 3=正常
    private Integer pulseRate; //脉率
    private Integer pulseRateState; //脉率状态1=偏高 2=偏低 3=正常
    private float leanBodyWeight; //去脂体重
    private float boneMass; //骨量
    private float muscleMass; //肌肉量
    private float muscleRate; //肌肉率
    private Integer muscleRateState; //肌肉率状态1=偏高 2=偏低 3=正常
    private float visceralFat; //内脏脂肪
    private Integer visceralFatState; //状态1=偏高 2=偏低 3=正常
    private float PeakFlow; //峰值流量
    private float ForcedVolume1; //用力吹第一秒流量
    private float ForcedVitalCapacity; //用力呼气流量
    private float PEF; //峰值流量与正常的百分比
    private float FEV1; //用力吹第一秒流量与正常的百分比
    private float FVC; //用力吹第一秒流量与用力呼气流量的百分比
    private Integer PEFState; //PEF结果（0：正常;1：警告; 2: 危险）
    private Integer FEV1State; //FEV1结果，（0：正常;1：轻度; 2: 中度;3:重度;4: 极重度）
    private Integer FVCState; //FVC结果，（0：正常;1：轻度; 2: 中度;3:重度;4: 极重度）

    public String getSequences() {
        return sequences;
    }

    public void setSequences(String sequences) {
        this.sequences = sequences;
    }

    public Integer getHealthType() {
        return healthType;
    }

    public void setHealthType(Integer healthType) {
        this.healthType = healthType;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public String getHospitalAddress() {
        return hospitalAddress;
    }

    public void setHospitalAddress(String hospitalAddress) {
        this.hospitalAddress = hospitalAddress;
    }

    public String getReportId() {
        return reportId;
    }

    public void setReportId(String reportId) {
        this.reportId = reportId;
    }

    public String getReportNo() {
        return reportNo;
    }

    public void setReportNo(String reportNo) {
        this.reportNo = reportNo;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public Integer getWeightState() {
        return weightState;
    }

    public void setWeightState(Integer weightState) {
        this.weightState = weightState;
    }

    public float getHwBmi() {
        return hwBmi;
    }

    public void setHwBmi(float hwBmi) {
        this.hwBmi = hwBmi;
    }

    public Integer getHwBmiState() {
        return hwBmiState;
    }

    public void setHwBmiState(Integer hwBmiState) {
        this.hwBmiState = hwBmiState;
    }

    public float getWaistCircumference() {
        return waistCircumference;
    }

    public void setWaistCircumference(float waistCircumference) {
        this.waistCircumference = waistCircumference;
    }

    public float getHipCircumference() {
        return hipCircumference;
    }

    public void setHipCircumference(float hipCircumference) {
        this.hipCircumference = hipCircumference;
    }

    public float getYtBmi() {
        return ytBmi;
    }

    public void setYtBmi(float ytBmi) {
        this.ytBmi = ytBmi;
    }

    public Integer getYtBmiState() {
        return ytBmiState;
    }

    public void setYtBmiState(Integer ytBmiState) {
        this.ytBmiState = ytBmiState;
    }

    public float getLeftEyesight() {
        return leftEyesight;
    }

    public void setLeftEyesight(float leftEyesight) {
        this.leftEyesight = leftEyesight;
    }

    public Integer getLeftEyesightState() {
        return leftEyesightState;
    }

    public void setLeftEyesightState(Integer leftEyesightState) {
        this.leftEyesightState = leftEyesightState;
    }

    public float getRightEyesight() {
        return rightEyesight;
    }

    public void setRightEyesight(float rightEyesight) {
        this.rightEyesight = rightEyesight;
    }

    public Integer getRightEyesightState() {
        return rightEyesightState;
    }

    public void setRightEyesightState(Integer rightEyesightState) {
        this.rightEyesightState = rightEyesightState;
    }

    public Integer getHeightPressure() {
        return heightPressure;
    }

    public void setHeightPressure(Integer heightPressure) {
        this.heightPressure = heightPressure;
    }

    public Integer getHeightPressureState() {
        return heightPressureState;
    }

    public void setHeightPressureState(Integer heightPressureState) {
        this.heightPressureState = heightPressureState;
    }

    public Integer getLowPressure() {
        return lowPressure;
    }

    public void setLowPressure(Integer lowPressure) {
        this.lowPressure = lowPressure;
    }

    public Integer getLowPressureState() {
        return lowPressureState;
    }

    public void setLowPressureState(Integer lowPressureState) {
        this.lowPressureState = lowPressureState;
    }

    public Integer getPulse() {
        return pulse;
    }

    public void setPulse(Integer pulse) {
        this.pulse = pulse;
    }

    public Integer getPulseState() {
        return pulseState;
    }

    public void setPulseState(Integer pulseState) {
        this.pulseState = pulseState;
    }

    public float getOxygenSaturation() {
        return oxygenSaturation;
    }

    public void setOxygenSaturation(float oxygenSaturation) {
        this.oxygenSaturation = oxygenSaturation;
    }

    public Integer getOxygenSaturationState() {
        return oxygenSaturationState;
    }

    public void setOxygenSaturationState(Integer oxygenSaturationState) {
        this.oxygenSaturationState = oxygenSaturationState;
    }

    public float getBloodSugar() {
        return bloodSugar;
    }

    public void setBloodSugar(float bloodSugar) {
        this.bloodSugar = bloodSugar;
    }

    public Integer getBloodSugarState() {
        return bloodSugarState;
    }

    public void setBloodSugarState(Integer bloodSugarState) {
        this.bloodSugarState = bloodSugarState;
    }

    public Integer getBloodSugarType() {
        return bloodSugarType;
    }

    public void setBloodSugarType(Integer bloodSugarType) {
        this.bloodSugarType = bloodSugarType;
    }

    public Integer getEcgRate() {
        return ecgRate;
    }

    public void setEcgRate(Integer ecgRate) {
        this.ecgRate = ecgRate;
    }

    public Integer getEcgRateState() {
        return ecgRateState;
    }

    public void setEcgRateState(Integer ecgRateState) {
        this.ecgRateState = ecgRateState;
    }

    public float getTemplature() {
        return templature;
    }

    public void setTemplature(float templature) {
        this.templature = templature;
    }

    public Integer getTemplatureState() {
        return templatureState;
    }

    public void setTemplatureState(Integer templatureState) {
        this.templatureState = templatureState;
    }

    public float getFatRate() {
        return fatRate;
    }

    public void setFatRate(float fatRate) {
        this.fatRate = fatRate;
    }

    public Integer getFatRateState() {
        return fatRateState;
    }

    public void setFatRateState(Integer fatRateState) {
        this.fatRateState = fatRateState;
    }

    public float getFat() {
        return fat;
    }

    public void setFat(float fat) {
        this.fat = fat;
    }

    public float getWaterRate() {
        return waterRate;
    }

    public void setWaterRate(float waterRate) {
        this.waterRate = waterRate;
    }

    public Integer getWaterRateState() {
        return waterRateState;
    }

    public void setWaterRateState(Integer waterRateState) {
        this.waterRateState = waterRateState;
    }

    public float getWater() {
        return water;
    }

    public void setWater(float water) {
        this.water = water;
    }

    public Integer getBasalMetabolism() {
        return basalMetabolism;
    }

    public void setBasalMetabolism(Integer basalMetabolism) {
        this.basalMetabolism = basalMetabolism;
    }

    public Integer getBasalMetabolismState() {
        return basalMetabolismState;
    }

    public void setBasalMetabolismState(Integer basalMetabolismState) {
        this.basalMetabolismState = basalMetabolismState;
    }

    public float getUricAcid() {
        return uricAcid;
    }

    public void setUricAcid(float uricAcid) {
        this.uricAcid = uricAcid;
    }

    public Integer getUricAcidState() {
        return uricAcidState;
    }

    public void setUricAcidState(Integer uricAcidState) {
        this.uricAcidState = uricAcidState;
    }

    public float getTotalCholesterol() {
        return totalCholesterol;
    }

    public void setTotalCholesterol(float totalCholesterol) {
        this.totalCholesterol = totalCholesterol;
    }

    public Integer getTotalCholesterolState() {
        return totalCholesterolState;
    }

    public void setTotalCholesterolState(Integer totalCholesterolState) {
        this.totalCholesterolState = totalCholesterolState;
    }

    public float getTriglycerides() {
        return triglycerides;
    }

    public void setTriglycerides(float triglycerides) {
        this.triglycerides = triglycerides;
    }

    public Integer getTriglyceridesState() {
        return triglyceridesState;
    }

    public void setTriglyceridesState(Integer triglyceridesState) {
        this.triglyceridesState = triglyceridesState;
    }

    public float getHeightLipoprotein() {
        return heightLipoprotein;
    }

    public void setHeightLipoprotein(float heightLipoprotein) {
        this.heightLipoprotein = heightLipoprotein;
    }

    public Integer getHeightLipoproteinState() {
        return heightLipoproteinState;
    }

    public void setHeightLipoproteinState(Integer heightLipoproteinState) {
        this.heightLipoproteinState = heightLipoproteinState;
    }

    public float getLowLipoprotein() {
        return lowLipoprotein;
    }

    public void setLowLipoprotein(float lowLipoprotein) {
        this.lowLipoprotein = lowLipoprotein;
    }

    public Integer getLowLipoproteinState() {
        return lowLipoproteinState;
    }

    public void setLowLipoproteinState(Integer lowLipoproteinState) {
        this.lowLipoproteinState = lowLipoproteinState;
    }

    public String getBuild() {
        return build;
    }

    public void setBuild(String build) {
        this.build = build;
    }

    public String getEcgs() {
        return ecgs;
    }

    public void setEcgs(String ecgs) {
        this.ecgs = ecgs;
    }

    public String getEcgRateResult() {
        return ecgRateResult;
    }

    public void setEcgRateResult(String ecgRateResult) {
        this.ecgRateResult = ecgRateResult;
    }

    public String getPhysicalResult() {
        return physicalResult;
    }
    public void setPhysicalResult(String physicalResult) {
        this.physicalResult = physicalResult;
    }

    public float getTclHdl() {
        return tclHdl;
    }

    public void setTclHdl(float tclHdl) {
        this.tclHdl = tclHdl;
    }

    public Integer getTclHdlState() {
        return tclHdlState;
    }

    public void setTclHdlState(Integer tclHdlState) {
        this.tclHdlState = tclHdlState;
    }

    public float getCholesterol() {
        return cholesterol;
    }

    public void setCholesterol(float cholesterol) {
        this.cholesterol = cholesterol;
    }

    public Integer getCholesterolState() {
        return cholesterolState;
    }

    public void setCholesterolState(Integer cholesterolState) {
        this.cholesterolState = cholesterolState;
    }

    public Integer getPulseRate() {
        return pulseRate;
    }

    public void setPulseRate(Integer pulseRate) {
        this.pulseRate = pulseRate;
    }

    public Integer getPulseRateState() {
        return pulseRateState;
    }

    public void setPulseRateState(Integer pulseRateState) {
        this.pulseRateState = pulseRateState;
    }

    public float getLeanBodyWeight() {
        return leanBodyWeight;
    }

    public void setLeanBodyWeight(float leanBodyWeight) {
        this.leanBodyWeight = leanBodyWeight;
    }

    public float getBoneMass() {
        return boneMass;
    }

    public void setBoneMass(float boneMass) {
        this.boneMass = boneMass;
    }

    public float getMuscleMass() {
        return muscleMass;
    }

    public void setMuscleMass(float muscleMass) {
        this.muscleMass = muscleMass;
    }

    public float getMuscleRate() {
        return muscleRate;
    }

    public void setMuscleRate(float muscleRate) {
        this.muscleRate = muscleRate;
    }

    public Integer getMuscleRateState() {
        return muscleRateState;
    }

    public void setMuscleRateState(Integer muscleRateState) {
        this.muscleRateState = muscleRateState;
    }

    public float getVisceralFat() {
        return visceralFat;
    }

    public void setVisceralFat(float visceralFat) {
        this.visceralFat = visceralFat;
    }

    public Integer getVisceralFatState() {
        return visceralFatState;
    }

    public void setVisceralFatState(Integer visceralFatState) {
        this.visceralFatState = visceralFatState;
    }

    public float getPeakFlow() {
        return PeakFlow;
    }

    public void setPeakFlow(float peakFlow) {
        PeakFlow = peakFlow;
    }

    public float getForcedVolume1() {
        return ForcedVolume1;
    }

    public void setForcedVolume1(float forcedVolume1) {
        ForcedVolume1 = forcedVolume1;
    }

    public float getForcedVitalCapacity() {
        return ForcedVitalCapacity;
    }

    public void setForcedVitalCapacity(float forcedVitalCapacity) {
        ForcedVitalCapacity = forcedVitalCapacity;
    }

    public float getPEF() {
        return PEF;
    }

    public void setPEF(float PEF) {
        this.PEF = PEF;
    }

    public float getFEV1() {
        return FEV1;
    }

    public void setFEV1(float FEV1) {
        this.FEV1 = FEV1;
    }

    public float getFVC() {
        return FVC;
    }

    public void setFVC(float FVC) {
        this.FVC = FVC;
    }

    public Integer getPEFState() {
        return PEFState;
    }

    public void setPEFState(Integer PEFState) {
        this.PEFState = PEFState;
    }

    public Integer getFEV1State() {
        return FEV1State;
    }

    public void setFEV1State(Integer FEV1State) {
        this.FEV1State = FEV1State;
    }

    public Integer getFVCState() {
        return FVCState;
    }

    public void setFVCState(Integer FVCState) {
        this.FVCState = FVCState;
    }

    public String[] getFatRateLines() {
        return fatRateLines;
    }

    public void setFatRateLines(String[] fatRateLines) {
        this.fatRateLines = fatRateLines;
    }

    public String[] getHeightPressureLines() {
        return heightPressureLines;
    }

    public void setHeightPressureLines(String[] heightPressureLines) {
        this.heightPressureLines = heightPressureLines;
    }

    public String[] getLowPressureLines() {
        return lowPressureLines;
    }

    public void setLowPressureLines(String[] lowPressureLines) {
        this.lowPressureLines = lowPressureLines;
    }

    public String[] getPhysical() {
        return physical;
    }

    public void setPhysical(String[] physical) {
        this.physical = physical;
    }

    public String[] getAdvice() {
        return advice;
    }

    public void setAdvice(String[] advice) {
        this.advice = advice;
    }
}
