package cn.comshinetechchina.hyjxyl.domain;

import java.util.List;

/**
 * 查询省市区tree辅助类
 */
public class PcaObj1 {
    //id
    private String value;
    //name
    private String label;
    private List<PcaObj2> children;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<PcaObj2> getChildren() {
        return children;
    }

    public void setChildren(List<PcaObj2> children) {
        this.children = children;
    }

}
