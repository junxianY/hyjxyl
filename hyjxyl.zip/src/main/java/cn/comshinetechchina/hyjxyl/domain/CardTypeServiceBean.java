package cn.comshinetechchina.hyjxyl.domain;

import java.util.List;

/**
 * 卡类型绑定服务bean
 */
public class CardTypeServiceBean {
    //卡类型id
    private String cardTypeId;
    //卡类型名
    private String name;
    //描述
    private String description;
    //相关服务列表
    private List<CardTypeService> services;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<CardTypeService> getServices() {
        return services;
    }

    public void setServices(List<CardTypeService> services) {
        this.services = services;
    }

    public String getCardTypeId() {
        return cardTypeId;
    }

    public void setCardTypeId(String cardTypeId) {
        this.cardTypeId = cardTypeId;
    }
}
