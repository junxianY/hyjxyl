package cn.comshinetechchina.hyjxyl.domain;

/**
 * 健康情况 积分判断辅助类
 */
public class HealthInfo {
    //身高
    private Integer height;
    //体重
    private Integer weight;
    //吸烟情况
    private String smokeSituation;
    //饮酒情况
    private String drinkSituation;
    //饮食偏好
    private String foodPreference;
    //睡眠质量
    private String sleepQuality;
    //情绪状态
    private String emotionalStatus;
    //锻炼频率
    private String exerciseFrequency;
    //饮食情况
    private String foodSituation;
    //排便情况
    private String defecationSituation;
    //排便频率
    private String defecationRate;
    //近况
    private String recentSituation;

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public String getSmokeSituation() {
        return smokeSituation;
    }

    public void setSmokeSituation(String smokeSituation) {
        this.smokeSituation = smokeSituation;
    }

    public String getDrinkSituation() {
        return drinkSituation;
    }

    public void setDrinkSituation(String drinkSituation) {
        this.drinkSituation = drinkSituation;
    }

    public String getFoodPreference() {
        return foodPreference;
    }

    public void setFoodPreference(String foodPreference) {
        this.foodPreference = foodPreference;
    }

    public String getSleepQuality() {
        return sleepQuality;
    }

    public void setSleepQuality(String sleepQuality) {
        this.sleepQuality = sleepQuality;
    }

    public String getEmotionalStatus() {
        return emotionalStatus;
    }

    public void setEmotionalStatus(String emotionalStatus) {
        this.emotionalStatus = emotionalStatus;
    }

    public String getExerciseFrequency() {
        return exerciseFrequency;
    }

    public void setExerciseFrequency(String exerciseFrequency) {
        this.exerciseFrequency = exerciseFrequency;
    }

    public String getFoodSituation() {
        return foodSituation;
    }

    public void setFoodSituation(String foodSituation) {
        this.foodSituation = foodSituation;
    }

    public String getDefecationSituation() {
        return defecationSituation;
    }

    public void setDefecationSituation(String defecationSituation) {
        this.defecationSituation = defecationSituation;
    }

    public String getDefecationRate() {
        return defecationRate;
    }

    public void setDefecationRate(String defecationRate) {
        this.defecationRate = defecationRate;
    }

    public String getRecentSituation() {
        return recentSituation;
    }

    public void setRecentSituation(String recentSituation) {
        this.recentSituation = recentSituation;
    }
}
