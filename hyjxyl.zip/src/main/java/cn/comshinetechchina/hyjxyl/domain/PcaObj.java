package cn.comshinetechchina.hyjxyl.domain;

import java.util.List;

/**
 * 查询省市区tree辅助类
 */
public class PcaObj {
    //id
    private String value;
    //name
    private String label;
    private List<PcaObj1> children;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<PcaObj1> getChildren() {
        return children;
    }

    public void setChildren(List<PcaObj1> children) {
        this.children = children;
    }
}
