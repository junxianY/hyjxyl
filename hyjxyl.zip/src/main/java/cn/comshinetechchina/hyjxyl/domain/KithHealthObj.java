package cn.comshinetechchina.hyjxyl.domain;

/**
 * app首页亲友健康信息辅助类
 */
public class KithHealthObj {
    private String nickMemberId;
    private String contentId;
    private String nickName;
    private String relationRemark;
    //血压  1正常 2异常 0未检测
    private int bloodPressure;
    //血糖   1正常 2异常
    private int bloodSugar;
    //体重 1正常 2异常
    private int weightState;
    //血氧 1正常 2异常
    private int bloodOxygenState;
    //尿酸 1正常 2异常
    private int urineState;
    //体脂 1正常 2异常
    private int fatRateState;

    private int bloodFatState; //血脂
    private int ecgRateState; //心率
    //检测时间
    private String testDate;
    //申请访问 1是 0否
    private int accessNick;

    public String getNickMemberId() {
        return nickMemberId;
    }

    public void setNickMemberId(String nickMemberId) {
        this.nickMemberId = nickMemberId;
    }

    public String getContentId() {
        return contentId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getRelationRemark() {
        return relationRemark;
    }

    public void setRelationRemark(String relationRemark) {
        this.relationRemark = relationRemark;
    }

    public int getBloodPressure() {
        return bloodPressure;
    }

    public void setBloodPressure(int bloodPressure) {
        this.bloodPressure = bloodPressure;
    }

    public int getBloodSugar() {
        return bloodSugar;
    }

    public void setBloodSugar(int bloodSugar) {
        this.bloodSugar = bloodSugar;
    }

    public String getTestDate() {
        return testDate;
    }

    public void setTestDate(String testDate) {
        this.testDate = testDate;
    }

    public int getWeightState() {
        return weightState;
    }

    public void setWeightState(int weightState) {
        this.weightState = weightState;
    }

    public int getBloodOxygenState() {
        return bloodOxygenState;
    }

    public void setBloodOxygenState(int bloodOxygenState) {
        this.bloodOxygenState = bloodOxygenState;
    }

    public int getUrineState() {
        return urineState;
    }

    public void setUrineState(int urineState) {
        this.urineState = urineState;
    }

    public int getFatRateState() {
        return fatRateState;
    }

    public void setFatRateState(int fatRateState) {
        this.fatRateState = fatRateState;
    }

    public int getAccessNick() {
        return accessNick;
    }

    public void setAccessNick(int accessNick) {
        this.accessNick = accessNick;
    }

    public int getBloodFatState() {
        return bloodFatState;
    }

    public void setBloodFatState(int bloodFatState) {
        this.bloodFatState = bloodFatState;
    }

    public int getEcgRateState() {
        return ecgRateState;
    }

    public void setEcgRateState(int ecgRateState) {
        this.ecgRateState = ecgRateState;
    }
}
