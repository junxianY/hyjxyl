package cn.comshinetechchina.hyjxyl.domain;

/**
 * 活动咨询统计类
 */
public class StatisticsArticle {
    //类型
    private String typeId;
    //点赞数
    private Integer favourCount;
    //评论数
    private Integer commentCount;
    //标题
    private String title;
    //浏览数
    private Integer browsingCount;

    public String getTypeId() {
        return typeId;
    }

    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    public Integer getFavourCount() {
        return favourCount;
    }

    public void setFavourCount(Integer favourCount) {
        this.favourCount = favourCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getBrowsingCount() {
        return browsingCount;
    }

    public void setBrowsingCount(Integer browsingCount) {
        this.browsingCount = browsingCount;
    }
}
