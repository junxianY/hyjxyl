package cn.comshinetechchina.hyjxyl.domain;

/**
 * 刷卡辅助类
 */
public class UseCardObj {
    private String cardNo;
    private String deviceNo;

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getDeviceNo() {
        return deviceNo;
    }

    public void setDeviceNo(String deviceNo) {
        this.deviceNo = deviceNo;
    }
}
