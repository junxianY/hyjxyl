package cn.comshinetechchina.hyjxyl.domain;

import java.util.Date;

/**
 * 用于积分判断个属性是否为空 55岁以上
 */
public class ExtendsMemberInfo {
    private String memberId;
    private String name;
    private Integer sex;
    private Date birthday;

    private Integer nationId;
    private Integer provinceId;
    private Integer cityId;
    private Integer areaId;
    private String areaName;
    private String idNo;
    private String workUnit;
    private String educationId;
    private String economicSourcesId;
    private String healthCategoryId;
    private String liveTypeId;
    private Integer sonNumber;
    private Integer daughterNumber;
    private Integer liveCategory;
    private Integer hasNanny;
    private Integer age;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public Integer getNationId() {
        return nationId;
    }

    public void setNationId(Integer nationId) {
        this.nationId = nationId;
    }

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public String getWorkUnit() {
        return workUnit;
    }

    public void setWorkUnit(String workUnit) {
        this.workUnit = workUnit;
    }

    public String getEducationId() {
        return educationId;
    }

    public void setEducationId(String educationId) {
        this.educationId = educationId;
    }

    public String getEconomicSourcesId() {
        return economicSourcesId;
    }

    public void setEconomicSourcesId(String economicSourcesId) {
        this.economicSourcesId = economicSourcesId;
    }

    public String getHealthCategoryId() {
        return healthCategoryId;
    }

    public void setHealthCategoryId(String healthCategoryId) {
        this.healthCategoryId = healthCategoryId;
    }

    public String getLiveTypeId() {
        return liveTypeId;
    }

    public void setLiveTypeId(String liveTypeId) {
        this.liveTypeId = liveTypeId;
    }

    public Integer getSonNumber() {
        return sonNumber;
    }

    public void setSonNumber(Integer sonNumber) {
        this.sonNumber = sonNumber;
    }

    public Integer getDaughterNumber() {
        return daughterNumber;
    }

    public void setDaughterNumber(Integer daughterNumber) {
        this.daughterNumber = daughterNumber;
    }

    public Integer getLiveCategory() {
        return liveCategory;
    }

    public void setLiveCategory(Integer liveCategory) {
        this.liveCategory = liveCategory;
    }

    public Integer getHasNanny() {
        return hasNanny;
    }

    public void setHasNanny(Integer hasNanny) {
        this.hasNanny = hasNanny;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}
